/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2011, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * PdfStreamDecoder.java
  * ---------------
 */
package org.jpedal.parser;

import org.jpedal.PdfDecoder;
import org.jpedal.color.*;
import org.jpedal.constants.PDFImageProcessing;
import org.jpedal.constants.PageInfo;
import org.jpedal.exception.PdfException;
import org.jpedal.exception.PdfFontException;
import org.jpedal.external.*;
import org.jpedal.fonts.FontMappings;
import org.jpedal.fonts.PdfFont;
import org.jpedal.fonts.StandardFonts;
import org.jpedal.fonts.glyph.*;
import org.jpedal.images.SamplingFactory;
import org.jpedal.io.*;
import org.jpedal.objects.*;
import org.jpedal.objects.layers.PdfLayerList;
import org.jpedal.objects.raw.*;
//<start-adobe>// <start-me>
import org.jpedal.objects.structuredtext.StructuredContentHandler;
//<end-adobe>// <end-me>
import org.jpedal.render.*;
import org.jpedal.utils.Fonts;
import org.jpedal.utils.LogWriter;
import org.jpedal.utils.Matrix;
import org.jpedal.utils.StringUtils;
import org.jpedal.utils.repositories.Vector_Int;
import org.jpedal.utils.repositories.Vector_Object;
import org.jpedal.utils.repositories.Vector_Rectangle;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.Rectangle2D;
import java.awt.image.*;
import java.util.*;

import static org.jpedal.parser.ValueTypes.*;

/**
 * Contains the code which 'parses' the commands in
 * the stream and extracts the data (images and text).
 * Users should not need to call it.
 */
public class PdfStreamDecoder{

    private StreamDecoderStatus streamDecoderStatus=new StreamDecoderStatus();

    private PdfObjectCache cache=new PdfObjectCache();

    /**list of images used for display*/
    private String imagesInFile=null;

    //set threshold - value indicates several possible values
    public static float currentThreshold=0.595f;

    /**xml color tag to show color*/
    private String currentColor=GenericColorSpace.cb+"C='1' M='1' Y='1' K='1'>";

    private TextDecoder textDecoder= new TextDecoder();

    public ErrorTracker errorTracker=new ErrorTracker();

    private boolean flattenXFormToImage=false;

    private boolean requestTimeout =false;

    private int timeoutInterval=-1;

    private PdfLayerList layers=null;

    private boolean TRFlagged=false;

    private PdfObject pageResources =null;

    private ImageHandler customImageHandler=null;


    //used in CS to avoid miscaching
    private String csInUse,CSInUse;

    private boolean rejectSuperimposedImages=true;

    private boolean isLayerVisible=true;
    private int layerLevel=0;

    private PdfObject groupObj=null;

    //flag used to debug feature - please do not use
    final public static boolean newForms=true;


    private Map layerVisibility=new HashMap();

    private Map layerClips=new HashMap();

    //only load 1 instance of any 1 font
    private  HashMap fontsLoaded=new HashMap();

    //start of Dictionary on Inline image
    private int startInlineStream=0;


    //save font info and generate glyph on first render
    private boolean generateGlyphOnRender=false;

    private final static int[] prefixes={60,40}; //important that [ comes before (  '<'=60 '('=40
    private final static int[] suffixes={62,41}; //'>'=62 ')'=41

    /**flag to show if non-embedded CID fonts*/
    private boolean hasNonEmbeddedCIDFonts=false;

    /**and the list of CID fonts*/
    private StringBuffer nonEmbeddedCIDFonts=new StringBuffer();

    /** last text stream decoded*/
    //private StringBuffer textData;

    /**interactive display*/
    private StatusBar statusBar=null;

    /**get percentage of gap required to create a space 1=100% */
    //public static float currentThreshold = 0.6f; //referenced in Decoder if changed
    //public static Map currentThresholdValues; //referenced in Decoder if changed

    /**flag to engage text printing*/
    private int textPrint=0;

    //used to clip and adjust scaling for images
    //int minX=0, minY=0,maxX=-1,maxY=-1;


    /**provide access to pdf file objects*/
    private PdfObjectReader currentPdfFile;

    private Vector_Rectangle textAreas = new Vector_Rectangle();
    private Vector_Int textDirections = new Vector_Int();

    /**flag to show if image is for clip*/
    private boolean isClip = false;

    /**flag to show content is being rendered*/
    private boolean renderText=false;

    /**flag to show if we REMOVE shapes*/
    private boolean removeRenderImages=false;

    private boolean   markedContentExtracted=false;

    //<start-adobe><start-me>
    private StructuredContentHandler contentHandler;
    //<end-me><end-adobe>

    /**flag to show text is being extracted*/
    private boolean textExtracted=true;

    /**flags to show we need colour data as well*/
    private boolean textColorExtracted=false,colorExtracted=false;

    /**store text data and can be passed out to other classes*/
    private PdfData pdfData = new PdfData();

    /**current XML tag*/
    private String font_as_string="";

    /**store image data extracted from pdf*/
    private PdfImageData pdfImages=new PdfImageData();

    /**token counter so we can work out order objects drawn*/
    private int tokenNumber = 0;

    /**flag to show if stack setup*/
    private boolean isStackInitialised=false;

    /**stack for graphics states*/
    private Vector_Object graphicsStateStack;

    /**stack for graphics states*/
    private Vector_Object strokeColorStateStack;

    /**stack for graphics states*/
    private Vector_Object nonstrokeColorStateStack;

    /**stack for graphics state clips*/
    //private Vector_Object clipStack;


    /**stack for graphics states*/
    private Vector_Object textStateStack;

    /**used to debug*/
    private String indent="";

    /**horizontal and vertical lines on page*/
    //private PageLines pageLines=new PageLines();

    /**current shape object being drawn note we pass in handle on pageLines*/
    private PdfShape currentDrawShape=new PdfShape();

    /**maximum ops*/
    private static final int MAXOPS=50;

    /**current op*/
    private int currentOp=0;

    /**actual numbe rof operands read*/
    private int operandCount=0;

    /**lookup table for operands on commands*/
    private int[] opStart= new int[MAXOPS];
    private int[] opEnd= new int[MAXOPS];

    /**flag to show type of move command being executed*/
    private int moveCommand = 0; //0=t*, 1=Tj, 2=TD

    /**current font for text*/
    private String currentFont = "";

    private Map globalXObjects = new Hashtable(),localXObjects=new Hashtable();

    /**current graphics state - updated and copied as file decode*/
    private GraphicsState gs=new GraphicsState();

    /**current text state - updated and copied as file decode*/
    private TextState currentTextState = new TextState();

    /**used to store font information from pdf and font functionality*/
    private PdfFont currentFontData;

    /**GS*/
    private Map GraphicsStates=new HashMap();

    private Map patterns=new HashMap(),globalShadings=new HashMap(), localShadings=new HashMap();

    /**flag to show we use hi-res images to draw onscreen*/
    private boolean useHiResImageForDisplay=false;

    /** holds page information used in grouping*/
    private PdfPageData pageData = new PdfPageData();

    private DynamicVectorRenderer current;

    /** constant for conversion*/
    private static final double radiansToDegrees=180f/Math.PI;

    /**used in grouping rotated text by Storypad*/
    private double rotationAsRadians=0;

    /**page number*/
    private int pageNum;

    /**list of fonts used for display*/
    private String fontsInFile;

    /**max width of type3 font*/
    private int T3maxWidth,T3maxHeight;

    /**flag to show we are drawing directly to g2 and not storing to render later*/
    private boolean renderDirectly;

    /**clip if we render directly*/
    private Shape defaultClip;

    /**flag to show embedded fonts present*/
    private boolean hasEmbeddedFonts=false;

    /**flag to show if images are included in datastream*/
    //private boolean includeImagesInData=false;

    /**track font size*/
    private int lastFontSize=-1;

    /**shows if t3 glyph uses internal colour or current colour*/
    public boolean ignoreColors=false;


    private ObjectStore objectStoreStreamRef;

    private int pageH;

    private int formLevel=0;

    private float topLevelStrokeAlpha=1f, topLevelNonStrokeAlpha=1f;
    private float TTtopLevelNonStrokeAlpha=1f;
    private int topBM=PdfDictionary.Normal;

    private float nonStrokeAlpha=1f, strokeAlpha=1f;

    //public static boolean runningStoryPad=false;

    final private static float[] matches={1f,0f,0f,1f,0f,0f};

    private boolean isType3Font;

    public static boolean showInvisibleText=false;

    public static boolean useTextPrintingForNonEmbeddedFonts=false;
    private int currentRotation=0;

    //use in rotation handling to handle minor issues
    private float unRotatedY =-1;


    static{

        SamplingFactory.setDownsampleMode(null);

    }

    private Map lines=new HashMap();

    /**
     * flag to show interrupted by user
     */
    private boolean isTimeout=false;

    private int renderMode=0;

    /**
     * only used by Pattern Colorspace to pass in cached values
     *
     */
    public PdfStreamDecoder(Map colorspacesObjects) {
        cache.colorspacesObjects=colorspacesObjects;

    }


    /**
     * NOT PART OF API
     * tells software to generate glyph when first rendered not when decoded.
     * Should not need to be called in general usage
     */
    public void setBooleanValue(int key,boolean value) {

        switch(key){


            /**method ensures images rendered as ARGB rather than RGB. Used internally
             * to ensure prints correctly on some files. Not recommended for
             * external usage.
             */
            case OptimiseDisplayForPrinting:
                streamDecoderStatus.isPrinting=value;
                break;


            case XFormFlattening:
            flattenXFormToImage=value;
            break;
        }
    }

    /**/

    public PdfStreamDecoder(PdfObjectReader currentPdfFile,boolean useHires,boolean isType3Font){


        StandardFonts.checkLoaded(StandardFonts.STD);

        this.currentPdfFile=currentPdfFile;
        this.useHiResImageForDisplay=useHires;

        this.isType3Font=isType3Font;

        String operlapValue=System.getProperty("org.jpedal.rejectsuperimposedimages");
        if(operlapValue!=null)
            this.rejectSuperimposedImages=(operlapValue!=null && operlapValue.toLowerCase().indexOf("true")!=-1);
    }

    public PdfStreamDecoder(PdfObjectReader currentPdfFile){

        StandardFonts.checkLoaded(StandardFonts.STD);

        this.currentPdfFile=currentPdfFile;

        String operlapValue=System.getProperty("org.jpedal.rejectsuperimposedimages");

        if(operlapValue!=null)
            this.rejectSuperimposedImages=(operlapValue!=null && operlapValue.toLowerCase().indexOf("true")!=-1);

    }

    public PdfStreamDecoder(PdfObject pageResources){

        this.pageResources =pageResources;

        StandardFonts.checkLoaded(StandardFonts.STD);

        String operlapValue=System.getProperty("org.jpedal.rejectsuperimposedimages");
        if(operlapValue!=null)
            rejectSuperimposedImages=(operlapValue!=null && operlapValue.toLowerCase().indexOf("true")!=-1);

    }



    public void print(Graphics2D g2,AffineTransform scaling,int currentPrintPage,
                      Rectangle userAnnot,CustomPrintHintingHandler customPrintHintingHandler, PdfDecoder pdf){

        if(customPrintHintingHandler!=null){
            current.stopG2HintSetting(true);
            customPrintHintingHandler.preprint(g2,pdf);
        }

        current.setPrintPage(currentPrintPage);

        current.setCustomColorHandler((ColorHandler) pdf.getExternalHandler(Options.ColorHandler));

        current.setG2(g2);
        current.paint(null,scaling,userAnnot);
    }

    /**
     * create new StreamDecoder to create screen display with hires images
     */
    public PdfStreamDecoder(boolean useHiResImageForDisplay, PdfLayerList layers, PdfObject pageResources) {

        this.layers=layers;
        this.pageResources =pageResources;

        StandardFonts.checkLoaded(StandardFonts.STD);


        String operlapValue=System.getProperty("org.jpedal.rejectsuperimposedimages");
        if(operlapValue!=null)
            rejectSuperimposedImages=(operlapValue!=null && operlapValue.toLowerCase().indexOf("true")!=-1);

    }

    /**used internally to allow for colored streams*/
    public void setDefaultColors(PdfPaint strokeCol, PdfPaint nonstrokeCol) {

        gs.strokeColorSpace.setColor(strokeCol);
        gs.nonstrokeColorSpace.setColor(nonstrokeCol);
        gs.setStrokeColor(strokeCol);
        gs.setNonstrokeColor(nonstrokeCol);
    }

    /**return the data*/
    public Object getObject(int key){

        switch(key){
            case ValueTypes.PDFData:
            return  pdfData;

            case ValueTypes.PDFImages:
                return  pdfImages;

            case ValueTypes.TextAreas:
                   return textAreas;

            case ValueTypes.TextDirections:
                   return textDirections;

            case ValueTypes.DynamicVectorRenderer:
                return current;

        }

        return null;
    }

    public void init(boolean isPageContent,boolean renderPage,
                     int renderMode, int extractionMode,PdfPageData currentPageData,
                     int pageNumber,DynamicVectorRenderer current,
                     PdfObjectReader currentPdfFile) throws PdfException{

        streamDecoderStatus.init(isPageContent,extractionMode, renderMode, renderPage);

        if(current!=null)
            this.current=current;

        this.renderMode=renderMode;

        this.pageNum=pageNumber;
        this.pageData=currentPageData;
        this.currentPdfFile=currentPdfFile;
        textAreas = new Vector_Rectangle();
        textDirections = new Vector_Int();
        if(customImageHandler!=null && current!=null)
            current.setCustomImageHandler(customImageHandler);

        //setup height
        this.pageH = pageData.getMediaBoxHeight(pageNumber);

        textExtracted=(extractionMode & PdfDecoder.TEXT)==PdfDecoder.TEXT;

        renderText=renderPage &&(renderMode & PdfDecoder.RENDERTEXT) == PdfDecoder.RENDERTEXT;

        //flag OCR used
        boolean isOCR=(renderMode & PdfDecoder.OCR_PDF)==PdfDecoder.OCR_PDF;
        if(isOCR && current!=null)
            current.setOCR(true);

        removeRenderImages=renderPage &&(renderMode & PdfDecoder.REMOVE_RENDERSHAPES )== PdfDecoder.REMOVE_RENDERSHAPES;

        textColorExtracted=(extractionMode & PdfDecoder.TEXTCOLOR) == PdfDecoder.TEXTCOLOR;

        colorExtracted=(extractionMode & PdfDecoder.COLOR) == PdfDecoder.COLOR;

        //flag if colour info being extracted
        if(textColorExtracted)
            pdfData.enableTextColorDataExtraction();

        currentFontData=new PdfFont(currentPdfFile);

    }

    private void readArrayPairs(PdfObject Resources, boolean resetFontList, int type) throws PdfException {

        LogWriter.writeMethod("{readArrayPairs}", 0);

        final boolean debugPairs=false;

        if(debugPairs){
            System.out.println("-------------readArrayPairs-----------"+type);
            System.out.println("new="+Resources+ ' '+Resources.getObjectRefAsString());
        }
        String id = "",value;

        if(resetFontList && type==PdfDictionary.Font)
            fontsInFile="";

        /**
         * new code
         */
        if(Resources!=null){


            PdfObject resObj=Resources.getDictionary(type);

            if(debugPairs)
                System.out.println("new res object="+resObj);

            if(resObj!=null){

                /**
                 * read all the key pairs for Glyphs
                 */
                PdfKeyPairsIterator keyPairs=resObj.getKeyPairsIterator();

                PdfObject obj;

                if(debugPairs){
                    System.out.println("New values");
                    System.out.println("----------");
                }

                while(keyPairs.hasMorePairs()){

                    id=keyPairs.getNextKeyAsString();
                    value=keyPairs.getNextValueAsString();
                    obj=keyPairs.getNextValueAsDictionary();

                    if(debugPairs)
                        System.out.println(id+ ' '+obj+ ' ' +value+ ' ' +Resources.isDataExternal());

                    if(Resources.isDataExternal()){ //check and flag if missing
                        //xxx
                        if(obj==null && value==null){
                            //System.out.println("missing1 ");
                            Resources.setFullyResolved(false);
                            return;
                        }else if(obj==null){

                            PdfObject childObj=ObjectFactory.createObject(type,value,type,-1);
                            //System.out.println("child="+childObj);

                            childObj.setStatus(PdfObject.UNDECODED_DIRECT);
                            childObj.setUnresolvedData(value.getBytes(), type);

                            if(!currentPdfFile.getObjectDecoder().resolveFully(childObj)){
                                Resources.setFullyResolved(false);
                                //System.out.println("missing2 ");
                                return;
                            }

                            //cache if setup
                            if(type==PdfDictionary.Font){
                                //System.out.println("id="+id);
                                PdfFont restoredFont = createFont(childObj,id);
                                cache.resolvedFonts.put(id,restoredFont);
                            }
                            //if(obj!=null)
                            //System.out.println(obj+" "+obj.getObjectRefAsString());
                        }else if(!currentPdfFile.getObjectDecoder().resolveFully(obj)){
                            //System.out.println("missing3 "+obj);
                            Resources.setFullyResolved(false);
                            return;
                        }//else
                        // System.out.println("fully resolved");




                    }

                    {
                        switch(type){

                            case PdfDictionary.ColorSpace:
                                cache.colorspaces.put(id,obj);
                                break;

                            case PdfDictionary.ExtGState:
                                GraphicsStates.put(id,obj);
                                break;

                            case PdfDictionary.Font:

                                cache.unresolvedFonts.put(id,value);

                                break;

                            case PdfDictionary.Pattern:
                                patterns.put(id,obj);

                                break;

                            case PdfDictionary.Shading:
                                if(resetFontList)
                                    globalShadings.put(id, obj);
                                else
                                    localShadings.put(id, obj);

                                break;

                            case PdfDictionary.XObject:
                                if(resetFontList)
                                    globalXObjects.put(id, obj);
                                else
                                    localXObjects.put(id, obj);

                                break;

                        }
                    }

                    keyPairs.nextPair();
                }
            }
        }
    }

    private PdfFont createFont(PdfObject pdfObject, String font_id) throws PdfException{

        LogWriter.writeMethod("{createFont}", 0);

        /**
         * allow for no actual object - ie /PDFdata/baseline_screens/debug/res.pdf
         **/
        //found examples with no type set so cannot rely on it
        //int rawType=pdfObject.getParameterConstant(PdfDictionary.Type);
        //if(rawType!=PdfDictionary.Font)
        //	return null;

        String baseFont="",rawFontName=null;

        String subFont=null;
        int fontType=PdfDictionary.Unknown,origfontType=PdfDictionary.Unknown;

        PdfObject descendantFont=pdfObject.getDictionary(PdfDictionary.DescendantFonts);

        boolean isEmbedded= isFontEmbedded(pdfObject);
        boolean isFontBroken=true; //ensure enters once

        while(isFontBroken){ //will try to sub font if error in embedded
            isFontBroken=false;

            /**
             * handle any font remapping but not on CID fonts or Type3 and gets too messy
             **/
            if(FontMappings.fontSubstitutionTable!=null && !isEmbedded &&
                    pdfObject.getParameterConstant(PdfDictionary.Subtype)!=StandardFonts.TYPE3){

                String rawFont;

                if(descendantFont==null)
                    rawFont=pdfObject.getName(PdfDictionary.BaseFont);
                else
                    rawFont=descendantFont.getName(PdfDictionary.BaseFont);

                if(rawFont==null)
                    rawFont=pdfObject.getName(PdfDictionary.Name);

                if(rawFont==null)
                    rawFont=font_id;


                if(rawFont.indexOf('#')!=-1)
                    rawFont= StringUtils.convertHexChars(rawFont);

                //save in case we need later
                rawFontName=rawFont;

                baseFont=(rawFont).toLowerCase();

                //if(baseFont.startsWith("/"))
                //    baseFont=baseFont.substring(1);


                //strip any postscript
                int pointer=baseFont.indexOf('+');
                if(pointer==6)
                    baseFont=baseFont.substring(7);

                String testFont=baseFont, nextSubType;

                subFont=(String) FontMappings.fontSubstitutionLocation.get(testFont);

                String newSubtype=(String)FontMappings.fontSubstitutionTable.get(testFont);

                //do not replace on MAC as default does not have certain values we need
                if(PdfDecoder.isRunningOnMac && testFont.equals("zapfdingbats"))
                    testFont="No match found";

                //check aliases
                if(newSubtype==null){
                    //check for mapping
                    HashMap fontsMapped=new HashMap();
                    String nextFont;
                    while(true){
                        nextFont=(String) FontMappings.fontSubstitutionAliasTable.get(testFont);

                        if(nextFont==null)
                            break;

                        testFont=nextFont;

                        nextSubType=(String)FontMappings.fontSubstitutionTable.get(testFont);

                        if(nextSubType!=null){
                            newSubtype=nextSubType;
                            subFont=(String) FontMappings.fontSubstitutionLocation.get(testFont);
                        }

                        if(fontsMapped.containsKey(testFont)){
                            StringBuilder errorMessage = new StringBuilder("[PDF] Circular font mapping for fonts");
                            Iterator i=fontsMapped.keySet().iterator();
                            while(i.hasNext()){
                                errorMessage.append(' ');
                                errorMessage.append(i.next());
                            }
                            throw new PdfException(errorMessage.toString());
                        }
                        fontsMapped.put(nextFont,"x");
                    }
                }

                if(newSubtype!=null && descendantFont==null){

                    //convert String to correct int value
                    if (newSubtype.equals("/Type1")|| newSubtype.equals("/Type1C")|| newSubtype.equals("/MMType1"))
                        fontType=StandardFonts.TYPE1;
                    else if (newSubtype.equals("/TrueType"))
                        fontType=StandardFonts.TRUETYPE;
                    else if (newSubtype.equals("/Type3"))
                        fontType=StandardFonts.TYPE3;
                    else
                        throw new RuntimeException("Unknown font type "+newSubtype+" used for font substitution");

                    origfontType=pdfObject.getParameterConstant(PdfDictionary.Subtype);

                }else if(PdfDecoder.enforceFontSubstitution){
                    LogWriter.writeLog("baseFont="+baseFont+" fonts added= "+FontMappings.fontSubstitutionTable);
                    throw new PdfFontException("No substitute Font found for font="+baseFont+ '<');
                }
            }

            //get subtype if not set above
            if(fontType==PdfDictionary.Unknown){
                fontType=pdfObject.getParameterConstant(PdfDictionary.Subtype);

                /**handle CID fonts where /Subtype stored inside sub object*/
                if (fontType==StandardFonts.TYPE0) {

                    //get CID type and use in preference to Type0 on CID fonts
                    PdfObject desc=pdfObject.getDictionary(PdfDictionary.DescendantFonts);
                    fontType=desc.getParameterConstant(PdfDictionary.Subtype);

                    origfontType=fontType;

                    //track non-embedded, non-substituted CID fonts
                    if(!isEmbedded && subFont==null) {
                        hasNonEmbeddedCIDFonts=true;

                        //track list
                        if(nonEmbeddedCIDFonts.length()>0)
                            nonEmbeddedCIDFonts.append(',');
                        nonEmbeddedCIDFonts.append(baseFont);
                    }
                }
            }

            if(fontType==PdfDictionary.Unknown){
                LogWriter.writeLog("Font type not supported");

                currentFontData=new PdfFont(currentPdfFile);
            }


            /**
             * check for OpenType fonts and reassign type
             */
            if(fontType==StandardFonts.TYPE1){

                PdfObject FontDescriptor=pdfObject.getDictionary(PdfDictionary.FontDescriptor);
                if(FontDescriptor!=null){

                    PdfObject FontFile3=FontDescriptor.getDictionary(PdfDictionary.FontFile3);
                    if(FontFile3!=null){ //must be present for OTTF font

                        //get data
                        byte[] stream=currentPdfFile.readStream(FontFile3,true,true,false, false,false, FontFile3.getCacheName(currentPdfFile.getObjectDecoder()));

                        //check first 4 bytes
                        if(stream!=null && stream.length>3 && stream[0]==79 && stream[1]==84 && stream[2]==84 && stream[3]==79)
                            fontType=StandardFonts.TRUETYPE; //put it through our TT handler which also does OT

                    }
                }
            }

            try{
                currentFontData=FontFactory.createFont(fontType,currentPdfFile,subFont);

                /**set an alternative to Lucida*/
                if(PdfDecoder.defaultFont!=null)
                    currentFontData.setDefaultDisplayFont(PdfDecoder.defaultFont);

                //some ghostscript T3 fonts can reference Page resources
                if(fontType==StandardFonts.TYPE3)
                    currentFontData.setRes(pageResources);

                currentFontData.createFont(pdfObject, font_id,streamDecoderStatus.renderPage, objectStoreStreamRef, fontsLoaded);

                //save raw version
                currentFontData.setRawFontName(rawFontName);

                //fix for odd file
                if(fontType==StandardFonts.TYPE1 && currentFontData.is1C() && pdfObject.getInt(PdfDictionary.FirstChar)==32 &&
                        pdfObject.getInt(PdfDictionary.FirstChar)==pdfObject.getInt(PdfDictionary.LastChar)){

                    if(isEmbedded){
                        isFontBroken=true;
                        isEmbedded=false;
                    }else{
                        currentFontData.isFontEmbedded=false;
                    }
                }

                //see if we failed and loop round to substitute
                if(!currentFontData.isFontEmbedded && isEmbedded){
                    isFontBroken=true;
                    isEmbedded=false;
                }

            }catch(Exception e){
                LogWriter.writeLog("[PDF] Problem "+e+" reading Font  type "+ StandardFonts.getFontypeAsString(fontType)+" in "+streamDecoderStatus.fileName);

                errorTracker.addPageFailureMessage("Problem " + e + " reading Font type " + StandardFonts.getFontypeAsString(fontType) + " in " + streamDecoderStatus.fileName);
            }
        }

        /**
         * add line giving font info so we can display or user access
         */
        String name=currentFontData.getFontName();

        //deal with odd chars
        if(name.indexOf('#')!=-1)
            name= StringUtils.convertHexChars(name);

        String details;
        if(currentFontData.isFontSubstituted()){
            details=font_id+"  "+name+"  "+StandardFonts.getFontypeAsString(origfontType)+"  Substituted ("+subFont+ ' ' +StandardFonts.getFontypeAsString(fontType)+ ')';
        }else if(currentFontData.isFontEmbedded){
            hasEmbeddedFonts=true;
            if(currentFontData.is1C() && descendantFont==null)
                details=font_id+"  "+name+" Type1C  Embedded";
            else
                details=font_id+"  "+name+"  "+StandardFonts.getFontypeAsString(fontType)+"  Embedded";
        }else
            details=font_id+"  "+name+"  "+StandardFonts.getFontypeAsString(fontType);

        if(fontsInFile==null)
            fontsInFile=details;
        else
            fontsInFile=details+'\n'+fontsInFile;

        return currentFontData;
    }

    /**
     * check for embedded font file to see if font embedded
     */
    private static boolean isFontEmbedded(PdfObject pdfObject) {

        //ensure we are looking in DescendantFonts object if CID
        int fontType=pdfObject.getParameterConstant(PdfDictionary.Subtype);
        if (fontType==StandardFonts.TYPE0)
            pdfObject=pdfObject.getDictionary(PdfDictionary.DescendantFonts);


        PdfObject descFontObj=pdfObject.getDictionary(PdfDictionary.FontDescriptor);


        if(descFontObj==null)
            return false;
        else
            return descFontObj.hasStream();
    }

    public static final boolean debugRes=false;



    /**
     * read page header and extract page metadata
     * @throws PdfException
     */
    public final void readResources(PdfObject Resources,boolean resetList) throws PdfException {

        LogWriter.writeMethod("{readResources}", 0);

        //decode
        String[] names={"ColorSpace","ExtGState","Font", "Pattern","Shading","XObject"};
        int[] keys={PdfDictionary.ColorSpace, PdfDictionary.ExtGState, PdfDictionary.Font,
                PdfDictionary.Pattern, PdfDictionary.Shading,PdfDictionary.XObject};

        for(int ii=0;ii<names.length;ii++){

            if(keys[ii]==PdfDictionary.Font || keys[ii]==PdfDictionary.XObject)
                readArrayPairs(Resources, resetList,keys[ii]);
            else
                readArrayPairs(Resources, false,keys[ii]);
        }
    }

    /**
     *
     *  objects off the page, stitch into a stream and
     * decode and put into our data object. Could be altered
     * if you just want to read the stream
     * @param pdfObject
     * @param pageStream
     * @throws PdfException
     */
    public final T3Size decodePageContent(PdfObject pdfObject, int minX, int minY, GraphicsState newGS, byte[] pageStream) throws PdfException{/* take out min's%%*/

        LogWriter.writeMethod("{decodePageContent}", 0);

        try{
            //		if(DynamicVectorRenderer.textBasedHighlight)
            //			PdfHighlights.setLineAreas(null);

            //check switched off
            streamDecoderStatus.imagesProcessedFully = true;
            isTimeout=false;

            //reset count
            streamDecoderStatus.imageCount=0;
            imagesInFile=null; //also reset here as good point as syncs with font code

            if((!this.renderDirectly)&&(statusBar!=null))
                statusBar.percentageDone=0;

            if(newGS!=null)
                gs = newGS;
            else
                gs = new GraphicsState(minX,minY);/* take out min's%%*/


            //save for later
            if (streamDecoderStatus.renderPage){

                /**
                 * check setup and throw exception if null
                 */
                if(current==null)
                    throw new PdfException("DynamicVectorRenderer not setup PdfStreamDecoder setStore(...) should be called");

                current.drawClip(gs,defaultClip) ;
            }


            //get the binary data from the file
            byte[] b_data = null;

            //reset text state
            currentTextState = new TextState();

            byte[][] pageContents= null;
            if(pdfObject!=null)
                pageContents= pdfObject.getKeyArray(PdfDictionary.Contents);


            //@speed - once converted, lose readPageIntoStream(contents); method
            if(pdfObject!=null && pageContents==null)
                b_data=currentPdfFile.readStream(pdfObject,true,true,false, false,false, pdfObject.getCacheName(currentPdfFile.getObjectDecoder()));
            else if(pageStream!=null)
                b_data=pageStream;
            else
                b_data=readPageIntoStream(pdfObject);

            //if page data found, turn it into a set of commands
            //and decode the stream of commands
            if (b_data!=null && b_data.length > 0) {

                //reset graphics state for each page and flush queue
                //currentGraphicsState.resetCTM();
                decodeStreamIntoObjects(b_data);

            }

            //flush fonts
            if(!isType3Font){
                cache.resetFonts();
            }

            /**fontHandle
             //lose font handles asap
             currentFontData.unsetUnscaledFont();
             currentFontData=null;
             this.releaseResources();
             fonts=null;
             */
            T3Size t3=new T3Size();
            t3.x = T3maxWidth;
            t3.y = T3maxHeight;
            return t3;


        }catch(Error err){


            errorTracker.addPageFailureMessage("Problem decoding page " + err);


        }

        return null;
    }

    /**
     *
     *  just scan for DO and CM to get image sizes so we can work out sampling used
     */
    public final float decodePageContentForImageSampling(PdfObject pdfObject, int minX, int minY, GraphicsState newGS, byte[] pageStream) throws PdfException{/* take out min's%%*/

        LogWriter.writeMethod("{decodePageContent}", 0);

        try{

            //check switched off
            streamDecoderStatus.imagesProcessedFully = true;

            renderDirectly=true;

            //reset count
            streamDecoderStatus.imageCount=0;

            if(newGS!=null)
                gs = newGS;
            else
                gs = new GraphicsState(minX,minY);/* take out min's%%*/

            //get the binary data from the file
            byte[] b_data = null;

            //reset text state
            currentTextState = new TextState();

            byte[][] pageContents= null;
            if(pdfObject!=null)
                pageContents= pdfObject.getKeyArray(PdfDictionary.Contents);

            //@speed - once converted, lose readPageIntoStream(contents); method
            if(pdfObject!=null && pageContents==null)
                b_data=currentPdfFile.readStream(pdfObject,true,true,false, false,false, pdfObject.getCacheName(currentPdfFile.getObjectDecoder()));
            else if(pageStream!=null)
                b_data=pageStream;
            else
                b_data=readPageIntoStream(pdfObject);

            //if page data found, turn it into a set of commands
            //and decode the stream of commands
            if (b_data!=null && b_data.length > 0) {

                streamDecoderStatus.getSamplingOnly=true;
                //reset graphics state for each page and flush queue
                //currentGraphicsState.resetCTM();
                decodeStreamIntoObjects(b_data);


            }

            //flush fonts
            cache.resetFonts();

            streamDecoderStatus.getSamplingOnly=false;

            return streamDecoderStatus.samplingUsed;


        }catch(Error err){

            streamDecoderStatus.getSamplingOnly=false;

            errorTracker.addPageFailureMessage("Problem decoding page " + err);
        }

        return -1;
    }

    public final void decodeStreamIntoObjects(byte[] characterStream){
        decodeStreamIntoObjects(characterStream, false);
    }

    /**
     * decode the actual 'Postscript' stream into text and images by extracting
     * commands and decoding each.
     */
    public final String decodeStreamIntoObjects(byte[] characterStream,boolean returnText) {

        LogWriter.writeMethod("{decodeStreamIntoObjects}", 0);

        textDecoder.setReturnText(returnText);

        final boolean debug=false;

        long startTime=System.currentTimeMillis();

        int count=prefixes.length;
        int start=0,end=0;
        int sLen=characterStream.length;

        if(!renderDirectly && statusBar!=null){
            statusBar.percentageDone=0;
            statusBar.resetStatus("stream");
        }

        int streamSize=characterStream.length;
        int dataPointer = 0,startCommand=0; //reset

        if(streamSize==0)
            return null;

        int current=0,nextChar=characterStream[0],commandID=-1;

        /**
         * loop to read stream and decode
         */
        while (true) {

            //allow user to request exit and fail page
            if(requestTimeout || (timeoutInterval!=-1 && System.currentTimeMillis()-startTime >timeoutInterval)){
                requestTimeout =false;
                timeoutInterval=-1;
                isTimeout=true;

                break;
            }

            if(!renderDirectly && statusBar!=null)
                statusBar.percentageDone=(90*dataPointer)/streamSize;

            current=nextChar;

            if(current==13 || current==10 || current==32 || current==9){

                dataPointer++;

                while(true){ //read next valid char

                    if(dataPointer==streamSize) //allow for end of stream
                        break;

                    current =characterStream[dataPointer];

                    if(current!=13 && current!=10 && current!=32 && current!=9)
                        break;

                    dataPointer++;

                }
            }


            if(dataPointer==streamSize) //allow for end of stream
                break;

            /**
             * read in value (note several options)
             */
            boolean matchFound=false;
            int type=0;

            if(current==60 && characterStream[dataPointer+1]==60) //look for <<
                type=1;
            else if(current==91) //[
                type=2;
            else if(current>=97 && current<=122) //lower case alphabetical a-z
                type=3;
            else if(current>=65 && current<=90) //upper case alphabetical A-Z
                type=3;
            else if(current==39 || current==34) //not forgetting the non-alphabetical commands '\'-'\"'/*
                type=3;
            else if(current==32)
                type=4;
            else
                type=0;

            if(debug)
                System.out.println("Char="+(char)current+" type="+type);

            if(type==3){ //option - its an aphabetical so may be command or operand values

                start=dataPointer;

                while(true){ //read next valid char

                    dataPointer++;
                    if((dataPointer)>=sLen) //trap for end of stream
                        break;

                    current = characterStream[dataPointer];
                    //return,space,( / or [
                    if (current == 13 || current == 10 || current == 32 || current == 40 || current == 47 || current == 91 || current == 9 || current=='<')
                        break;

                }

                end=dataPointer-1;

                if(end>=sLen)
                    break;

                //move back if ends with / or [
                int endC=characterStream[end];
                if(endC==47 || endC==91 || endC=='<')
                    end--;

                //see if command
                commandID=-1;
                if(end-start<3){ //no command over 3 chars long
                    //@turn key into ID.
                    //convert token to int
                    int key=0,x=0;
                    for(int i2=end;i2>start-1;i2--){
                        key=key+(characterStream[i2]<<x);
                        x=x+8;
                    }
                    commandID=Cmd.getCommandID(key);
                }

                /**
                 * if command execute otherwise add to stack
                 */
                if (commandID==-1) {

                    opStart[currentOp]=start;
                    opEnd[currentOp]=end;


                    currentOp++;
                    if (currentOp == this.MAXOPS)
                        currentOp = 0;
                    operandCount++;
                }else{


                    //showCommands=(tokenNumber>6300);
                    //this makes rest of page disappear
                    //	if(tokenNumber>300)
                    	//		break;



                    try {
                        dataPointer = processToken(commandID,characterStream,startCommand, dataPointer);
                        startCommand=dataPointer;
                    } catch (Exception e) {

                        LogWriter.writeLog("[PDF] "+ e);
                        LogWriter.writeLog("Processing token >" + Cmd.getCommandAsString(commandID)
                                + "<>" + streamDecoderStatus.fileName+" <"+pageNum);

                    } catch (OutOfMemoryError ee) {
                        errorTracker.addPageFailureMessage("Memory error decoding token stream");
                        LogWriter.writeLog("[MEMORY] Memory error - trying to recover");
                    }

                    currentOp=0;
                    operandCount=0;
                }
            }else if(type!=4){

                start=dataPointer;

                //option  << values >>
                //option  [value] and [value (may have spaces and brackets)]
                if(type==1 || type==2){

                    boolean inStream=false;
                    matchFound=true;

                    int last=32;  // ' '=32

                    while(true){ //read rest of chars

                        if(last==92 && current==92) //allow for \\  \\=92
                            last=120;  //'x'=120

                        else
                            last = current;

                        dataPointer++; //roll on counter

                        if(dataPointer==sLen) //allow for end of stream
                            break;

                        //read next valid char, converting CR to space
                        current = characterStream[dataPointer];
                        if(current==13 || current==10 || current==9)
                            current=32;

                        //exit at end
                        boolean isBreak=false;


                        if(current==62 && last==62 &&(type==1))  //'>'=62
                            isBreak=true;

                        if(type==2){
                            //stream flags
                            if((current==40)&&(last!=92)) 	//'('=40 '\\'=92
                                inStream=true;
                            else if((current==41)&&(last!=92))
                                inStream=false;

                            //exit at end
                            if (!inStream && current==93 && last != 92)	//']'=93
                                isBreak=true;
                        }

                        if(isBreak)
                            break;
                    }

                    end=dataPointer;
                }

                if(!matchFound){ //option 3 other braces

                    int last=32;
                    for(int startChars=0;startChars<count;startChars++){

                        if(current==prefixes[startChars]){
                            matchFound=true;

                            start=dataPointer;

                            int numOfPrefixs=0;//counts the brackets when inside a text stream
                            while(true){ //read rest of chars

                                if((last==92) &&(current==92)) //allow for \\ '\\'=92
                                    last=120; //'x'=120
                                else
                                    last = current;
                                dataPointer++; //roll on counter

                                if(dataPointer==sLen)
                                    break;
                                current = characterStream[dataPointer]; //read next valid char, converting CR to space
                                if(current==13 || current==10 || current==9)
                                    current=32;

                                if(current ==prefixes[startChars] && last!=92) // '\\'=92
                                    numOfPrefixs++;

                                if ((current == suffixes[startChars])&& (last != 92)){ //exit at end  '\\'=92
                                    if(numOfPrefixs==0)
                                        break;
                                    else{
                                        numOfPrefixs--;

                                    }
                                }
                            }
                            startChars=count; //exit loop after match
                        }
                    }
                    end=dataPointer;
                }

                //option 2 -its a value followed by a deliminator (CR,space,/)
                if(!matchFound){

                    if(debug)
                        System.out.println("Not type 2");

                    start=dataPointer;
                    int firstChar=characterStream[start];

                    while(true){ //read next valid char
                        dataPointer++;
                        if((dataPointer)==sLen) //trap for end of stream
                            break;

                        current = characterStream[dataPointer];
                        if (current == 13 || current == 10 || current == 32 || current == 40 || current == 47 || current == 91 || current==9 || (firstChar=='/' && current=='<'))
                            //							// '('=40	'/'=47  '['=91
                            break;

                    }

                    end=dataPointer;

                    if(debug)
                        System.out.println("end="+end);
                }

                if(debug)
                    System.out.println("stored start="+start+" end="+end);

                if(end<characterStream.length){
                    int next=characterStream[end];
                    if(next==47 || next==91)
                        end--;
                }

                opStart[currentOp]=start;
                opEnd[currentOp]=end;


                currentOp++;
                if (currentOp == this.MAXOPS)
                    currentOp = 0;
                operandCount++;

            }

            //increment pointer
            if(dataPointer < streamSize){

                nextChar=characterStream[dataPointer];
                if(nextChar != 47 && nextChar != 40 && nextChar!= 91  && nextChar!= '<'){
                    dataPointer++;
                    if(dataPointer<streamSize)
                        nextChar=characterStream[dataPointer];
                }
            }

            //break at end
            if ((streamSize <= dataPointer))
                break;
        }


        if(!renderDirectly && statusBar!=null)
            statusBar.percentageDone=100;



            return "";
    }

    ////////////////////////////////////////////////////////////////////////
    private void d1(float urX,float llX,float wX,float urY,float llY,float wY) {

        //flag to show we use text colour or colour in stream
        ignoreColors=true;

        /**/
        //not fully implemented
        //float urY = Float.parseFloat(generateOpAsString(0,characterStream));
        //float urX = Float.parseFloat(generateOpAsString(1,characterStream));
        //float llY = Float.parseFloat(generateOpAsString(2,characterStream));
        //float llX = Float.parseFloat(generateOpAsString(3,characterStream));
        //float wY = Float.parseFloat(generateOpAsString(4,characterStream));
        //float wX = Float.parseFloat(generateOpAsString(5,characterStream));
        /***/

        //this.minX=(int)llX;
        //this.minY=(int)llY;

        //currentGraphicsState = new GraphicsState(0,0);/*remove values on contrutor%%*/

        //setup image to draw on
        //current.init((int)(wX),(int)(urY-llY+1));

        //wH=urY;
        //wW=llX;

        T3maxWidth=(int)wX;
        if(wX==0)
            T3maxWidth=(int)(llX-urX);
        else
            T3maxWidth=(int)wX; //Float.parseFloat(generateOpAsString(5,characterStream));

        T3maxHeight=(int)wY;
        if(wY==0)
            T3maxHeight=(int)(urY-llY);
        else
            T3maxHeight=(int)wY; //Float.parseFloat(generateOpAsString(5,characterStream));

        /***/
    }
    ////////////////////////////////////////////////////////////////////////
    private void d0(int w,int y) {

        //flag to show we use text colour or colour in stream
        ignoreColors=false;

        //float glyphX = Float.parseFloat((String) operand.elementAt(0));
        T3maxWidth=w;
        T3maxHeight=y;

        //setup image to draw on
        //current.init((int)glyphX,(int)glyphY);

    }
    ////////////////////////////////////////////////////////////////////////
    private void TD(boolean isLowerCase,float x,float y) {

        relativeMove(x, y);

        if (!isLowerCase) { //set leading as well
            float TL = -y;
            currentTextState.setLeading(TL);
        }
        textDecoder.reset();


    }
    ///////////////////////////////////////////////////////////////////
    /**
     * get postscript data (which may be split across several objects)
     */
    public byte[] readPageIntoStream(PdfObject pdfObject){

        LogWriter.writeMethod("{readPageIntoStream}", 0);

        byte[][] pageContents= pdfObject.getKeyArray(PdfDictionary.Contents);

        //reset buffer object
        byte[] binary_data = new byte[0];

        //exit on empty
        if(pageContents==null || (pageContents!=null && pageContents.length>0 && pageContents[0]==null))
            return binary_data;

        /**read an array*/
        if(pageContents!=null){

            int count=pageContents.length;

            byte[] decoded_stream_data=null;
            PdfObject streamData;

            //read all objects for page into stream
            for(int ii=0;ii<count;ii++) {

                //if(pageContents[ii].length==0)
                //	break;

                //get the data for an object
                //currentPdfFile.resetCache();
                //decoded_stream_data =currentPdfFile.readStream(new String(pageContents[ii]),true);

                streamData=new StreamObject(new String(pageContents[ii]));
                streamData.isDataExternal(pdfObject.isDataExternal());//flag if being read from external stream
                currentPdfFile.readObject(streamData);

                decoded_stream_data=streamData.getDecodedStream();

                //System.out.println(decoded_stream_data+" "+OLDdecoded_stream_data);
                if(ii==0 && decoded_stream_data!=null)
                    binary_data=decoded_stream_data;
                else
                    binary_data = appendData(binary_data, decoded_stream_data);
            }
        }

        return binary_data;
    }

    /**
     * append into data_buffer by copying processed_data then
     * binary_data into temp and then temp back into binary_data
     */
    private static byte[] appendData(byte[] binary_data, byte[] decoded_stream_data) {

        if (decoded_stream_data != null){
            int current_length = binary_data.length + 1;

            //find end of our data which we decompressed.
            int processed_length = decoded_stream_data.length;
            if (processed_length > 0) { //trap error
                while (decoded_stream_data[processed_length - 1] == 0)
                    processed_length--;

                //put current into temp so I can resize array
                byte[] temp = new byte[current_length];
                System.arraycopy(binary_data,0, temp,0, current_length - 1);

                //add a space between streams
                temp[current_length - 1] =  ' ';

                //resize
                binary_data = new byte[current_length + processed_length];

                //put original data back
                System.arraycopy(temp, 0, binary_data, 0, current_length);

                //and add in new data
                System.arraycopy(decoded_stream_data,0,binary_data,current_length,processed_length);
            }
        }
        return binary_data;
    }

    /**
     * convert to to String
     */
    private String generateOpAsString(int p,byte[] dataStream, boolean loseSlashPrefix) {

        String s="";

        int start=this.opStart[p];

        //remove / on keys
        if(loseSlashPrefix && dataStream[start]==47)
            start++;

        int end=this.opEnd[p];

        //lose spaces or returns at end
        while((dataStream[end]==32)||(dataStream[end]==13)||(dataStream[end]==10))
            end--;

        int count=end-start+1;

        //discount duplicate spaces
        int spaces=0;
        for(int ii=0;ii<count;ii++){
            if((ii>0)&&((dataStream[start+ii]==32)||(dataStream[start+ii]==13)||(dataStream[start+ii]==10))&&
                    ((dataStream[start+ii-1]==32)||(dataStream[start+ii-1]==13)||(dataStream[start+ii-1]==10)))
                spaces++;
        }

        char[] charString=new char[count-spaces];
        int pos=0;

        for(int ii=0;ii<count;ii++){
            if((ii>0)&&((dataStream[start+ii]==32)||(dataStream[start+ii]==13)||(dataStream[start+ii]==10))&&
                    ((dataStream[start+ii-1]==32)||(dataStream[start+ii-1]==13)||(dataStream[start+ii-1]==10)))
            {
            }else{
                if((dataStream[start+ii]==10)||(dataStream[start+ii]==13))
                    charString[pos]=' ';
                else
                    charString[pos]=(char)dataStream[start+ii];
                pos++;
            }
        }

        s=String.copyValueOf(charString);

        return s;

    }

    ////////////////////////////////////////////////////
    private void BT() {

        //set values used in plot
        currentTextState.resetTm();

        //keep position in case we need
        currentTextState.setTMAtLineStart();

        //currentGraphicsState.setClippingShape(null);

        //font info
        currentFont = currentTextState.getFontName();
        currentTextState.setCurrentFontSize(0);
        lastFontSize=-1;

        //currentGraphicsState.setLineWidth(0);

        //save for later and set TR
        if (streamDecoderStatus.renderPage){

            current.drawClip(gs,defaultClip) ;

            current.drawTR(GraphicsState.FILL);
            //current.setLineWidth(0);
            //  current.drawColor((Color)currentGraphicsState.getNonstrokeColor(),GraphicsState.FILL);
            //   current.drawColor((Color)currentGraphicsState.getStrokeColor(),GraphicsState.STROKE);

            //flag text block started
            current.flagCommand(Cmd.BT);

        }
    }

    //////////////////////////////////////////////////////////
    /**
     * restore GraphicsState status from graphics stack
     */
    private void restoreGraphicsState() {

        if(!isStackInitialised){

            LogWriter.writeLog("No GraphicsState saved to retrieve");

        }else{

            //see if clip changed
            boolean hasClipChanged=gs.hasClipChanged();

            gs = (GraphicsState) graphicsStateStack.pull();
            currentTextState = (TextState) textStateStack.pull();

            //@remove all caching?
            gs.strokeColorSpace=(GenericColorSpace) strokeColorStateStack.pull();
            gs.nonstrokeColorSpace=(GenericColorSpace) nonstrokeColorStateStack.pull();

            if(gs.strokeColorSpace.getID()==ColorSpaces.Separation)
                gs.strokeColorSpace.restoreColorStatus();

            if(gs.nonstrokeColorSpace.getID()==ColorSpaces.Separation)
                gs.nonstrokeColorSpace.restoreColorStatus();

            //20101122 removed by MS as not apparently needed
            //Object currentClip=clipStack.pull();


            /**
             if(hasClipChanged){
             //if(!renderDirectly && hasClipChanged){
             if(currentClip==null){

             if(gs.current_clipping_shape!=null){
             System.out.println("1shape="+gs.current_clipping_shape);
             throw new RuntimeException();
             }
             gs.setClippingShape(null);
             }else{

             if(!gs.current_clipping_shape.equals((Area)currentClip)){
             System.out.println("2shape="+gs.current_clipping_shape);
             //  throw new RuntimeException();
             }
             gs.setClippingShape((Area)currentClip);
             }
             }
             /**/
            ////////////////////////////////////

            //copy last CM
            for(int i=0;i<3;i++)
                System.arraycopy(gs.CTM, 0, gs.lastCTM, 0, 3);

            //save for later
            if (streamDecoderStatus.renderPage){

                nonStrokeAlpha=gs.getNonStrokeAlpha();
                strokeAlpha=gs.getStrokeAlpha();

                if(hasClipChanged)
                    current.drawClip(gs,defaultClip) ;

                current.resetOnColorspaceChange();

                current.drawFillColor(gs.getNonstrokeColor());
                current.drawStrokeColor(gs.getStrokeColor());

                /**
                 * align display
                 */
                current.setGraphicsState(GraphicsState.FILL,nonStrokeAlpha);
                current.setGraphicsState(GraphicsState.STROKE,strokeAlpha);

                //current.drawTR(currentGraphicsState.getTextRenderType()); //reset TR value

            }


        }
    }
    ///////////////////////////////////////////////////////////////////////
    private void L(float x,float y) {
        currentDrawShape.lineTo(x,y);
    }
    ///////////////////////////////////////////////////////////////////////
    private void F(boolean isStar) {

        if(removeRenderImages)
            return;

        //if(gs.notMask)
        //      return;

        //ignore transparent white if group set
        if(formLevel>0 && groupObj!=null && !groupObj.getBoolean(PdfDictionary.K) && TTtopLevelNonStrokeAlpha>0.84f && (gs.nonstrokeColorSpace.getID() == ColorSpaces.DeviceCMYK)){
            // && operand[0]==0 && operand[1]==0 &&
            //		operand[2]==0 && operand[3]==0){

            PdfArrayIterator BMvalue = gs.getBM();

            //check not handled elsewhere
            int firstValue=PdfDictionary.Unknown;
            if(BMvalue !=null && BMvalue.hasMoreTokens()) {
                firstValue= BMvalue.getNextValueAsConstant(false);
            }


            //if(firstValue==PdfDictionary.Multiply)
            //System.out.println(gs.SMask+" >> "+gs.SMask.getObjectRefAsString() +" "+this.topLevelNonStrokeAlpha+" "+this.topLevelStrokeAlpha+" "+this.strokeAlpha+" "+this.nonStrokeAlpha);

            if(gs.nonstrokeColorSpace.getColor().getRGB()==-1 || (firstValue==PdfDictionary.Multiply && nonStrokeAlpha==1f))
                return;
        }

        if(isLayerVisible){

            //set Winding rule
            if (isStar){
                currentDrawShape.setEVENODDWindingRule();
            }else
                currentDrawShape.setNONZEROWindingRule();

            currentDrawShape.closeShape();

            //generate shape and stroke and status
            Shape currentShape =
                    currentDrawShape.generateShapeFromPath(gs.getClippingShape(),
                            gs.CTM,
                            isClip, true,gs.nonstrokeColorSpace.getColor(),
                            gs.getLineWidth(),pageData.getCropBoxWidth(1));


            //simulate overPrint - may need changing to draw at back of stack
            if(gs.nonstrokeColorSpace.getID()==ColorSpaces.DeviceCMYK && gs.getOPM()==1.0f){

                PdfArrayIterator BMvalue = gs.getBM();

                //check not handled elsewhere
                int firstValue=PdfDictionary.Unknown;
                if(BMvalue !=null && BMvalue.hasMoreTokens()) {
                    firstValue= BMvalue.getNextValueAsConstant(false);
                }

                if(firstValue==PdfDictionary.Multiply){

                    float[] rawData=gs.nonstrokeColorSpace.getRawValues();

                    if(rawData!=null && rawData[3]==1){

                        //try to keep as binary if possible
                        //boolean hasObjectBehind=current.hasObjectsBehind(gs.CTM);
                        //if(hasObjectBehind){
                        currentShape=null;
                        //}
                    }
                }
            }


            if(currentShape!=null && gs.nonstrokeColorSpace.getID()==ColorSpaces.ICC && gs.getOPM()==1.0f){

                PdfArrayIterator BMvalue = gs.getBM();

                //check not handled elsewhere
                int firstValue=PdfDictionary.Unknown;
                if(BMvalue !=null && BMvalue.hasMoreTokens()) {
                    firstValue= BMvalue.getNextValueAsConstant(false);
                }

                if(firstValue==PdfDictionary.Multiply){

                    float[] rawData=gs.nonstrokeColorSpace.getRawValues();

                    /**if(rawData!=null && rawData[2]==1){

                     //try to keep as binary if possible
                     boolean hasObjectBehind=current.hasObjectsBehind(gs.CTM);
                     if(hasObjectBehind)
                     currentShape=null;
                     }else*/{ //if zero just remove
                        int elements=rawData.length;
                        boolean isZero=true;
                        for(int ii=0;ii<elements;ii++)
                            if(rawData[ii]!=0)
                                isZero=false;

                        if(isZero)
                            currentShape=null;
                    }
                }
            }


            //do not paint white CMYK in overpaint mode
            if(currentShape!=null && gs.getNonStrokeAlpha()<1 && gs.nonstrokeColorSpace.getID()==ColorSpaces.DeviceN && gs.getOPM()==1.0f && gs.nonstrokeColorSpace.getColor().getRGB()==-16777216 ){

                //System.out.println(gs.getNonStrokeAlpha());
                //System.out.println(nonstrokeColorSpace.getAlternateColorSpace()+" "+nonstrokeColorSpace.getColorComponentCount()+" "+nonstrokeColorSpace.pantoneName);
                boolean ignoreTransparent =true; //assume true and disprove
                float[] raw=gs.nonstrokeColorSpace.getRawValues();

                if(raw!=   null){
                    int count=raw.length;
                    for(int ii=0;ii<count;ii++){

                        //System.out.println(ii+"="+raw[ii]+" "+count);

                        if(raw[ii]>0){
                            ignoreTransparent =false;
                            ii=count;
                        }
                    }
                }

                if(ignoreTransparent){
                    currentShape=null;
                }
            }

            //save for later
            if (currentShape!=null && streamDecoderStatus.renderPage){

                gs.setStrokeColor( gs.strokeColorSpace.getColor());
                gs.setNonstrokeColor(gs.nonstrokeColorSpace.getColor());
                gs.setFillType(GraphicsState.FILL);

                float mainstrokeAlpha=gs.getStrokeAlpha();
                gs.setStrokeAlpha(strokeAlpha);

                float mainnonstrokeAlpha=gs.getNonStrokeAlpha();
                gs.setNonStrokeAlpha(nonStrokeAlpha);

                current.drawShape( currentShape,gs);

                gs.setStrokeAlpha(mainstrokeAlpha);
                gs.setNonStrokeAlpha(mainnonstrokeAlpha);

            }
        }
        //always reset flag
        isClip = false;
        currentDrawShape.resetPath(); // flush all path ops stored

    }
    ////////////////////////////////////////////////////////////////////////
    private void TC(float tc) {
        currentTextState.setCharacterSpacing(tc);
    }
    ////////////////////////////////////////////////////////
    private void CM(float[][] Trm) {


        //copy last CM
        for(int i=0;i<3;i++)
            System.arraycopy(gs.CTM, 0, gs.lastCTM, 0, 3);

        //multiply to get new CTM
        gs.CTM =Matrix.multiply(Trm, gs.CTM);

        //remove slight sheer
        if(gs.CTM[0][0]>0 && gs.CTM[1][1]>0 && gs.CTM[1][0]>0 && gs.CTM[1][0]<0.01 && gs.CTM[0][1]<0){
            gs.CTM[0][1]=0;
            gs.CTM[1][0]=0;
        }

        textDecoder.reset();

    }
    ////////////////////////////////////////////////////////////////////////
    /**
     * used by TD and T* to move current co-ord
     */
    final void relativeMove(float new_x, float new_y) {

        //create matrix to update Tm
        float[][] temp = new float[3][3];

        currentTextState.Tm = currentTextState.getTMAtLineStart();

        //set Tm matrix
        temp[0][0] = 1;
        temp[0][1] = 0;
        temp[0][2] = 0;
        temp[1][0] = 0;
        temp[1][1] = 1;
        temp[1][2] = 0;
        temp[2][0] = new_x;
        temp[2][1] = new_y;
        temp[2][2] = 1;

        //multiply to get new Tm
        currentTextState.Tm = Matrix.multiply(temp, currentTextState.Tm);

        currentTextState.setTMAtLineStart();

        if(currentRotation!=0){
            //create matrix to update Tm
            float[][] temp2 = new float[3][3];

            currentTextState.TmNoRotation = currentTextState.getTMAtLineStartNoRotation();

            //set Tm matrix
            temp2[0][0] = 1;
            temp2[0][1] = 0;
            temp2[0][2] = 0;
            temp2[1][0] = 0;
            temp2[1][1] = 1;
            temp2[1][2] = 0;
            temp2[2][0] = new_x;
            temp2[2][1] = new_y;
            temp2[2][2] = 1;

            //multiply to get new Tm
            currentTextState.TmNoRotation = Matrix.multiply(temp2, currentTextState.TmNoRotation);

            float plusX=new_x,plusY=new_y;
            if(plusX<0)
                plusX=-new_x;
            if(plusY<0)
                plusY=-new_y;

            //if new object, recalculate
            if(plusX>currentTextState.Tm[0][0] && plusY>currentTextState.Tm[1][1])
                convertToUnrotated(currentTextState.Tm);

            currentTextState.setTMAtLineStartNoRotation();

        }

        //move command
        moveCommand = 2; //0=t*, 1=Tj, 2=TD
    }

    /**
     * remove rotation on matrix and set unrotated
     */
    private void convertToUnrotated(float[][] trm) {

        final boolean showCommands=false;

        if(showCommands){
            System.out.println("------------original value--------------");
            Matrix.show(trm);
        }

        //now we have it, apply to trm to turn back

        //note we convert radians to degrees - ignore if slight
        if(trm[0][1]==0 || trm[1][0]==0)
            return;

        rotationAsRadians=-Math.asin(trm[1][0]/trm[0][0]);


        //build transformation matrix by hand to avoid errors in rounding
        float[][] rotation = new float[3][3];
        rotation[0][0] = (float) Math.cos(-rotationAsRadians);
        rotation[0][1] = (float) Math.sin(-rotationAsRadians);
        rotation[0][2] = 0;
        rotation[1][0] = (float) -Math.sin(-rotationAsRadians);
        rotation[1][1] = (float) Math.cos(-rotationAsRadians);
        rotation[1][2] = 0;
        rotation[2][0] = 0;
        rotation[2][1] = 0;
        rotation[2][2] = 1;

        //round numbers if close to 1
        for (int yy = 0; yy < 3; yy++) {
            for (int xx = 0; xx < 3; xx++) {
                if ((rotation[xx][yy] > .99) & (rotation[xx][yy] < 1))
                    rotation[xx][yy] = 1;
            }
        }

        //matrix for corner
        float[][] pt=new float[3][3];
        pt[0][0]=trm[2][0];//+trm[0][1];
        pt[1][1]=trm[2][1];//+trm[1][0];
        pt[2][2]=1;

        if(showCommands){
            System.out.println("---------------------pt before-----------rotation="+currentRotation+" radians="+rotationAsRadians);
            Matrix.show(pt);
        }

        pt=Matrix.multiply(rotation,pt);

        if(showCommands){
            System.out.println("---------------------pt--------------------------"+(pt[1][0]+pt[1][1]));
            Matrix.show(pt);
        }
        //apply to trm

        if(showCommands){
            System.out.println("====================before====================rotation="+currentRotation+" radians="+rotationAsRadians);
            //			Matrix.show(trm);
        }
        float[][] unrotatedTrm=Matrix.multiply(rotation,trm);

        //put onto start of line
        float diffY=pt[1][0];
        float newY=pt[1][1]-diffY;
        float convertedY=currentTextState.Tm[2][1];
        Integer key=new Integer((int)(newY+.5));
        Float mappedY=(Float)lines.get(key);

        //allow for fp error
        if(mappedY==null)
            mappedY=(Float)lines.get(new Integer((int)(newY+1)));


        if(mappedY==null){
            lines.put(key,new Float(currentTextState.Tm[2][1]));

            //if(currentTextState.Tm[2][0]>1200)
            //        System.out.println(mappedY+" "+newY+" "+key+" "+lines.keySet());

        }else{
            convertedY=mappedY.floatValue();

        }

        unrotatedTrm[2][1]=convertedY;

        currentTextState.TmNoRotation=unrotatedTrm;

        //adjust matrix so all on same line if on same line
        float rotatedY;
        float lastHeight = -1;
        if(unRotatedY ==-1){
            //track last line
            unRotatedY =currentTextState.TmNoRotation[2][1];
            rotatedY =currentTextState.Tm[2][1];

            //currentTextState.TmNoRotation[2][1]= rotatedY;
        }else if(1==2){
            float diff= unRotatedY -(currentTextState.TmNoRotation[2][1]);
            if(diff<0)
                diff=-diff;

            if(showCommands)
                System.out.println("diff="+diff+" currentTextState.TmNoRotation[1][1]="+currentTextState.TmNoRotation[1][1]);

            if(diff<currentTextState.TmNoRotation[1][1]){

                float diffH=lastHeight-currentTextState.TmNoRotation[1][1];
                if(diffH<0)
                    diffH=-diffH;

                if(diffH<2){
                    unRotatedY =currentTextState.TmNoRotation[2][1];

                    currentTextState.TmNoRotation[2][1]= rotatedY;
                    if(showCommands)
                        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>set to "+ rotatedY);
                }
            } else{
                unRotatedY =currentTextState.TmNoRotation[2][1];
                rotatedY =currentTextState.Tm[2][1];

                if(showCommands)
                    System.out.println(">>>>>>>reset to "+ rotatedY + ' '+unRotatedY);
            }
        }

        lastHeight=currentTextState.TmNoRotation[1][1];
        currentTextState.TmNoRotation[0][1]=0;
        currentTextState.TmNoRotation[1][0]=0;

        if(showCommands)
            Matrix.show(currentTextState.TmNoRotation);

        /**
         if(tokenNumber>3514)
         showCommands=false;
         else
         showCommands=true;
         /**/
    }

    ////////////////////////////////////////////////////////////////////////
    private void S(boolean isLowerCase) {

        if(removeRenderImages)
            return;

        if(isLayerVisible){

            //close for s command
            if (isLowerCase)
                currentDrawShape.closeShape();

            Shape currentShape =
                    currentDrawShape.generateShapeFromPath( null,
                            gs.CTM,
                            isClip,false,null,
                            gs.getLineWidth(),pageData.getCropBoxWidth(1));


            //simulate overPrint - may need changing to draw at back of stack
            if(1==2 && !isLowerCase && gs.strokeColorSpace.getID()==ColorSpaces.DeviceCMYK && gs.getOPM()==1.0f){

                PdfArrayIterator BMvalue = gs.getBM();

                //check not handled elsewhere
                int firstValue=PdfDictionary.Unknown;
                if(BMvalue !=null && BMvalue.hasMoreTokens()) {
                    firstValue= BMvalue.getNextValueAsConstant(false);
                }


                if(firstValue==PdfDictionary.Normal){// || firstValue==PdfDictionary.Multiply){

                    float[] rawData=gs.strokeColorSpace.getRawValues();

                    if(rawData!=null  && rawData[0]==0  && rawData[1]==0  && rawData[2]==0 && rawData[3]==0){

                        //try to keep as binary if possible
                        //boolean hasObjectBehind=current.hasObjectsBehind(gs.CTM);
                        //if(hasObjectBehind){
                        currentShape=null;
                        //}
                    }
                }
            }

            if(currentShape!=null){ //allow for the odd combination of crop with zero size
                Area crop=gs.getClippingShape();

                if(crop!=null && (crop.getBounds().getWidth()==0 || crop.getBounds().getHeight()==0 ))
                    currentShape=null;
            }

            if(currentShape!=null){ //allow for the odd combination of f then S

                if(currentShape.getBounds().getWidth()<=1){// && currentGraphicsState.getLineWidth()<=1.0f){
                    currentShape=currentShape.getBounds2D();
                    //    System.out.println("XX");
                }

                //				if(currentShape!=null && currentShape.getBounds().getX()>628 && currentShape.getBounds().getX()<630){
                //				System.out.println(currentShape+" "+currentShape.getBounds2D());
                //				Matrix.show(currentGraphicsState.CTM);

                //				}

                //save for later
                if (streamDecoderStatus.renderPage){

                    gs.setStrokeColor( gs.strokeColorSpace.getColor());
                    gs.setNonstrokeColor( gs.nonstrokeColorSpace.getColor());
                    gs.setFillType(GraphicsState.STROKE);

                    float mainstrokeAlpha=gs.getStrokeAlpha();
                    gs.setStrokeAlpha(strokeAlpha);

                    float mainnonstrokeAlpha=gs.getNonStrokeAlpha();
                    gs.setNonStrokeAlpha(nonStrokeAlpha);

                    current.drawShape( currentShape,gs);

                    gs.setStrokeAlpha(mainstrokeAlpha);
                    gs.setNonStrokeAlpha(mainnonstrokeAlpha);
                }
            }
        }

        //always reset flag
        isClip = false;
        currentDrawShape.resetPath(); // flush all path ops stored

    }
    ///////////////////////////////////////////////////////////////////////////
    private void I() {
        //if (currentToken.equals("i")) {
        //int value =
        //	(int) Float.parseFloat((String) operand.elementAt(0));

        //set value
        //currentGraphicsState.setFlatness(value);
        //}
    }

    ////////////////////////////////////////////////////////////
    private void D(byte[] characterStream) {


        String values = ""; //used to combine values

        //and the dash array
        int items = operandCount;

        if(items==1)
            values=generateOpAsString(0,characterStream, false);
        else{
            //concat values
            StringBuilder list = new StringBuilder();
            for (int i = items - 1; i > -1; i--){
                list.append(generateOpAsString(i,characterStream, false));
                list.append(' ');
            }
            values=list.toString();
        }

        //allow for default
        if ((values.equals("[ ] 0 "))|| (values.equals("[]0"))|| (values.equals("[] 0 "))) {
            gs.setDashPhase(0);
            gs.setDashArray(new float[0]);
        } else {

            //get dash pattern
            int pointer=values.indexOf(']');

            String dash=values.substring(0,pointer);
            int phase=(int)Float.parseFloat(values.substring(pointer+1,values.length()).trim());

            //put into dash array
            float[] dash_array = PdfArray.convertToFloatArray(dash);

            for(int aa=0;aa<dash_array.length;aa++){
                // System.out.println(aa+" "+dash_array[aa]);

                if(dash_array[aa]<0.001)
                    dash_array[aa]=0;
            }
            //put array into global value
            gs.setDashArray(dash_array);

            //last value is phase
            gs.setDashPhase(phase);

        }
    }
    ////////////////////////////////////////////////////////////////////////
    private void SCN(boolean isLowerCase,byte[] stream)  {

        float[] values=null;

        if(isLowerCase){

            if(gs.nonstrokeColorSpace.getID()==ColorSpaces.Pattern){
                gs.nonstrokeColorSpace.setColor(getValuesAsString(operandCount,stream),operandCount);
            }else{
                values=getValuesAsFloat(operandCount,stream);

                float[] tempValues=new float[operandCount];
                for(int ii=0;ii<operandCount;ii++)
                    tempValues[operandCount-ii-1]=values[ii];
                values=tempValues;

                //System.out.println(nonstrokeColorSpace);
                gs.nonstrokeColorSpace.setColor(values,operandCount);
            }

            //track colrspace use
            cache.put(PdfObjectCache.ColorspacesUsed,new Integer(gs.nonstrokeColorSpace.getID()),"x");

        }else{
            if(gs.strokeColorSpace.getID()==ColorSpaces.Pattern)
                gs.strokeColorSpace.setColor(getValuesAsString(operandCount,stream),operandCount);
            else{
                values=getValuesAsFloat(operandCount,stream);

                float[] tempValues=new float[operandCount];
                for(int ii=0;ii<operandCount;ii++)
                    tempValues[operandCount-ii-1]=values[ii];
                values=tempValues;

                gs.strokeColorSpace.setColor(values,operandCount);
            }

            //track colrspace use
            cache.put(PdfObjectCache.ColorspacesUsed, new Integer(gs.strokeColorSpace.getID()),"x");


        }
    }

    /***
     * COMMANDS - refer to Adobes pdf manual to
     * see what these commands do
     */
    /////////////////////////////////////////////////
    private void B(boolean isStar,boolean isLowerCase) {

        if(removeRenderImages)
            return;

        if(isLayerVisible){
            //set Winding rule
            if (isStar)
                currentDrawShape.setEVENODDWindingRule();
            else
                currentDrawShape.setNONZEROWindingRule();

            //close for s command
            if (isLowerCase)
                currentDrawShape.closeShape();

            Shape currentShape =
                    currentDrawShape.generateShapeFromPath( null,
                            gs.CTM,
                            isClip,false,null,
                            gs.getLineWidth(),pageData.getCropBoxWidth(1));

            //hack which fixes blocky text on Customers3/demo_3.pdf
            if(currentShape!=null && currentShape.getBounds2D().getWidth()<1 && currentShape.getBounds2D().getHeight()<1){
                return;
            }

            if(!isLowerCase && formLevel > 0 &&  currentShape!=null && gs.getClippingShape()!=null && gs.nonstrokeColorSpace.getID()==ColorSpaces.DeviceCMYK && gs.nonstrokeColorSpace.getColor().getRGB()==-1){

                //System.out.println(currentShape.getPathIterator(null).)
                Area a=gs.getClippingShape();
                a.subtract(new Area(currentShape));
                currentShape=a;


            }


            //save for later
            if (streamDecoderStatus.renderPage && currentShape!=null){

                gs.setStrokeColor(gs.strokeColorSpace.getColor());
                gs.setNonstrokeColor(gs.nonstrokeColorSpace.getColor());

                if(gs.nonstrokeColorSpace.getColor().getRGB()==-16777216 && (gs.getStrokeAlpha()==0)){
                    gs.setFillType(GraphicsState.STROKE);
                }else
                    gs.setFillType(GraphicsState.FILLSTROKE);

                current.drawShape( currentShape,gs) ;

            }
        }
        //always reset flag
        isClip = false;

        currentDrawShape.resetPath(); // flush all path ops stored
    }
    ///////////////////////////////////////////////////////////////////////
    /**handle the M commands*/
    private void mm(int mitre_limit) {

        //handle M command
        gs.setMitreLimit(mitre_limit);

    }

    /**handle the m commands*/
    private void M(float x,float y) {

        //handle m command
        currentDrawShape.moveTo(x, y);


    }
    /////////////////////////////////////////////////////
    private void J(boolean isLowerCase,int value) {

        int style = 0;
        if (!isLowerCase) {

            //map join style
            if (value == 0)
                style = BasicStroke.JOIN_MITER;
            if (value == 1)
                style = BasicStroke.JOIN_ROUND;
            if (value == 2)
                style = BasicStroke.JOIN_BEVEL;

            //set value
            gs.setJoinStyle(style);
        } else {
            //map cap style
            if (value == 0)
                style = BasicStroke.CAP_BUTT;
            if (value == 1)
                style = BasicStroke.CAP_ROUND;
            if (value == 2)
                style = BasicStroke.CAP_SQUARE;

            //set value
            gs.setCapStyle(style);
        }
    }
    ////////////////////////////////////////////////////////////////////////
    private void RG(boolean isLowerCase,byte[] stream)  {

        //ensure color values reset
        current.resetOnColorspaceChange();

        //set flag to show which color (stroke/nonstroke)
        boolean isStroke=!isLowerCase;

        float[] operand=getValuesAsFloat(operandCount,stream);

        float[] tempValues=new float[operandCount];
        for(int ii=0;ii<operandCount;ii++)
            tempValues[operandCount-ii-1]=operand[ii];
        operand=tempValues;

        //set colour
        if(isStroke){
            if (gs.strokeColorSpace.getID() != ColorSpaces.DeviceRGB)
                gs.strokeColorSpace=new DeviceRGBColorSpace();

            gs.strokeColorSpace.setColor(operand,operandCount);

            //track colorspace use
            cache.put(PdfObjectCache.ColorspacesUsed, new Integer(gs.strokeColorSpace.getID()),"x");

        }else{
            if (gs.nonstrokeColorSpace.getID() != ColorSpaces.DeviceRGB)
                gs.nonstrokeColorSpace=new DeviceRGBColorSpace();

            gs.nonstrokeColorSpace.setColor(operand,operandCount);

            //track colrspace use
            cache.put(PdfObjectCache.ColorspacesUsed,new Integer(gs.nonstrokeColorSpace.getID()),"x");

        }
    }
    ////////////////////////////////////////////////////////////////////////
    private void Y(float x3,float y3,float x,float y) {
        currentDrawShape.addBezierCurveY(x, y, x3, y3);
    }
    ////////////////////////////////////////////////////////////////////////
    private void TZ(float tz) {

        //Text height
        currentTextState.setHorizontalScaling(tz / 100);
    }
    ////////////////////////////////////////////////////////////////////////
    private void RE(float x,float y,float w,float h) {
        /**
         if(h<0){

         System.out.println("before="+y+" "+h);
         y=y+h;
         h=-h;
         System.out.println("after="+y+" "+h);
         }

         if(w<0){
         x=x+w;
         w=-w;
         }
         /**/


        //get values
        currentDrawShape.appendRectangle(x, y, w, h);
    }
    //////////////////////////////////////////////////////////////////////
    private void ET() {

        //currentGraphicsState.setLineWidth(0);
        //current.setLineWidth(0);

        current.resetOnColorspaceChange();

    }
    ////////////////////////////////////////////////////////////////////////
    /**
     * put item in graphics stack
     */
    private void pushGraphicsState() {

        if(!isStackInitialised){
            isStackInitialised=true;

            graphicsStateStack = new Vector_Object(10);
            textStateStack = new Vector_Object(10);
            strokeColorStateStack= new Vector_Object(20);
            nonstrokeColorStateStack= new Vector_Object(20);
            //clipStack=new Vector_Object(20);
        }

        //store
        graphicsStateStack.push(gs.clone());

        //store clip
        //		Area currentClip=gs.getClippingShape();
        //		if(currentClip==null)
        //			clipStack.push(null);
        //		else{
        //			clipStack.push(currentClip.clone());
        //		}
        //store text state (technically part of gs)
        textStateStack.push(currentTextState.clone());

        //save colorspaces
        nonstrokeColorStateStack.push(gs.nonstrokeColorSpace.clone());
        strokeColorStateStack.push(gs.strokeColorSpace.clone());

        current.resetOnColorspaceChange();

    }

    private void MP() {

        //<start-adobe><start-me>
        if(markedContentExtracted)
            contentHandler.MP();
        //<end-me><end-adobe>

    }

    private void DP(int startCommand, int dataPointer,byte[] raw,String op) {

        //<start-adobe><start-me>
        if(markedContentExtracted){

            MCObject obj=new MCObject(op);
            currentPdfFile.readObject(obj);

            contentHandler.DP(obj);
        }
        //<end-me><end-adobe>

    }

    ////////////////////////////////////////////////////////////////////////
    private void EMC() {

        //<start-adobe><start-me>
        if(markedContentExtracted)
            contentHandler.EMC();
        //<end-me><end-adobe>

        //remove any clip
        Integer key=new Integer(layerLevel);
        if(layerClips.containsKey(key)){

            Area currentClip=(Area) layerClips.get(key);

            gs.setClippingShape(currentClip);

            current.drawClip(gs,currentClip);
        }


        layerLevel--;
        //reset flag
        isLayerVisible = layers == null || layerLevel == 0 || layerVisibility.containsKey(new Integer(layerLevel));

    }

    private void TJ(byte[] characterStream,int startCommand,int dataPointer) {

        if(!isLayerVisible)
            return;



        //extract the text
        textDecoder.setValues(currentTextState, currentFontData, gs, current,textAreas, textDirections,textPrint,
                generateGlyphOnRender,textExtracted,renderDirectly,renderText, currentRotation, errorTracker);

        //attempt to fix odd customers3/slides1.pdf text off page issue
        //no obvious reason to ignore text on form other than negative y value
        if(formLevel==1 && gs.CTM[0][0]!=1 && currentTextState.Tm[0][0]==1 && gs.CTM[1][1]<1f && (gs.CTM[1][1]>0.92f || gs.CTM[0][1]!=0) && currentTextState.Tm[2][1]<0){
            //ignore
        }else{

            /**set colors*/
            if(renderText && gs.getTextRenderType()!=GraphicsState.INVISIBLE){
                gs.setStrokeColor(gs.strokeColorSpace.getColor());
                gs.setNonstrokeColor(gs.nonstrokeColorSpace.getColor());
            }

            StringBuffer current_value =textDecoder.processTextArray(characterStream, startCommand, dataPointer,streamDecoderStatus);

            /**set textState values*/
            int fontSize=textDecoder.getFontSize();
            if(fontSize!=lastFontSize || font_as_string==null){

                //make sure its positive
                if(fontSize>0)
                    currentTextState.setCurrentFontSize(fontSize);
                else
                    currentTextState.setCurrentFontSize(-fontSize);

                font_as_string =Fonts.createFontToken(currentFont,currentTextState.getCurrentFontSize());

                lastFontSize=fontSize;
            }

            //<start-adobe><start-me>
            //will be null if no content
            if (current_value != null && streamDecoderStatus.isPageContent){

                //get colour if needed
                if(textColorExtracted){
                    if ((gs.getTextRenderType() & GraphicsState.FILL) == GraphicsState.FILL){
                        currentColor=gs.nonstrokeColorSpace.getXMLColorToken();
                    }else{
                        currentColor=gs.strokeColorSpace.getXMLColorToken();
                    }
                }

                textDecoder.storeExtractedText(currentColor, pdfData, current_value, tokenNumber, moveCommand,
                        contentHandler, markedContentExtracted, font_as_string);
            }
            //<end-me><end-adobe>
        }

        moveCommand = -1; //flags no move!
    }



    ///////////////////////////////////////////////////////////////////////
    private void G(boolean isLowerCase,byte[] stream) {

        //ensure color values reset
        current.resetOnColorspaceChange();

        boolean isStroke=!isLowerCase;
        float[] operand=getValuesAsFloat(1,stream);

        //set colour and colorspace
        if(isStroke){
            if (gs.strokeColorSpace.getID() != ColorSpaces.DeviceGray)
                gs.strokeColorSpace=new DeviceGrayColorSpace();

            gs.strokeColorSpace.setColor(operand,operandCount);

            //track colrspace use
            cache.put(PdfObjectCache.ColorspacesUsed,new Integer(gs.strokeColorSpace.getID()),"x");

        }else{
            if (gs.nonstrokeColorSpace.getID() != ColorSpaces.DeviceGray)
                gs.nonstrokeColorSpace=new DeviceGrayColorSpace();

            gs.nonstrokeColorSpace.setColor(operand,operandCount);

            //track colorspace use
            cache.put(PdfObjectCache.ColorspacesUsed,new Integer(gs.nonstrokeColorSpace.getID()),"x");

        }
    }

    private void TL(float tl) {
        currentTextState.setLeading(tl);
    }

    private void BDC(int startCommand, int dataPointer,byte[] raw,String op) {

        layerLevel++;

        int rawStart=startCommand;

        PdfObject BDCobj=new MCObject(op);
        BDCobj.setID(PdfDictionary.BDC); //use an existing feature to add unknown tags

        if(startCommand<1)
            startCommand=1;

        boolean hasDictionary=true;
        while(startCommand<raw.length && raw[startCommand]!='<' && raw[startCommand-1]!='<'){
            startCommand++;

            if(raw[startCommand]=='B' && raw[startCommand+1]=='D' && raw[startCommand+2]=='C'){
                hasDictionary=false;
                break;
            }
        }

        /**
         * read Dictionary object
         */
        if(hasDictionary &&(markedContentExtracted || (layers!=null && isLayerVisible)))
            currentPdfFile.getObjectDecoder().readDictionaryAsObject(BDCobj, "layer" ,startCommand+1,raw, dataPointer, false);


        //add in layer if visible
        if(layers!=null && isLayerVisible){

            String name="";

            if(hasDictionary){
                //see if name and if shown
                name = BDCobj.getName(PdfDictionary.OC);


                //see if Layer defined and get title if no Name as alternative
                if(name==null){

                    PdfObject layerObj=BDCobj.getDictionary(PdfDictionary.Layer);
                    if(layerObj!=null)
                        name=layerObj.getTextStreamValue(PdfDictionary.Title);
                }

                //needed to flags its a BMC
                layerClips.put(new Integer(layerLevel),null);

                //apply any clip, saving old to restore on EMC
                float[] BBox=BDCobj.getFloatArray(PdfDictionary.BBox);

                if(BBox!=null){
                    Area currentClip=gs.getClippingShape();

                    //store so we restore in EMC
                    if(currentClip!=null)
                        layerClips.put(new Integer(layerLevel),currentClip.clone());


                    Area clip=new Area(new Rectangle2D.Float(BBox[0], BBox[1], -gs.CTM[2][0]+(BBox[2]-BBox[0]), -gs.CTM[2][1]+(BBox[3]-BBox[1])));
                    gs.setClippingShape(clip);

                    current.drawClip(gs,clip);
                }
            }else{ //direct just /OC and /MCxx

                //find /OC
                for(int ii=rawStart;ii<dataPointer;ii++){
                    if(raw[ii]=='/' && raw[ii+1]=='O' && raw[ii+2]=='C'){ //find oc

                        ii=ii+2;
                        //roll onto value
                        while(raw[ii]!='/')
                            ii++;

                        ii++; //roll pass /

                        int strStart=ii,charCount=0;

                        while(ii<dataPointer){
                            ii++;
                            charCount++;

                            if(raw[ii]==13 || raw[ii]==10 || raw[ii]==32 || raw[ii]=='/')
                                break;
                        }

                        name=new String(raw,strStart,charCount);

                    }
                }
            }

            if(name!=null) //name referring to Layer or Title
                isLayerVisible=layers.decodeLayer(name,true);

            //flag so we can next values
            if(isLayerVisible)
                layerVisibility.put(new Integer(layerLevel),"x");

            //@delete-start---------------------------------------------------
            //debug code
            int count=1;
            if(!isLayerVisible && 1==2){

                System.out.println(BDCobj.getName(PdfDictionary.OC)+"----------->");
                while(dataPointer<raw.length){

                    System.out.print((char)raw[dataPointer]);

                    if(raw[dataPointer-2]=='B' && raw[dataPointer-1]=='D' && raw[dataPointer]=='C'){
                        count++;
                        dataPointer=dataPointer+3;
                    }else if(raw[dataPointer-2]=='B' && raw[dataPointer-1]=='M' && raw[dataPointer]=='C'){
                        count++;
                        dataPointer=dataPointer+3;
                    }else if(raw[dataPointer-2]=='E' && raw[dataPointer-1]=='M' && raw[dataPointer]=='C'){
                        count--;
                        dataPointer=dataPointer+3;
                    }else
                        dataPointer++;

                    if(count==0)
                        break;
                }

                System.out.println("<----------->");



                dataPointer--;

            }
            //@delete-end
        }

        //get Structured Content
        if(markedContentExtracted){

            //<start-adobe><start-me>
            contentHandler.BDC(BDCobj);
            //<end-me><end-adobe>
        }


    }

    private void BMC(String op) {

        layerLevel++;

        //<start-adobe><start-me>
        if(markedContentExtracted)
            contentHandler.BMC(op);

        //<end-me><end-adobe>
    }

    private static final int[][] intValues={
            {0,100000,200000,300000,400000,500000,600000,700000,800000,900000},
            {0,10000,20000,30000,40000,50000,60000,70000,80000,90000},
            {0,1000,2000,3000,4000,5000,6000,7000,8000,9000},
            {0,100,200,300,400,500,600,700,800,900},
            {0,10,20,30,40,50,60,70,80,90},
            {0,1,2,3,4,5,6,7,8,9}};

    final float parseFloat(int id,byte[] stream){

        float f=0f,dec=0f,num=0f;

        int start=opStart[id];
        int charCount=opEnd[id]-start;

        int floatptr=charCount,intStart=0;

        boolean isMinus=false;
        //hand optimised float code
        //find decimal point
        for(int j=charCount-1;j>-1;j--){
            if(stream[start+j]==46){ //'.'=46
                floatptr=j;
                break;
            }
        }

        int intChars=floatptr;
        //allow for minus
        if(stream[start]==43){ //'+'=43
            intChars--;
            intStart++;
        }else if(stream[start]==45){ //'-'=45
            //intChars--;
            intStart++;
            isMinus=true;
        }

        //optimisations
        int intNumbers=intChars-intStart;
        int decNumbers=charCount-floatptr;

        if(intNumbers>3 || decNumbers>11){ //non-optimised to cover others (tiny decimals on big scaling can add up to a big diff)
            isMinus=false;
            f=Float.parseFloat(this.generateOpAsString(id,stream, false));

        }else{

            float units=0f,tens=0f,hundreds=0f,tenths=0f,hundredths=0f, thousands=0f, tenthousands=0f,hunthousands=0f;
            int c;

            //hundreds
            if(intNumbers>2){
                c=stream[start+intStart]-48;
                switch(c){
                    case 1:
                        hundreds=100.0f;
                        break;
                    case 2:
                        hundreds=200.0f;
                        break;
                    case 3:
                        hundreds=300.0f;
                        break;
                    case 4:
                        hundreds=400.0f;
                        break;
                    case 5:
                        hundreds=500.0f;
                        break;
                    case 6:
                        hundreds=600.0f;
                        break;
                    case 7:
                        hundreds=700.0f;
                        break;
                    case 8:
                        hundreds=800.0f;
                        break;
                    case 9:
                        hundreds=900.0f;
                        break;
                }
                intStart++;
            }

            //tens
            if(intNumbers>1){
                c=stream[start+intStart]-48;
                switch(c){
                    case 1:
                        tens=10.0f;
                        break;
                    case 2:
                        tens=20.0f;
                        break;
                    case 3:
                        tens=30.0f;
                        break;
                    case 4:
                        tens=40.0f;
                        break;
                    case 5:
                        tens=50.0f;
                        break;
                    case 6:
                        tens=60.0f;
                        break;
                    case 7:
                        tens=70.0f;
                        break;
                    case 8:
                        tens=80.0f;
                        break;
                    case 9:
                        tens=90.0f;
                        break;
                }
                intStart++;
            }

            //units
            if(intNumbers>0){
                c=stream[start+intStart]-48;
                switch(c){
                    case 1:
                        units=1.0f;
                        break;
                    case 2:
                        units=2.0f;
                        break;
                    case 3:
                        units=3.0f;
                        break;
                    case 4:
                        units=4.0f;
                        break;
                    case 5:
                        units=5.0f;
                        break;
                    case 6:
                        units=6.0f;
                        break;
                    case 7:
                        units=7.0f;
                        break;
                    case 8:
                        units=8.0f;
                        break;
                    case 9:
                        units=9.0f;
                        break;
                }
            }

            //tenths
            if(decNumbers>1){
                floatptr++; //move beyond.
                c=stream[start+floatptr]-48;
                switch(c){
                    case 1:
                        tenths=0.1f;
                        break;
                    case 2:
                        tenths=0.2f;
                        break;
                    case 3:
                        tenths=0.3f;
                        break;
                    case 4:
                        tenths=0.4f;
                        break;
                    case 5:
                        tenths=0.5f;
                        break;
                    case 6:
                        tenths=0.6f;
                        break;
                    case 7:
                        tenths=0.7f;
                        break;
                    case 8:
                        tenths=0.8f;
                        break;
                    case 9:
                        tenths=0.9f;
                        break;
                }
            }

            //hundredths
            if(decNumbers>2){
                floatptr++; //move beyond.
                //c=value.charAt(floatptr)-48;
                c=stream[start+floatptr]-48;
                switch(c){
                    case 1:
                        hundredths=0.01f;
                        break;
                    case 2:
                        hundredths=0.02f;
                        break;
                    case 3:
                        hundredths=0.03f;
                        break;
                    case 4:
                        hundredths=0.04f;
                        break;
                    case 5:
                        hundredths=0.05f;
                        break;
                    case 6:
                        hundredths=0.06f;
                        break;
                    case 7:
                        hundredths=0.07f;
                        break;
                    case 8:
                        hundredths=0.08f;
                        break;
                    case 9:
                        hundredths=0.09f;
                        break;
                }
            }

            //thousands
            if(decNumbers>3){
                floatptr++; //move beyond.
                c=stream[start+floatptr]-48;
                switch(c){
                    case 1:
                        thousands=0.001f;
                        break;
                    case 2:
                        thousands=0.002f;
                        break;
                    case 3:
                        thousands=0.003f;
                        break;
                    case 4:
                        thousands=0.004f;
                        break;
                    case 5:
                        thousands=0.005f;
                        break;
                    case 6:
                        thousands=0.006f;
                        break;
                    case 7:
                        thousands=0.007f;
                        break;
                    case 8:
                        thousands=0.008f;
                        break;
                    case 9:
                        thousands=0.009f;
                        break;
                }
            }

            //tenthousands
            if(decNumbers>4){
                floatptr++; //move beyond.
                c=stream[start+floatptr]-48;
                switch(c){
                    case 1:
                        tenthousands=0.0001f;
                        break;
                    case 2:
                        tenthousands=0.0002f;
                        break;
                    case 3:
                        tenthousands=0.0003f;
                        break;
                    case 4:
                        tenthousands=0.0004f;
                        break;
                    case 5:
                        tenthousands=0.0005f;
                        break;
                    case 6:
                        tenthousands=0.0006f;
                        break;
                    case 7:
                        tenthousands=0.0007f;
                        break;
                    case 8:
                        tenthousands=0.0008f;
                        break;
                    case 9:
                        tenthousands=0.0009f;
                        break;
                }
            }

            //			tenthousands
            if(decNumbers>5){
                floatptr++; //move beyond.
                c=stream[start+floatptr]-48;

                switch(c){
                    case 1:
                        hunthousands=0.00001f;
                        break;
                    case 2:
                        hunthousands=0.00002f;
                        break;
                    case 3:
                        hunthousands=0.00003f;
                        break;
                    case 4:
                        hunthousands=0.00004f;
                        break;
                    case 5:
                        hunthousands=0.00005f;
                        break;
                    case 6:
                        hunthousands=0.00006f;
                        break;
                    case 7:
                        hunthousands=0.00007f;
                        break;
                    case 8:
                        hunthousands=0.00008f;
                        break;
                    case 9:
                        hunthousands=0.00009f;
                        break;
                }
            }

            dec=tenths+hundredths+thousands+tenthousands+hunthousands;
            num=hundreds+tens+units;
            f=num+dec;

        }

        if(isMinus)
            return -f;
        else
            return f;
    }


    final int parseInt(byte[] stream,int start,int opEnd){

        int number=0,id=0;

        int charCount=opEnd-start;

        int intStart=0;
        boolean isMinus=false;


        int intChars=charCount;
        //allow for minus
        if(stream[start]==43){ //'+'=43
            intChars--;
            intStart++;
        }else if(stream[start]==45){ //'-'=45
            //intChars--;
            intStart++;
            isMinus=true;
        }

        //optimisations
        int intNumbers=intChars-intStart;

        if((intNumbers>6)){ //non-optimised to cover others
            isMinus=false;
            number=Integer.parseInt(this.generateOpAsString(id,stream, false));

        }else{ //optimised lookup version

            int c;

            for(int jj=5;jj>-1;jj--){
                if(intNumbers>jj){
                    c=stream[start+intStart]-48;
                    number=number+intValues[5-jj][c];
                    intStart++;
                }
            }
        }

        if(isMinus)
            return -number;
        else
            return number;
    }

    ////////////////////////////////////////////////////////////////////////
    private void TM() {

        boolean includeRotation = false;
        if(includeRotation){

            float[][] trm=currentTextState.Tm;


            if(trm[1][0]==0 && trm[0][1]==0){
                currentRotation=0;
                unRotatedY =-1;
            }else{

                //note we convert radians to degrees - ignore if slight
                if(trm[0][1]==0 || trm[1][0]==0){
                    currentRotation=0;
                    unRotatedY =-1;

                }else{
                    rotationAsRadians=-Math.asin(trm[1][0]/trm[0][0]);

                    int newRotation=(int)(rotationAsRadians*radiansToDegrees);

                    if(newRotation==0){
                        currentRotation=0;
                        unRotatedY =-1;
                    }else{
                        //set new rotation
                        currentRotation = newRotation;
                        convertToUnrotated(trm);
                    }
                }
            }
        }

        //keep position in case we need
        currentTextState.setTMAtLineStart();
        currentTextState.setTMAtLineStartNoRotation();

        textDecoder.reset();

        //move command
        moveCommand = 1; //0=t*, 1=Tj, 2=TD

    }

    //////////////////////////////////////////////////////////////////////////
    private void H() {
        currentDrawShape.closeShape();
    }
    ////////////////////////////////////////////////////////////////////////
    private void TR(int value) {

        //Text render mode

        if (value == 0)
            value = GraphicsState.FILL;
        else if (value == 1)
            value = GraphicsState.STROKE;
        else if (value == 2)
            value = GraphicsState.FILLSTROKE;
        else if(value==3){
            value = GraphicsState.INVISIBLE;

            //allow user to over-ride
            if(showInvisibleText)
                value=GraphicsState.FILL;

        }else if(value==7)
            value = GraphicsState.CLIPTEXT;

        gs.setTextRenderType(value);

        if (streamDecoderStatus.renderPage && !renderDirectly)
                current.drawTR(value);

    }
    ////////////////////////////////////////////////////////////////////////
    private void Q(boolean isLowerCase) {

        //save or retrieve
        if (isLowerCase)
            pushGraphicsState();
        else{
            restoreGraphicsState();

            //switch to correct font
            String fontID=currentTextState.getFontID();

            PdfFont restoredFont = resolveFont(fontID);
            if(restoredFont!=null){
                currentFontData=restoredFont;

                current.drawFontBounds(currentFontData.getBoundingBox());
            }
        }
    }

    /**
     * decode or get font
     * @param fontID
     */
    private PdfFont resolveFont(String fontID) {

        PdfFont restoredFont=(PdfFont) cache.resolvedFonts.get(fontID);

        //check it was decoded
        if(restoredFont==null){

            String ref=(String)cache.unresolvedFonts.get(fontID);

            if(ref!=null){

                //remove from list
                cache.unresolvedFonts.remove(fontID);

                PdfObject newFont=new FontObject(ref);

                //                if(ref!=null && ref.length()>2 && ref.charAt(0)=='<') {
                //                    System.out.println("XXX");
                //                    newFont.setStatus(PdfObject.UNDECODED_DIRECT);
                //                }else
                newFont.setStatus(PdfObject.UNDECODED_REF);

                //must be done AFTER setStatus()

                //                if(ref.charAt(0)=='<'){
                //                //ref=ref.substring(2,ref.length());
                //                System.out.println(ref);
                //                    newFont.setStatus(PdfObject.UNDECODED_DIRECT);
                //                }
                newFont.setUnresolvedData(ref.getBytes(), PdfDictionary.Font);
                currentPdfFile.checkResolved(newFont);

                //currentPdfFile.readObject(newFont);

                try {
                    restoredFont = createFont(newFont,fontID);
                } catch (PdfException e) {
                    e.printStackTrace();
                }

                //store
                if(restoredFont!=null)
                    cache.resolvedFonts.put(fontID,restoredFont);
            }
        }

        return restoredFont;
    }

    private int ID(byte[] stream, int startInlineStream, int dataPointer) throws Exception{

        /**
         * read Dictionary
         */
         PdfObject XObject=new XObject(-1);

        /**/

        currentPdfFile.getObjectDecoder().readDictionaryAsObject(XObject,"",startInlineStream,stream, dataPointer-2,true);

        BufferedImage image =   null;

        boolean inline_imageMask = false;

        //store pointer to current place in file
        int inline_start_pointer = dataPointer + 1;
        int i_w = 0, i_h = 0, i_bpc = 0;

        //find end of stream
        int i = inline_start_pointer;
        int streamLength=stream.length;

        //find end
        while (true) {

            //System.out.println(i+"="+stream[i]+" "+stream[i+1]+" "+stream[i+2]+" "+stream[i+3]+" "+stream[i+4]+" "
            //      +(char)stream[i]+""+(char)stream[i+1]+""+(char)stream[i+2]+""+(char)stream[i+3]+""+(char)stream[i+4]+""+(char)stream[i+5]);
            //look for end EI

            //handle Pdflib variety
            if (streamLength-i>3 &&  stream[i + 1] == 69 && stream[i + 2] == 73 && stream[i+3] == 10)
                break;

            //general case
            if ((streamLength-i>3)&&(stream[i] == 32 || stream[i] == 10 || stream[i] == 13 ||  (stream[i+3] == 32 && stream[i+4] == 'Q'))
                    && (stream[i + 1] == 69)
                    && (stream[i + 2] == 73)
                    && ( stream[i+3] == 32 || stream[i+3] == 10 || stream[i+3] == 13))
                break;



            i++;

            if(i==streamLength)
                break;
        }

        if(isLayerVisible && (streamDecoderStatus.renderImages || streamDecoderStatus.finalImagesExtracted || streamDecoderStatus.clippedImagesExtracted || streamDecoderStatus.rawImagesExtracted)){

            //load the data
            //		generate the name including file name to make it unique
            String image_name =streamDecoderStatus.fileName+ "-IN-" + tokenNumber;

            int endPtr=i;
            //hack for odd files
            if(i<stream.length && stream[endPtr] != 32 && stream[endPtr] != 10 && stream[endPtr] != 13)
                endPtr++;

            //correct data (ie idoq/FC1100000021259.pdf )
            if(stream[inline_start_pointer]==10)
                inline_start_pointer++;

            /**
             * put image data in array
             */
            byte[] i_data = new byte[endPtr - inline_start_pointer];
            System.arraycopy(
                    stream,
                    inline_start_pointer,
                    i_data,
                    0,
                    endPtr - inline_start_pointer);

            //System.out.print(">>");
            //for(int ss=inline_start_pointer-5;ss<endPtr+15;ss++)
            //System.out.print((char)stream[ss]);
            //System.out.println("<<"+i_data.length+" end="+endPtr);
            //pass in image data
            XObject.setStream(i_data);

            /**
             * work out colorspace
             */
            PdfObject ColorSpace=XObject.getDictionary(PdfDictionary.ColorSpace);

            //check for Named value
            if(ColorSpace!=null){
                String colKey=ColorSpace.getGeneralStringValue();

                if(colKey!=null){
                    Object col=cache.colorspaces.get(colKey);

                    if(col!=null)
                        ColorSpace=(PdfObject) col;
                    else{
                        //throw new RuntimeException("error with "+colKey+" on ID "+colorspaces);
                    }
                }
            }

            if(ColorSpace!=null && ColorSpace.getParameterConstant(PdfDictionary.ColorSpace)==PdfDictionary.Unknown)
                ColorSpace=null; //no values set

            /**
             * allow user to process image
             */
            if(customImageHandler!=null)
                image=customImageHandler.processImageData(gs,XObject);

            PdfArrayIterator filters = XObject.getMixedArray(PdfDictionary.Filter);

            //check not handled elsewhere
            int firstValue=PdfDictionary.Unknown;
            boolean needsDecoding=false;
            if(filters!=null && filters.hasMoreTokens()){
                firstValue=filters.getNextValueAsConstant(false);

                needsDecoding=(firstValue!=PdfFilteredReader.JPXDecode && firstValue!=PdfFilteredReader.DCTDecode);
            }

            i_w=XObject.getInt(PdfDictionary.Width);
            i_h=XObject.getInt(PdfDictionary.Height);
            i_bpc=XObject.getInt(PdfDictionary.BitsPerComponent);
            inline_imageMask=XObject.getBoolean(PdfDictionary.ImageMask);

            //handle filters (JPXDecode/DCT decode is handle by process image)
            if(needsDecoding){
                PdfFilteredReader filter=new PdfFilteredReader();
                i_data=filter.decodeFilters(currentPdfFile.getObjectDecoder().setupDecodeParms(XObject), i_data, filters, i_w, i_h, null);
            }

            //handle colour information
            GenericColorSpace decodeColorData=new DeviceRGBColorSpace();
            if(ColorSpace!=null){
                decodeColorData=ColorspaceFactory.getColorSpaceInstance(streamDecoderStatus.isPrinting,currentPdfFile,
                        ColorSpace, cache.colorspacesObjects, null, false);

                //track colorspace use
                cache.put(PdfObjectCache.ColorspacesUsed,new Integer(decodeColorData.getID()),"x");

                //use alternate as preference if CMYK
                //if(newColorSpace.getID()==ColorSpaces.ICC && ColorSpace.getParameterConstant(PdfDictionary.Alternate)==ColorSpaces.DeviceCMYK)
                //newColorSpace=new DeviceCMYKColorSpace();
            }
            if(i_data!=null){

                ImageDecoder imageDecoder=new ImageDecoder(current, pageNum,isType3Font, customImageHandler,useHiResImageForDisplay,
                                            currentPdfFile,objectStoreStreamRef,streamDecoderStatus, gs, renderDirectly,cache, pdfImages, formLevel,pageData, errorTracker, null);

                if(customImageHandler==null ||(image==null && !customImageHandler.alwaysIgnoreGenericHandler())){


                    image=imageDecoder.processImage(decodeColorData,
                            i_data,
                            image_name,
                            i_w,
                            i_h,
                            i_bpc,
                            inline_imageMask,
                            XObject,false);

                    //generate name including filename to make it unique
                   imageDecoder.setImageName(image_name);
                }

                //skip if smaller than zero as work around for JPS bug
                if(streamDecoderStatus.isPrinting && image!=null && gs!=null && image.getHeight()==1
                        && gs.CTM[1][1]<1){
                    image=null;
                }

                if (image != null){
                    if(renderDirectly || this.useHiResImageForDisplay){

                        gs.x=gs.CTM[2][0];
                        gs.y=gs.CTM[2][1];

                        current.drawImage(pageNum, image, gs, false, image_name, imageDecoder.getOptionsApplied(), -1);
                    }else{
                        if(streamDecoderStatus.clippedImagesExtracted)
                            imageDecoder.generateTransformedImage(image,image_name);
                        else
                            imageDecoder.generateTransformedImageSingle(image, image_name);
                    }

                    if(image!=null)
                        image.flush();
                }
            }
        }

        dataPointer = i + 3;

        return dataPointer;

    }
    ////////////////////////////////////////////////////////////////////////
    private void TS(float ts) {

        //Text rise
        currentTextState.setTextRise(ts);
    }
    ////////////////////////////////////////////////////////////////////////
    private void double_quote(byte[] characterStream,int startCommand,int dataPointer,float tc,float tw) {

        //Tc part
        currentTextState.setCharacterSpacing(tc);

        //Tw
        currentTextState.setWordSpacing(tw);
        TSTAR();
        TJ(characterStream, startCommand,dataPointer);
    }
    ////////////////////////////////////////////////////////////////////////
    private  void TSTAR() {
        relativeMove(0, -currentTextState.getLeading());

        //move command
        moveCommand = 0; //0=t*, 1=Tj, 2=TD

        textDecoder.reset();
    }
    //////////////////
    private void K(boolean isLowerCase,byte[] stream) {

        //ensure color values reset
        current.resetOnColorspaceChange();

        //set flag to show which color (stroke/nonstroke)
        boolean isStroke=!isLowerCase;

        /**allow for less than 4 values
         * (ie second mapping for device colourspace
         */
        if (operandCount > 3) {

            float[] operand=getValuesAsFloat(operandCount,stream);

            float[] tempValues=new float[operandCount];
            for(int ii=0;ii<operandCount;ii++)
                tempValues[operandCount-ii-1]=operand[ii];
            operand=tempValues;

            //set colour and make sure in correct colorspace
            if(isStroke){
                if (gs.strokeColorSpace.getID() != ColorSpaces.DeviceCMYK)
                    gs.strokeColorSpace=new DeviceCMYKColorSpace();

                gs.strokeColorSpace.setColor(operand,operandCount);

                //track colorspace use
                cache.put(PdfObjectCache.ColorspacesUsed,new Integer(gs.strokeColorSpace.getID()),"x");

            }else{
                if (gs.nonstrokeColorSpace.getID() != ColorSpaces.DeviceCMYK)
                    gs.nonstrokeColorSpace=new DeviceCMYKColorSpace();

                //make white on forms transparent
                if(!newForms && formLevel>0 && groupObj!=null && !groupObj.getBoolean(PdfDictionary.K) && (gs.nonstrokeColorSpace.getID() == ColorSpaces.DeviceCMYK) &&
                        operand[0]==0 && operand[1]==0 &&
                        operand[2]==0 && operand[3]==0){

                    gs.nonstrokeColorSpace.setColorIsTransparent();

                }else
                    gs.nonstrokeColorSpace.setColor(operand,operandCount);

                //track colorspace use
                cache.put(PdfObjectCache.ColorspacesUsed,new Integer(gs.nonstrokeColorSpace.getID()),"x");

            }
        }
    }

    private String[] getValuesAsString(int count,byte[] dataStream) {

        String[] op=new String[count];
        for(int i=0;i<count;i++)
            op[i]=this.generateOpAsString(i,dataStream, true);
        return op;
    }

    private float[] getValuesAsFloat(int count,byte[] dataStream) {

        float[] op=new float[count];
        for(int i=0;i<count;i++)
            op[i]=this.parseFloat(i,dataStream);
        return op;
    }

    private void W(boolean isStar) {

        //set Winding rule
        if (isStar)
            currentDrawShape.setEVENODDWindingRule();
        else
            currentDrawShape.setNONZEROWindingRule();

        //set clipping flag
        isClip = true;

    }

    /**set width from lower case w*/
    private void width(float w) {

        //ensure minimum width
        //if(w<1)
        //w=1;

        gs.setLineWidth(w);

    }

    private void one_quote(
            byte[] characterStream,
            int startCommand,int dataPointer) {

        if(!isLayerVisible)
            return;

        TSTAR();
        TJ(characterStream, startCommand,dataPointer);

    }

    private void N() {

        if (isClip) {

            //create clipped shape
            currentDrawShape.closeShape();

            Shape s=currentDrawShape.generateShapeFromPath(  null,gs.CTM,false,false,null,0,0);

            //ignore huge shapes which will crash Java
            if(currentDrawShape.getSegmentCount()<5000){
                Area newClip=new Area(s);

                gs.updateClip(newClip);
            }


            gs.checkWholePageClip(pageData.getMediaBoxHeight(pageNum)+pageData.getMediaBoxY(pageNum));

            //always reset flag
            isClip = false;

            //save for later
            if (streamDecoderStatus.renderPage){
                current.drawClip(gs,defaultClip) ;
            }
        }

        currentDrawShape.resetPath(); // flush all path ops stored

    }


    ////////////////////////////////////////////////////////////////////////
    private void sh(String shadingObject) {

        if (streamDecoderStatus.renderPage){

            PdfObject Shading= (PdfObject) localShadings.get(shadingObject);
            if(Shading==null){
                Shading= (PdfObject) globalShadings.get(shadingObject);
            }

            //workout shape
            Shape shadeShape=null;
            /**if(gs.CTM!=null){
             int x=(int)gs.CTM[2][0];
             int y=(int)gs.CTM[2][1];
             int w=(int)gs.CTM[0][0];
             if(w==0){
             w=(int)gs.CTM[1][0];
             }
             if(w<0)
             w=-w;

             int h=(int)gs.CTM[1][1];
             if(h==0)
             h=(int)gs.CTM[0][1];
             if(h<0)
             h=-h;
             shadeShape=new Rectangle(x,y,w,h);
             }/**/
            if(shadeShape==null)
                shadeShape=gs.getClippingShape();

            if(shadeShape==null && gs.CTM!=null && gs.CTM[0][1]>0 && gs.CTM[0][0]==0 && gs.CTM[1][1]==0){ //special case

                int x=(int)gs.CTM[2][0];

                int y=(int)gs.CTM[2][1];

                int w=(int)gs.CTM[0][0];
                if(w==0)
                    w=(int)gs.CTM[0][1];

                if(w<0)
                    w=-w;
                int h=(int)gs.CTM[1][1];
                if(h==0)
                    h=(int)gs.CTM[1][0];
                if(h<0)
                    h=-h;

                //don't understand but works on example I have!
                if(gs.CTM[1][0]<0){
                    x=x+(int)gs.CTM[1][0];
                    x=-x;
                    w=(int)gs.CTM[2][0]-x;
                }
                shadeShape=new Rectangle(x,y,w,h);
            }

            /**
             * corner case for odd rotated shading
             */
            if(shadeShape==null && gs.CTM[0][1]<0 && gs.CTM[1][0]<0){
                int x=(int)-gs.CTM[0][1];

                int y=(int)(gs.CTM[2][1]+gs.CTM[1][0]);

                int w=(int)gs.CTM[2][0]-x;
                int h=(int)-gs.CTM[1][0];

                shadeShape=new Rectangle(x,y,w,h);

                //System.out.println(">>"+tokenNumber+" "+shadingObject+" "+gs.getClippingShape());

            }

             /**
             * corner case for odd rotated shading
             */
            if(shadeShape==null && gs.CTM[0][0]>0 && gs.CTM[1][1]<0){
                int x=(int)gs.CTM[2][0];
                int h=(int)gs.CTM[1][1];

                int y=(int)(gs.CTM[2][1]);

                int w=(int)gs.CTM[0][0];

                shadeShape=new Rectangle(x,y,w,h);


            }

             /**
             * corner case for odd rotated shading
             */
            if(shadeShape==null && gs.CTM[0][0]<0 && gs.CTM[1][1]>0){
                int x=(int)gs.CTM[2][0];
                int h=(int)gs.CTM[1][1];

                int y=(int)(gs.CTM[2][1]);

                int w=(int)gs.CTM[0][0];

                shadeShape=new Rectangle(x,y,w,h);

               // System.out.println(">>"+shadeShape.getBounds());

            }

            if(shadeShape==null)
                shadeShape=new Rectangle(pageData.getMediaBoxX(pageNum),pageData.getMediaBoxY(pageNum),pageData.getMediaBoxWidth(pageNum),pageData.getMediaBoxHeight(pageNum));

            /**
             * generate the appropriate shading and then colour in the current clip with it
             */
            try{

                /**
                 * workout colorspace
                 **/
                PdfObject ColorSpace=Shading.getDictionary(PdfDictionary.ColorSpace);

                GenericColorSpace newColorSpace=ColorspaceFactory.getColorSpaceInstance(streamDecoderStatus.isPrinting,
                        currentPdfFile, ColorSpace, cache.colorspacesObjects, null, true);

                //use alternate as preference if CMYK
                //if(newColorSpace.getID()==ColorSpaces.ICC && ColorSpace.getParameterConstant(PdfDictionary.Alternate)==ColorSpaces.DeviceCMYK)
                //newColorSpace=new DeviceCMYKColorSpace();

                /**setup shading object*/

                PdfPaint shading=null;

                if(shading!=null){
                    /**
                     * shade the current clip
                     */
                    gs.setFillType(GraphicsState.FILL);
                    gs.setNonstrokeColor(shading);

                    //track colrspace use
                    cache.put(PdfObjectCache.ColorspacesUsed,new Integer(newColorSpace.getID()),"x");

                    current.drawShape(shadeShape,gs) ;
                }
            }catch(Exception e){
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////
    private void TW(float tw) {
        currentTextState.setWordSpacing(tw);
    }
    ////////////////////////////////////////////////////////
    private void CS(boolean isLowerCase,String colorspaceObject) {

        //ensure color values reset
        current.resetOnColorspaceChange();

        //set flag for stroke
        boolean isStroke = !isLowerCase;

        //ensure if used for both Cs and cs simultaneously we only cache one version and do not overwrite
        boolean alreadyUsed=(!isLowerCase && colorspaceObject.equals(csInUse))||(isLowerCase && colorspaceObject.equals(CSInUse));

        if(isLowerCase)
            csInUse=colorspaceObject;
        else
            CSInUse=colorspaceObject;


        /**
         * work out colorspace
         */
        PdfObject ColorSpace=(PdfObject)cache.colorspaces.get(colorspaceObject);

        if(ColorSpace==null)
            ColorSpace=new ColorSpaceObject(colorspaceObject.getBytes());

        String ref=ColorSpace.getObjectRefAsString(), ref2=ref+ '-'+isLowerCase;

        GenericColorSpace newColorSpace= null;

        //(ms) 20090430 new code does not work so commented out

        //int ID=ColorSpace.getParameterConstant(PdfDictionary.ColorSpace);

        //        if(isLowerCase)
        //            System.out.println(" cs="+colorspaceObject+" "+alreadyUsed+" ref="+ref);
        //        else
        //            System.out.println(" CS="+colorspaceObject+" "+alreadyUsed+" ref="+ref);

        if(!alreadyUsed && cache.colorspacesObjects.containsKey(ref)){

            newColorSpace=(GenericColorSpace) cache.colorspacesObjects.get(ref);

            //reinitialise
            newColorSpace.reset();
        }else if(alreadyUsed &&cache.colorspacesObjects.containsKey(ref2)){

            newColorSpace=(GenericColorSpace) cache.colorspacesObjects.get(ref2);

            //reinitialise
            newColorSpace.reset();
        }else{

            newColorSpace=ColorspaceFactory.getColorSpaceInstance(streamDecoderStatus.isPrinting,currentPdfFile, ColorSpace, cache.colorspacesObjects, null, false);

            //use alternate as preference if CMYK
            //if(newColorSpace.getID()==ColorSpaces.ICC && ColorSpace.getParameterConstant(PdfDictionary.Alternate)==ColorSpaces.DeviceCMYK)
            //  newColorSpace=new DeviceCMYKColorSpace();

            //broken on calRGB so ignore at present
            //if(newColorSpace.getID()!=ColorSpaces.CalRGB)

            if((newColorSpace.getID()==ColorSpaces.ICC || newColorSpace.getID()==ColorSpaces.Separation)){
                //if(newColorSpace.getID()==ColorSpaces.Separation)

                if(!alreadyUsed){
                    cache.colorspacesObjects.put(ref, newColorSpace);
                }else
                    cache.colorspacesObjects.put(ref2, newColorSpace);

                // System.out.println("cache "+ref +" "+isLowerCase+" "+colorspaceObject);
            }

        }

        //pass in pattern arrays containing all values
        if(newColorSpace.getID()==ColorSpaces.Pattern){

            //at this point we only know it is Pattern so need to pass in WHOLE array
            newColorSpace.setPattern(patterns,pageH,gs.CTM);
            newColorSpace.setGS(gs);
        }

        //track colorspace use
        cache.put(PdfObjectCache.ColorspacesUsed,new Integer(newColorSpace.getID()),"x");

        if(isStroke)
            gs.strokeColorSpace=newColorSpace;
        else
            gs.nonstrokeColorSpace=newColorSpace;


    }
    ////////////////////////////////////////////////////////////////////////
    private void V(float x3,float y3,float x2,float y2) {
        currentDrawShape.addBezierCurveV(x2, y2, x3, y3);
    }
    ////////////////////////////////////////////////////////////////////////
    private void TF(float Tfs,String fontID) {


        //set global variables to new values
        currentTextState.setFontTfs(Tfs);

        PdfFont newFont=resolveFont(fontID);

        if(newFont!=null){
            //@fontHandle currentFontData.unsetUnscaledFont();
            currentFontData=newFont;

            current.drawFontBounds(currentFontData.getBoundingBox());
        }

        //convert ID to font name and store
        currentFont = currentFontData.getFontName();
        currentTextState.setFont(currentFont,fontID);

        //compensate for odd font scaling in Type 3
        font_as_string =Fonts.createFontToken(currentFont,currentTextState.getCurrentFontSize());

    }

    /**
     * process each token and add to text or decode
     * if not known command, place in array (may be operand which is
     * later used by command)
     */
    private int processToken(int commandID,
                             byte[] characterStream,
                             int startCommand,int dataPointer) throws  Exception
    {

        //reorder values so work
        if(operandCount>0){

            int[] orderedOpStart=new int[MAXOPS];
            int[] orderedOpEnd=new int[MAXOPS];
            int opid=0;
            for(int jj=this.currentOp-1;jj>-1;jj--){

                orderedOpStart[opid]=opStart[jj];
                orderedOpEnd[opid]=opEnd[jj];
                if(opid==operandCount)
                    jj=-1;
                opid++;
            }
            if(opid==operandCount){
                currentOp--; //decrease to make loop comparison faster
                for(int jj=this.MAXOPS-1;jj>currentOp;jj--){

                    orderedOpStart[opid]=opStart[jj];
                    orderedOpEnd[opid]=opEnd[jj];
                    if(opid==operandCount)
                        jj=currentOp;
                    opid++;
                }
                currentOp++;
            }

            opStart=orderedOpStart;
            opEnd=orderedOpEnd;
        }


        /**
         * call method to handle commands
         */

        /**text commands first and all other
         * commands if not found in first
         **/
        boolean notFound=true;
        if(!streamDecoderStatus.getSamplingOnly &&(renderText || textExtracted)) {

            notFound=false;

            switch(commandID){
                case Cmd.Tc :
                    TC(parseFloat(0,characterStream));
                    break;
                case Cmd.Tw :
                    TW(parseFloat(0,characterStream));
                    break;
                case Cmd.Tz :
                    TZ(parseFloat(0,characterStream));
                    break;
                case Cmd.TL :
                    TL(parseFloat(0,characterStream));
                    break;
                case Cmd.Tf :
                    TF(parseFloat(0,characterStream),(generateOpAsString(1,characterStream, true)));
                    break;
                case Cmd.Tr :
                    TR(parseInt(characterStream,opStart[0],opEnd[0]));
                    break;
                case Cmd.Ts :
                    TS(parseFloat(0,characterStream));
                    break;
                case Cmd.TD :
                    TD(false,parseFloat(1,characterStream),parseFloat(0,characterStream));
                    break;
                case Cmd.Td :
                    TD(true,parseFloat(1,characterStream),parseFloat(0,characterStream));
                    break;
                case Cmd.Tm :
                    //set Tm matrix
                    currentTextState.Tm[0][0] =parseFloat(5,characterStream);
                    currentTextState.Tm[0][1] =parseFloat(4,characterStream);
                    currentTextState.Tm[0][2] = 0;
                    currentTextState.Tm[1][0] =parseFloat(3,characterStream);
                    currentTextState.Tm[1][1] =parseFloat(2,characterStream);
                    currentTextState.Tm[1][2] = 0;
                    currentTextState.Tm[2][0] =parseFloat(1,characterStream);
                    currentTextState.Tm[2][1] =parseFloat(0,characterStream);
                    currentTextState.Tm[2][2] = 1;

                    //set Tm matrix
                    currentTextState.TmNoRotation[0][0] =currentTextState.Tm[0][0];
                    currentTextState.TmNoRotation[0][1] =currentTextState.Tm[0][1];
                    currentTextState.TmNoRotation[0][2] = 0;
                    currentTextState.TmNoRotation[1][0] =currentTextState.Tm[1][0];
                    currentTextState.TmNoRotation[1][1] =currentTextState.Tm[1][1];
                    currentTextState.TmNoRotation[1][2] = 0;
                    currentTextState.TmNoRotation[2][0] =currentTextState.Tm[2][0];
                    currentTextState.TmNoRotation[2][1] =currentTextState.Tm[2][1];
                    currentTextState.TmNoRotation[2][2] = 1;


                    TM();
                    break;
                case Cmd.Tstar :
                    TSTAR();
                    break;
                case Cmd.Tj :
                    TJ(characterStream, startCommand,dataPointer);
                    break;
                case Cmd.TJ :
                    TJ(characterStream, startCommand,dataPointer);
                    break;
                case Cmd.quote :
                    one_quote(characterStream,startCommand,dataPointer);
                    break;
                case Cmd.doubleQuote :
                    double_quote(characterStream,startCommand,dataPointer,parseFloat(1,characterStream),parseFloat(2,characterStream));
                    break;
                default:
                    notFound=true;
                    break;

            }
        }

        if(!streamDecoderStatus.getSamplingOnly && (streamDecoderStatus.renderPage || textColorExtracted || colorExtracted)) {

            notFound=false;

            switch(commandID){
                case Cmd.rg :
                    RG(true,characterStream);
                    break;
                case Cmd.RG :
                    RG(false,characterStream);
                    break;
                case Cmd.SCN :
                    SCN(false,characterStream);
                    break;
                case Cmd.scn :
                    SCN(true,characterStream);
                    break;
                case Cmd.SC :
                    SCN(false,characterStream);
                    break;
                case Cmd.sc :
                    SCN(true,characterStream);
                    break;
                case Cmd.cs :
                    CS(true,generateOpAsString(0,characterStream, true));
                    break;
                case Cmd.CS :
                    CS(false,generateOpAsString(0,characterStream, true));
                    break;
                case Cmd.g :
                    G(true,characterStream);
                    break;
                case Cmd.G :
                    G(false,characterStream);
                    break;
                case Cmd.k :
                    K(true,characterStream);
                    break;
                case Cmd.K :
                    K(false,characterStream);
                    break;
                case Cmd.sh:
                    sh(generateOpAsString(0,characterStream, true));
                    break;
                default:
                    notFound=true;
                    break;

            }
        }

        if(notFound){

            switch(commandID){

                case Cmd.cm :
                    //create temp Trm matrix to update Tm
                    float[][] Trm = new float[3][3];

                    //set Tm matrix
                    Trm[0][0] = parseFloat(5,characterStream);
                    Trm[0][1] = parseFloat(4,characterStream);
                    Trm[0][2] = 0;
                    Trm[1][0] = parseFloat(3,characterStream);
                    Trm[1][1] = parseFloat(2,characterStream);
                    Trm[1][2] = 0;
                    Trm[2][0] = parseFloat(1,characterStream);
                    Trm[2][1] = parseFloat(0,characterStream);
                    Trm[2][2] = 1;

                    CM(Trm);
                    break;

                case Cmd.Do :
                    DO(generateOpAsString(0,characterStream, true));
                    break;

                case Cmd.q :
                    Q(true);
                    break;
                case Cmd.Q :
                    Q(false);
                    break;

                default:
                    notFound=true;
                    break;
            }
        }

        if(notFound && !streamDecoderStatus.getSamplingOnly){

            /**
             * other commands here
             */
            switch (commandID) {
                case Cmd.BI:
                    startInlineStream=dataPointer;
                    break;
                case Cmd.ID :
                    dataPointer=ID(characterStream,startInlineStream, dataPointer);
                    break;
                case Cmd.B :
                    B(false,false);
                    break;
                case Cmd.b :
                    B(false,true);
                    break;
                case Cmd.bstar :
                    B(true,true);
                    break;
                case Cmd.Bstar :
                    B(true,false);
                    break;
                case Cmd.c :
                    float x3 =parseFloat(1,characterStream);
                    float y3 = parseFloat(0,characterStream);
                    float x2 =parseFloat(3,characterStream);
                    float y2 = parseFloat(2,characterStream);
                    float x = parseFloat(5,characterStream);
                    float y = parseFloat(4,characterStream);
                    currentDrawShape.addBezierCurveC(x, y, x2, y2, x3, y3);
                    break;
                case Cmd.d :
                    D(characterStream);
                    break;
                case Cmd.F :
                    F(false);
                    break;
                case Cmd.f :
                    F(false);
                    break;
                case Cmd.Fstar :
                    F(true);
                    break;
                case Cmd.fstar :
                    F(true);
                    break;
                case Cmd.h :
                    H();
                    break;
                case Cmd.l :
                    L(parseFloat(1,characterStream),parseFloat(0,characterStream));
                    break;
                case Cmd.m :
                    M(parseFloat(1,characterStream),parseFloat(0,characterStream));
                    break;
                case Cmd.n :
                    N();
                    break;
                case Cmd.S :
                    S(false);
                    break;
                case Cmd.s :
                    S(true);
                    break;
                case Cmd.v :
                    V(parseFloat(1,characterStream),parseFloat(0,characterStream),parseFloat(3,characterStream),parseFloat(2,characterStream));
                    break;
                case Cmd.Wstar :
                    W(true);
                    break;
                case Cmd.W :
                    W(false);
                    break;
                case Cmd.y :
                    Y(parseFloat(1,characterStream),parseFloat(0,characterStream),parseFloat(3,characterStream),parseFloat(2,characterStream));
                    break;
                case Cmd.re :
                    RE(parseFloat(3,characterStream),parseFloat(2,characterStream),parseFloat(1,characterStream),parseFloat(0,characterStream));
                    break;

                case Cmd.gs :
                    gs(generateOpAsString(0,characterStream, true));
                    break;
                case Cmd.i:
                    I();
                    break;
                case Cmd.J :
                    J(false,parseInt(characterStream,opStart[0],opEnd[0]));
                    break;
                case Cmd.j :
                    J(true,parseInt(characterStream,opStart[0],opEnd[0]));
                    break;

                case Cmd.MP :
                    MP();
                    break;
                case Cmd.DP :
                    DP(startCommand,  dataPointer, characterStream,generateOpAsString(0,characterStream, false));
                    break;
                case Cmd.BDC :
                    BDC(startCommand,  dataPointer, characterStream,generateOpAsString(0,characterStream, false));
                    break;
                case Cmd.BMC :
                    BMC(generateOpAsString(0,characterStream, false));
                    break;
                case Cmd.d0 :
                    d0((int) parseFloat(0,characterStream),(int) parseFloat(1,characterStream));
                    break;
                case Cmd.d1 :
                    d1(parseFloat(1,characterStream),
                            parseFloat(3,characterStream),
                            parseFloat(5,characterStream),
                            parseFloat(0,characterStream),
                            parseFloat(2,characterStream),
                            parseFloat(4,characterStream));
                    break;
                case Cmd.EMC :
                    EMC();
                    break;
                case Cmd.BT :
                    BT();
                    break;
                case Cmd.ET :
                    ET();
                    break;

                case Cmd.M:
                    mm((int) (parseFloat(0,characterStream)));
                    break;
                case Cmd.w:
                    width(parseFloat(0,characterStream));
                    break;

            }
        }

        //reset array of trailing values
        currentOp=0;
        operandCount=0;

        //increase pointer
        tokenNumber++;

        return dataPointer;

    }

    private void gs(Object key) {

        PdfObject GS= (PdfObject) GraphicsStates.get(key);

        //@newspeed
        /**new code when ready
         if(oldGS==null){
         currentGraphicsState=new GraphicsState();
         }else
         currentGraphicsState=oldGS.clone();

         /**/
        /**
         * set gs
         */
        gs.setMode(GS);

        /**
         * align display
         */
        nonStrokeAlpha=gs.getNonStrokeAlpha();
        strokeAlpha=gs.getStrokeAlpha();
        //System.out.println(topLevelNonStrokeAlpha+" "+nonStrokeAlpha);
        //System.out.println(topLevelStrokeAlpha+" "+strokeAlpha);

        if(formLevel==0){

            TTtopLevelNonStrokeAlpha=nonStrokeAlpha;
            //TTtopLevelStrokeAlpha=strokeAlpha;

            PdfArrayIterator BM = gs.getBM();
            if(BM==null || !BM.hasMoreTokens())
                topBM=PdfDictionary.Normal;
            else
                topBM=BM.getNextValueAsConstant(false);

        }

        //if(TTtopLevelNonStrokeAlpha<1f)
        //System.out.println(GS.getObjectRefAsString()+" "+formLevel+"-------------nonStrokeAlpha="+nonStrokeAlpha+" strokeAlpha="+strokeAlpha+" TTtopLevelNonStrokeAlpha="+TTtopLevelNonStrokeAlpha+" topBM="+topBM);

        //modify for PlayTime
        //if(!newForms){
        if(formLevel==0){

            topLevelNonStrokeAlpha=nonStrokeAlpha;
            topLevelStrokeAlpha=strokeAlpha;
        }else if (topBM==PdfDictionary.Normal){ //fudge to reproduce effect correctly on samples we have

            if(topLevelNonStrokeAlpha<nonStrokeAlpha){
                nonStrokeAlpha=topLevelNonStrokeAlpha;

                //System.out.println("Adjust to "+nonStrokeAlpha+" "+topBM+" "+PdfDictionary.Normal);
            }

            if(topLevelStrokeAlpha<strokeAlpha){
                strokeAlpha=topLevelStrokeAlpha;
            }
        }

        current.setGraphicsState(GraphicsState.FILL,nonStrokeAlpha);
        current.setGraphicsState(GraphicsState.STROKE,strokeAlpha);
    }

    private Map OXbjectsDecoded = new HashMap();

    //////////////////////////////////////////////////////////////////////
    /**
     * process form or image - we must always process XForms becasue they may contain text
     */
    private void DO(String name) throws PdfException {

        //System.out.println("DO "+name);
        if (!isLayerVisible) {
            return;
        }
        
       
        //string to hold image details
        String details=name;

        //see if we have already decode image and reuse if so and unaltered
        int previousUse = -1;
        String objKey = name + '-' + ((int) gs.CTM[0][0]) + '-' + ((int) gs.CTM[1][1]) + '-' + ((int) gs.CTM[0][1]) + '-' + ((int) gs.CTM[1][0]);
        Object objectKey = OXbjectsDecoded.get(objKey);
        if (objectKey != null && !streamDecoderStatus.isPrinting) {
            previousUse = ((Integer) objectKey).intValue();
        }

        //set if we need
        String key = null;
        if (rejectSuperimposedImages) {
            key = ((int) gs.CTM[2][0]) + "-" + ((int) gs.CTM[2][1]) + '-'
                    + ((int) gs.CTM[0][0]) + '-' + ((int) gs.CTM[1][1]) + '-'
                    + ((int) gs.CTM[0][1]) + '-' + ((int) gs.CTM[1][0]);
        }

        //new version
        PdfObject XObject = (PdfObject) localXObjects.get(name);
        if (XObject == null) {
            XObject = (PdfObject) globalXObjects.get(name);
        }

        if (XObject != null) {
            currentPdfFile.checkResolved(XObject);
        }

        try {

            if (XObject != null) {

                int subtype = XObject.getParameterConstant(PdfDictionary.Subtype);

                //see if visible
                boolean isVisible = true;

                //if layer object attached see if should be visible
                PdfObject layerObj = XObject.getDictionary(PdfDictionary.OC);

                if (layerObj != null) {
                    String layerName = layerObj.getTextStreamValue(PdfDictionary.Name);

                    if (layerName != null && layers != null && layers.isLayerName(layerName)) {
                        //System.out.println("name="+ layerName);
                        isVisible = layers.isVisible(layerName);
                    }
                }

                if (!isVisible) {
                } else if (subtype == PdfDictionary.Form) {


                    if(ImageDecoder.trackImages){
                        //add details to string so we can pass back
                        if(imagesInFile==null)
                            imagesInFile=details+" Form";
                        else
                            imagesInFile=details+" Form\n"+imagesInFile;
                    }

                    if (!this.renderDirectly && statusBar != null) {
                        statusBar.inSubroutine(true);
                    }

                    //reset operand
                    currentOp = 0;
                    operandCount = 0;

                    //read stream for image
                    byte[] objectData = currentPdfFile.readStream(XObject, true, true, false, false, false, XObject.getCacheName(currentPdfFile.getObjectDecoder()));
                    if (objectData != null) {
                        XFormDecoder imageDecoder=new XFormDecoder(current, pageNum,isType3Font, customImageHandler, useHiResImageForDisplay,
                                currentPdfFile,objectStoreStreamRef,streamDecoderStatus, gs, renderDirectly,cache, pdfImages, formLevel,pageData, errorTracker);

                        imageDecoder.processXForm(XObject, objectData, name, this);
                    }

                    if (!this.renderDirectly && statusBar != null) {
                        statusBar.inSubroutine(false);
                    }

                } else if (subtype == PdfDictionary.Image) {

                    if(ImageDecoder.trackImages){
                        details=details+" Image";
                        if(imagesInFile==null)
                            imagesInFile="";
                    }

                    /**don't process unless needed*/
                    if (streamDecoderStatus.renderImages || streamDecoderStatus.clippedImagesExtracted || streamDecoderStatus.finalImagesExtracted || streamDecoderStatus.rawImagesExtracted) {

                        //read stream for image
                        byte[] objectData = null;
                        if (previousUse == -1) {
                        	
                        	objectData = currentPdfFile.readStream(XObject, true, true, false, false, false, XObject.getCacheName(currentPdfFile.getObjectDecoder()));

                            //flag issue
                            if(objectData==null)
                                streamDecoderStatus.imagesProcessedFully = false;
                        }

                        if (objectData != null || previousUse > 0) {

                            boolean alreadyCached = false;//(useHiResImageForDisplay && current.isImageCached(this.pageNum));

                            BufferedImage image = null;

                            ImageDecoder imageDecoder= new ImageDecoder(current, pageNum,isType3Font,customImageHandler,useHiResImageForDisplay,currentPdfFile,
                                    objectStoreStreamRef,streamDecoderStatus, gs, renderDirectly,cache,pdfImages, formLevel,pageData, errorTracker,imagesInFile);

                            //generate name including filename to make it unique less /
                            imageDecoder.setImageName(streamDecoderStatus.fileName + '-' + name);

                            //process the image and save raw version
                            if (!alreadyCached && previousUse == -1) {


                                //last flag change from true to false to fix issue
                                image = imageDecoder.processImageXObject(XObject, name, streamDecoderStatus.fileName, objectData, true, details);

                                imagesInFile=imageDecoder.getImagesInFile();
                            }

                            //                            if(name.equals("X321")){
                            //
                            //                                Graphics2D gg2=image.createGraphics();
                            //                                gg2.setPaint(Color.RED);
                            //                                gg2.drawRect(0,0,image.getWidth()-1, image.getHeight()-1);
                            //        org.jpedal.gui.ShowGUIMessage.showGUIMessage("x",image,"x");
                            //                            }

                            //fix for oddity in Annotation
                            if (image != null && image.getWidth() == 1 && image.getHeight() == 1 && isType3Font) {
                                image.flush();
                                image = null;
                            }

                            if (PdfDecoder.debugHiRes) {
                                System.out.println("final=" + image);
                            }

                            //save transformed image
                            if (image != null || alreadyCached || previousUse > 0) {

                                //manipulate CTM to allow for image truncated
                                float[][] savedCMT = null;

                                if (renderDirectly || useHiResImageForDisplay || previousUse > 0) {

                                    if (previousUse > 0 && PdfDecoder.clipOnMac && PdfDecoder.isRunningOnMac && !alreadyCached) {
                                        image = imageDecoder.clipForMac(image);
                                    }

                                    gs.x = gs.CTM[2][0];
                                    gs.y = gs.CTM[2][1];

                                    if(renderDirectly){ //in own bit as other code not needed
                                        current.drawImage(pageNum, image, gs, alreadyCached, name, imageDecoder.getOptionsApplied(), -1);
                                    }else if (image != null || alreadyCached || previousUse > 0) {

                                        int id = current.drawImage(pageNum, image, gs, alreadyCached, name, imageDecoder.getOptionsApplied(),previousUse);

                                        /**
                                         * delete previous used if this not transparent
                                         */
                                        /**
                                         * ignore multiple overlapping images
                                         */
                                        if (rejectSuperimposedImages && image != null && image.getType() != BufferedImage.TYPE_INT_ARGB) {

                                            if (cache.imposedImages == null) {
                                                cache.imposedImages = new HashMap();
                                            }

                                            //delete under image....
                                            Object lastRef = cache.imposedImages.get(key);
                                            if (lastRef != null && gs.getClippingShape() == null) { //limit to avoid issues on other files
                                                current.flagImageDeleted(((Integer) lastRef).intValue());
                                            }
                                        }

                                        /**
                                         * store last usage in case it reappears unless it is transparent
                                         */
                                        if (rejectSuperimposedImages && key != null && cache.imposedImages != null) {
                                            cache.imposedImages.put(key, new Integer(id));
                                        }

                                        //flag first use if not binary
                                        if (OXbjectsDecoded.get(objKey) == null && image.getType() != BufferedImage.TYPE_BYTE_BINARY) {
                                            OXbjectsDecoded.put(objKey, new Integer(id));
                                        }
                                    }
                                } else {

                                    if (streamDecoderStatus.clippedImagesExtracted) {
                                        imageDecoder.generateTransformedImage(image, name);
                                    } else {
                                        try {
                                            imageDecoder.generateTransformedImageSingle(image, name);
                                        } catch (Exception e) {
                                            LogWriter.writeLog("Exception " + e + " on transforming image in file");
                                        }
                                    }
                                }

                                if (image != null) {
                                    image.flush();
                                }

                                //restore
                                if (savedCMT != null) {
                                    gs.CTM = savedCMT;
                                    //maxX=-1; //flag as used
                                }
                            }
                        }
                    }
                } else {
                    LogWriter.writeLog("[PDF] " + " not supported");
                }
            }

        } catch (Error e) {
            e.printStackTrace();
            streamDecoderStatus.imagesProcessedFully = false;
            errorTracker.addPageFailureMessage("Error " + e + " in DO with image isPrinting=" + streamDecoderStatus.isPrinting + " useHiResImageForDisplay=" + useHiResImageForDisplay);
        } catch (Exception e) {
        	LogWriter.writeLog("Exception "+e);
            streamDecoderStatus.imagesProcessedFully = false;
            errorTracker.addPageFailureMessage("Error " + e + " in DO with image isPrinting=" + streamDecoderStatus.isPrinting + " useHiResImageForDisplay=" + useHiResImageForDisplay);
        }

    }


    /**
     * routine to decode an XForm stream
     */
    public void drawFlattenedForm(PdfObject form) throws  PdfException {

        //check if this form should be displayed
        boolean[] characteristic = ((FormObject)form).getCharacteristics();
        if (characteristic[0] || characteristic[1] || characteristic[5] ||
                (form.getBoolean(PdfDictionary.Open)==false &&
                        form.getParameterConstant(PdfDictionary.Subtype)==PdfDictionary.Popup)){
            //this form should be hidden
            return;
        }

        PdfObject imgObj = null;
        PdfObject APobjN = form.getDictionary(PdfDictionary.AP).getDictionary(PdfDictionary.N);
        String defaultState = form.getName(PdfDictionary.AS);
        if (defaultState != null && defaultState.equals(((FormObject)form).getNormalOnState())) {
            //use the selected appearance stream
            if(APobjN.getDictionary(PdfDictionary.On) !=null){
                imgObj = APobjN.getDictionary(PdfDictionary.On);
            }else {
                Map otherValues=APobjN.getOtherDictionaries();
                if(otherValues!=null && !otherValues.isEmpty()){
                    Iterator keys=otherValues.keySet().iterator();
                    PdfObject val;
                    String key;
                    while(keys.hasNext()){
                        key=(String)keys.next();
                        val=(PdfObject)otherValues.get(key);
                        imgObj = val;
                    }
                }
            }
        }else {
            //use the normal appearance Stream
            if(APobjN!=null || form.getDictionary(PdfDictionary.MK).getDictionary(PdfDictionary.I) !=null){


                //if we have a root stream then it is the off value
                //check in order of N Off, MK I, then N 
                //as N Off overrides others and MK I is in preference to N
                if(APobjN!=null && APobjN.getDictionary(PdfDictionary.Off) !=null){
                    imgObj = APobjN.getDictionary(PdfDictionary.Off);
                }else if(form.getDictionary(PdfDictionary.MK).getDictionary(PdfDictionary.I) !=null
                        && form.getDictionary(PdfDictionary.MK).getDictionary(PdfDictionary.IF)==null){
                    //@mark - look here for MK IF
                    //if we have an IF inside the MK then use the MK I as some files shown that this value is there 
                    //only when the MK I value is not as important as the AP N.
                    imgObj = form.getDictionary(PdfDictionary.MK).getDictionary(PdfDictionary.I);

                }else if(APobjN!=null && APobjN.getDecodedStream()!=null){
                    imgObj = APobjN;
                }
            }
        }

        if(imgObj==null)
            return;

        currentPdfFile.checkResolved(imgObj);
        byte[] formData=imgObj.getDecodedStream(); //get from the AP

        //might be needed to pick up fonts
        PdfObject resources = imgObj.getDictionary(PdfDictionary.Resources);
        currentPdfFile.checkResolved(resources);
        readResources(resources,false);

        /**
         * see if bounding box and set
         */
        float[] BBox=form.getFloatArray(PdfDictionary.Rect);
        Area clip=null;
        boolean clipChanged=false;

        //set gs.CTM to form coords (probably {1,0,0}{0,1,0}{x,y,1} at a guess
        gs.CTM = new float[][]{{1,0,0},{0,1,0},{BBox[0],BBox[1],1}};

        //set clip to match bounds on form
        {
            clip=null;

            Area newClip=new Area(new Rectangle((int)BBox[0],(int)BBox[1],(int)BBox[2],(int)BBox[3]));
            gs.updateClip(new Area(newClip));
            current.drawClip(gs, defaultClip) ;
            clipChanged=true;
        }

        /**decode the stream*/
        decodeStreamIntoObjects(formData);

        /**
         * we need to reset clip otherwise items drawn afterwards
         * like forms data in image or print will not appear.
         */
        gs.updateClip(null);
        current.drawClip(gs, null) ;

    }

    public void setObjectValue(int key, Object  obj){

        switch(key){

            case Name:
                streamDecoderStatus.setName((String) obj);
                break;

            /**
             * pass in status bar object
             *
             */
            case StatusBar:
                this.statusBar=(StatusBar)obj;
                break;

            case PdfLayerList:
                this.layers=(PdfLayerList) obj;
                break;

            //<start-adobe><start-me>

            /**
             * used internally for structured content extraction.
             * Does not work on OS version
             */
            case MarkedContent:

                markedContentExtracted=true;

                contentHandler=new StructuredContentHandler(obj);

                break;

            //<end-me><end-adobe>



            case ImageHandler:
                this.customImageHandler = (ImageHandler)obj;
                if(customImageHandler!=null && current!=null)
                    current.setCustomImageHandler(this.customImageHandler);
                break;

            /**
                 * setup stream decoder to render directly to g2
                 * (used by image extraction)
                 */
             case DirectRendering:

                    this.renderDirectly=true;
                    Graphics2D g2 = (Graphics2D)obj;
                    this.defaultClip=g2.getClip();

                 break;

            /** should be called after constructor or other methods may not work
             * <p>Also initialises DynamicVectorRenderer*/
            case ObjectStore:
                objectStoreStreamRef = (ObjectStore)obj;

                current=new ScreenDisplay(this.pageNum,objectStoreStreamRef,streamDecoderStatus.isPrinting);
                current.setHiResImageForDisplayMode(useHiResImageForDisplay);

                if(customImageHandler!=null && current!=null)
                    current.setCustomImageHandler(customImageHandler);

                break;

        }
    }

    /**
     * Returns the info used in the file or null if no value
     * type can be PdfDictionary.Font, PdfDictionary.Image
     */
    public String getInfoInFile(int type) {

        String returnStr = null;

        switch (type) {
            case PdfDictionary.Font:
                returnStr = fontsInFile;
                break;
            case PdfDictionary.Image:
                returnStr = imagesInFile;
                break;

        }
        return returnStr;
    }

    /**
     return boolean flags with appropriate ket
     */
    public boolean getBooleanValue(int key) {

        switch(key){

            case EmbeddedFonts:
            return hasEmbeddedFonts;


            default:
                throw new RuntimeException("Unknown value "+key);
        }
    }

    /**
     * get page statuses
     */
    public boolean getPageDecodeStatus(int status) {

        if(status==(DecodeStatus.PageDecodingSuccessful))
            return errorTracker.pageSuccessful;
        else if(status==(DecodeStatus.NonEmbeddedCIDFonts))
            return hasNonEmbeddedCIDFonts;
        else if(status==(DecodeStatus.ImagesProcessed))
            return streamDecoderStatus.imagesProcessedFully;
        else if(status==(DecodeStatus.YCCKImages))
            return streamDecoderStatus.hasYCCKimages;
        else if(status==(DecodeStatus.Timeout))
            return isTimeout;
        else if(status==(DecodeStatus.TTHintingRequired))
            return textDecoder.isTTHintingRequired();
        else
            new RuntimeException("Unknown paramter");

        return false;
    }

    /**
     * get page statuses
     */
    public String getPageDecodeStatusReport(int status) {

        if(status==(DecodeStatus.NonEmbeddedCIDFonts)){
            return nonEmbeddedCIDFonts.toString();
        }else
            new RuntimeException("Unknown parameter");

        return "";
    }

    public void setFloatValue(int key,float value) {

        switch(key){

            case Multiplier:
            streamDecoderStatus.multiplyer=value;
                break;
        }
    }

    public void dispose() {

        if(pdfData!=null)
            this.pdfData.dispose();

        //this.pageLines=null;

        this.currentDrawShape=null;

    }
    /**
     private class TestShapeTracker implements ShapeTracker {
     public void addShape(int tokenNumber, int type, Shape currentShape, PdfPaint nonstrokecolor, PdfPaint strokecolor) {

     //use this to see type
     //Cmd.getCommandAsString(type);

     //print out details
     if(type==Cmd.S || type==Cmd.s){ //use stroke color to draw line
     System.out.println("-------Stroke-------PDF cmd="+Cmd.getCommandAsString(type));
     System.out.println("tokenNumber="+tokenNumber+" "+currentShape.getBounds()+" stroke color="+strokecolor);

     }else if(type==Cmd.F || type==Cmd.f || type==Cmd.Fstar || type==Cmd.fstar){ //uses fill color to fill shape
     System.out.println("-------Fill-------PDF cmd="+Cmd.getCommandAsString(type));
     System.out.println("tokenNumber="+tokenNumber+" "+currentShape.getBounds()+" fill color="+nonstrokecolor);

     }else{ //not yet implemented (probably B which is S and F combo)
     System.out.println("Not yet added");
     System.out.println("tokenNumber="+tokenNumber+" "+currentShape.getBounds()+" type="+type+" "+Cmd.getCommandAsString(type));
     }
     }
     }

     /**
     * return details on page for type (defined in org.jpedal.constants.PageInfo) or null if no values
     * Unrecognised key will throw a RunTime exception
     */
    public Iterator getPageInfo(int type) {

        Iterator i=null;
        switch(type){
            case PageInfo.COLORSPACES:

                i=cache.iterator(PdfObjectCache.ColorspacesUsed);
                break;

            default:
                throw new RuntimeException("Unrecognised key "+type);
        }
        return i;
    }

    /**
     * request exit from main loop
     */
    public void reqestTimeout(Object value) {

        if(value==null)
            requestTimeout =true;
        else if(value instanceof Integer){
            timeoutInterval=((Integer)value).intValue();
        }
    }

    public void setIntValue(int key, int value) {

        switch(key){

            /**
             * currentPage number
             */
            case PageNum:
                this.pageNum=value;
                break;


            /**
             * define stream as PATTERN or POSTSCRIPT or TYPE3 fonts
             */
            case StreamType:
                streamDecoderStatus.streamType=value;
                break;

            /**
             * tells program to try and use Java's font printing if possible
             * as work around for issue with PCL printing
             */
            case TextPrint:
                this.textPrint = value;
                break;
        }
    }

    public class XFormDecoder extends ImageDecoder{

        private Map scalings=new HashMap();

        public XFormDecoder(DynamicVectorRenderer current, int pageNum, boolean isType3Font, ImageHandler customImageHandler, boolean useHiResImageForDisplay, PdfObjectReader currentPdfFile, ObjectStore objectStoreStreamRef, StreamDecoderStatus streamDecoderStatus, GraphicsState gs, boolean renderDirectly, PdfObjectCache cache, PdfImageData pdfImages, int formLevel, PdfPageData pageData, ErrorTracker errorTracker) {
            super(current, pageNum, isType3Font, customImageHandler, useHiResImageForDisplay, currentPdfFile, objectStoreStreamRef, streamDecoderStatus, gs, renderDirectly, cache, pdfImages, formLevel, pageData, errorTracker,imagesInFile);
        }

        private BufferedImage getImageFromPdfObject(PdfObject newSMask, int fx, int fw, int fy, int fh) throws PdfException {

            BufferedImage smaskImage;
            Graphics2D formG2;
            byte[] objectData =currentPdfFile.readStream(newSMask,true,true,false, false,false, newSMask.getCacheName(currentPdfFile.getObjectDecoder()));

            PdfStreamDecoder glyphDecoder=new PdfStreamDecoder(currentPdfFile,useHiResImageForDisplay,true); //switch to hires as well

            ObjectStore localStore = new ObjectStore();
            glyphDecoder.setObjectValue(ObjectStore, localStore);

            DynamicVectorRenderer glyphDisplay=new ScreenDisplay(0,false,20,localStore);
            glyphDisplay.setHiResImageForDisplayMode(useHiResImageForDisplay);
            glyphDecoder.init(false,true,renderMode,0,new PdfPageData(),0,glyphDisplay,currentPdfFile);

            /**read any resources*/
            try{

                PdfObject SMaskResources =newSMask.getDictionary(PdfDictionary.Resources);
                currentPdfFile.checkResolved(SMaskResources);
                if (SMaskResources != null)
                    glyphDecoder.readResources(SMaskResources,false);

            }catch(Exception e){
                e.printStackTrace();
            }

            /**decode the stream*/
            if(objectData!=null)
                glyphDecoder.decodeStreamIntoObjects(objectData);

            //see if gray (assume true and disprove) colorspace so we can create image below
            //        boolean isGray=true;
            //        Iterator colsUsed=glyphDecoder.getPageInfo(PageInfo.COLORSPACES);
            //        while(colsUsed.hasNext() && isGray){
            //            if(((Integer)colsUsed.next()).intValue()!=ColorSpaces.DeviceGray)
            //            isGray=false;
            //        }

            glyphDecoder=null;

            //check x,y offsets and factor in
            // if(fx<0)
            //   fx=0;

            int hh=fh;
            if(fy>fh)
                hh=fy-fh;

            //if(isGray)
            //    smaskImage=new  BufferedImage(fw,hh,BufferedImage.TYPE_BYTE_GRAY);
            //else
            smaskImage=new  BufferedImage(fw,hh,BufferedImage.TYPE_INT_ARGB);



            //ensure transparency is white
            //                    BufferedImage white=new BufferedImage(smaskImage.getWidth(), smaskImage.getHeight(), smaskImage.getType());
            //                    Graphics2D gs=white.createGraphics();
            //                    gs.setPaint(Color.WHITE);
            //                    gs.fillRect(0,0,smaskImage.getWidth(), smaskImage.getHeight());
            //                    gs.drawImage(smaskImage,0,0,null);
            //                    smaskImage=white;

            formG2=smaskImage.createGraphics();

            formG2.translate(-fx,-fh);
            glyphDisplay.setG2(formG2);
            glyphDisplay.paint(null,null,null);

            localStore.flush();
            return smaskImage;
        }


        /**
         * routine to decode an XForm stream
         * @param XObject
         * @param formData
         * @param name
         * @param pdfStreamDecoder
         */
        public void processXForm(PdfObject XObject, byte[] formData, String name, PdfStreamDecoder pdfStreamDecoder) throws  PdfException {

            String oldIndent= indent;
            indent= indent+"   ";

            float[] transformMatrix=new float[6];

            /**
             * work through values and see if all match
             * exit on first failure
             */
            boolean isIdentity=true;// assume right and try to disprove

            //set value and see if Transform matrix
            float[] matrix=XObject.getFloatArray(PdfDictionary.Matrix);
            if(matrix!=null){
                transformMatrix=matrix;

                //see if it matches if not set flag and exit
                for(int ii=0;ii<6;ii++){
                    if(matrix[ii]!=matches[ii]){
                        isIdentity=false;
                        break;
                    }
                }
            }

            float[][] CTM=null;

            //allow for stroke line width being altered by scaling
            float lineWidthInForm=-1; //negative values not used

            if(matrix!=null && !isIdentity) {

                //save current
                float[][] currentCTM=new float[3][3];
                for(int i=0;i<3;i++)
                    System.arraycopy(gs.CTM[i], 0, currentCTM[i], 0, 3);
                scalings.put(new Integer(formLevel),currentCTM);

                CTM= gs.CTM;

                float[][] scaleFactor={{transformMatrix[0],transformMatrix[1],0},
                        {transformMatrix[2],transformMatrix[3],0},
                        {transformMatrix[4],transformMatrix[5],1}};

                scaleFactor=Matrix.multiply(scaleFactor,CTM);
                gs.CTM=scaleFactor;

                //work out line width
                lineWidthInForm=transformMatrix[0]* gs.getLineWidth();

                if (lineWidthInForm == 0)
                    lineWidthInForm=transformMatrix[1]* gs.getLineWidth();

                if(lineWidthInForm<0)
                    lineWidthInForm=-lineWidthInForm;
            }

            //track depth
            formLevel++;

            //preserve colorspaces
            GenericColorSpace mainStrokeColorData=(GenericColorSpace) gs.strokeColorSpace.clone();
            GenericColorSpace mainnonStrokeColorData=(GenericColorSpace) gs.nonstrokeColorSpace.clone();

            //preserve GS state as could be over-written
            Map old_gs_state= pdfStreamDecoder.GraphicsStates;
            pdfStreamDecoder.GraphicsStates=new HashMap();
            Iterator keys=old_gs_state.keySet().iterator();
            while(keys.hasNext()){
                Object key=keys.next();
                pdfStreamDecoder.GraphicsStates.put(key,old_gs_state.get(key));
            }

            //set form line width if appropriate
            if(lineWidthInForm>0)
                gs.setLineWidth(lineWidthInForm);

            //preserve Colorspace state as could be over-written
            Map old_ColorSpace_Objects= cache.colorspaces;
            cache.colorspaces=new HashMap();
            keys=old_ColorSpace_Objects.keySet().iterator();
            while(keys.hasNext()){
                Object key=keys.next();
                cache.colorspaces.put(key,old_ColorSpace_Objects.get(key));
            }

            //preserve XObject state as could be over-written
            //		Map old_globalXObjects=globalXObjects;
            //		globalXObjects=new HashMap();
            //		keys=old_globalXObjects.keySet().iterator();
            //		while(keys.hasNext()){
            //			Object key=keys.next();
            //			globalXObjects.put(key,old_globalXObjects.get(key));
            //		}

            Map old_localShadings= pdfStreamDecoder.localShadings;
            pdfStreamDecoder.localShadings=new HashMap();
            keys=old_localShadings.keySet().iterator();
            while(keys.hasNext()){
                Object key=keys.next();
                pdfStreamDecoder.localXObjects.put(key,old_localShadings.get(key));
            }




            Map old_localXObjects= pdfStreamDecoder.localXObjects;
            pdfStreamDecoder.localXObjects=new HashMap();
            keys=old_localXObjects.keySet().iterator();
            while(keys.hasNext()){
                Object key=keys.next();
                pdfStreamDecoder.localXObjects.put(key,old_localXObjects.get(key));
            }

            //preserve fonts
            Map rawFonts= cache.unresolvedFonts;
            Map rawDecodedFonts= cache.resolvedFonts;
            cache.resolvedFonts=new HashMap();
            cache.unresolvedFonts=new HashMap();

            PdfObject mainGroup= pdfStreamDecoder.groupObj;

            //renderer
            DynamicVectorRenderer oldCurrent=null;

            /**read any resources*/
            PdfObject Resources=XObject.getDictionary(PdfDictionary.Resources);

            /**read any resources*/
            pdfStreamDecoder.groupObj=XObject.getDictionary(PdfDictionary.Group);
            currentPdfFile.checkResolved(pdfStreamDecoder.groupObj);

            //reset fags
            if(!newForms && formLevel==0){
                pdfStreamDecoder.topLevelStrokeAlpha=1f;
                pdfStreamDecoder.topLevelNonStrokeAlpha=1f;

                pdfStreamDecoder.strokeAlpha=1f;
                pdfStreamDecoder.nonStrokeAlpha=1f;
            }

            //System.out.println("formLevel="+formLevel);

            currentPdfFile.checkResolved(Resources);
            pdfStreamDecoder.readResources(Resources, false);

            //allow for no fonts in FormObject when we use any global
            if(cache.unresolvedFonts.isEmpty()){
                //unresolvedFonts=rawFonts;
                keys=rawFonts.keySet().iterator();
                while(keys.hasNext()){
                    Object key=keys.next();
                   cache.unresolvedFonts.put(key,rawFonts.get(key));
                }
            }

            /**
             * see if bounding box and set
             */
            float[] BBox=XObject.getFloatArray(PdfDictionary.BBox);
            Area clip=null;
            boolean clipChanged=false;

            //only apply if no scaling
            //System.out.println("matrix="+matrix+" BBox="+BBox+" "+gs.getClippingShape());
            //if(gs.getClippingShape()!=null)
            //System.out.println(gs.getClippingShape().getBounds());

            //if(BBox!=null)
            //System.out.println("BBox="+BBox[0]+" "+BBox[1]+" "+BBox[2]+" "+BBox[3]+" ");

            if(BBox!=null && BBox[0]>0 && BBox[1]>0 && BBox[2]>1 && BBox[3]>1 && (gs.CTM[2][0]<-1 || gs.CTM[2][0]>1) && gs.CTM[2][1]!=0){//)  && BBox[2]>1 && BBox[3]>1 ){//if(BBox!=null && matrix==null && BBox[0]==0 && BBox[1]==0){

                float scaling=gs.CTM[0][0];
                if(scaling==0)
                    scaling=gs.CTM[0][1];

                //System.out.println("scaling="+scaling+" "+gs.CTM[2][0]+" "+gs.CTM[2][1]);

                {//if(scaling>1){
                    int x,y,w,h;


                    //Matrix.show(gs.CTM);
                    //System.out.println("BBox="+BBox[0]+" "+BBox[1]+" "+BBox[2]+" "+BBox[3]+" scaling="+scaling);

                    if(gs.CTM[0][1]>0 && gs.CTM[1][0]<0){

                        x=(int)(gs.CTM[2][0]-(BBox[3]));
                        y=(int)(gs.CTM[2][1]+BBox[0]);
                        w=(int)((BBox[3]-BBox[1])*scaling);
                        h=(int)((BBox[2]-BBox[0])*scaling);

                        //System.out.println("vals="+x+" "+y+" "+w+" "+h);

                    }else if(gs.CTM[0][1]<0 && gs.CTM[1][0]>0){

                        x=(int)(gs.CTM[2][0]+BBox[1]);
                        y=(int)(gs.CTM[2][1]-BBox[2]);
                        w=(int)((BBox[3]-BBox[1])*-scaling);
                        h=(int)((BBox[2]-BBox[0])*-scaling);

                        //System.out.println("vals1="+x+" "+y+" "+w+" "+h);
                    }else{
                        x=(int)(gs.CTM[2][0]+BBox[0]);
                        y=(int)(gs.CTM[2][1]+BBox[1]);
                        w=(int)(1+(BBox[2]-BBox[0])*scaling);
                        h=(int)(1+(BBox[3]-BBox[1])*scaling);

                        //allow for inverted
                        if(gs.CTM[1][1]<0){
                            y=y-h;
                        }
                        //System.out.println("vals2="+x+" "+y+" "+w+" "+h);
                    }

                    if(gs.getClippingShape()==null)
                        clip=null;
                    else
                        clip= (Area) gs.getClippingShape().clone();

                    Area newClip=new Area(new Rectangle(x,y,w,h));

                    gs.updateClip(new Area(newClip));

                    current.drawClip(gs, pdfStreamDecoder.defaultClip) ;

                    clipChanged=true;
                    //Shape currentShape=new Rectangle(105,75,(int)(BBox[3])-135,(int)(BBox[2]-125));
                }
            }

            /**decode the stream*/
            if(formData.length>0){

                //check for soft mask we need to apply
                PdfObject newSMask=null;

                if(gs.SMask!=null){ //see if SMask to cache to image

                    BBox=XObject.getFloatArray(PdfDictionary.BBox);

                    if(BBox!=null && BBox[2]>0 ){ //stop negative cases such as Milkshake StckBook Activity disX.pdf

                        if(gs.SMask.getParameterConstant(PdfDictionary.Type)!=PdfDictionary.Mask || gs.SMask.getFloatArray(PdfDictionary.BC)!=null){ //fix for waves file
                            newSMask= gs.SMask.getDictionary(PdfDictionary.G);
                            currentPdfFile.checkResolved(newSMask);
                        }
                    }
                }

                //see if multiply transparency
                PdfArrayIterator BMvalue = gs.getBM();

                int firstValue=PdfDictionary.Unknown;
                if(BMvalue !=null && BMvalue.hasMoreTokens()) {
                    firstValue= BMvalue.getNextValueAsConstant(false);
                }

                //added formLevel to try and fix customer issue on customers3/Auktionsauftrag_45.9.33620.pdf (including printing)
                if(pdfStreamDecoder.flattenXFormToImage || (streamDecoderStatus.isPrinting && (gs.CTM[2][0]==0) && gs.CTM[2][1]==0 && newSMask==null && firstValue!=PdfDictionary.Multiply && pdfStreamDecoder.nonStrokeAlpha==1) ||
                        ((pdfStreamDecoder.nonStrokeAlpha==1 || !newForms || pdfStreamDecoder.layerLevel>0 || (formLevel==1 && pdfStreamDecoder.nonStrokeAlpha<0.1f)) && newSMask==null && firstValue!=PdfDictionary.Multiply)){ //use if looks like marked text block


                    pdfStreamDecoder.decodeStreamIntoObjects(formData);

                }else if(newSMask!=null || firstValue==PdfDictionary.Multiply){ //if an smask render to image and apply Smask to it - then write out as image

                    //size
                    BBox=XObject.getFloatArray(PdfDictionary.BBox);

                    /**get form as an image*/
                    int fx=(int)BBox[0];
                    int fy=(int)BBox[1];
                    int fw=(int)BBox[2];
                    int fh=(int)(BBox[3]);

                    //check x,y offsets and factor in
                    if(fx<0)
                        fx=0;

                    //if(fy>0)
                    //    fh=fh+fy;

                    //ignore offpage
                    //if(fw<=0 || fh<=0)
                    //    return;

                    //get the form
                    BufferedImage image=null;

                    // get smask if present and create as image for later
                    if(newSMask!=null){

                        image = getImageFromPdfObject(XObject, fx, fw, fy, fh);

                        BufferedImage smaskImage = getImageFromPdfObject(newSMask, fx, fw, fy, fh);
                        image=ImageDecoder.applySmask(image, smaskImage, newSMask, true, false);
                        smaskImage.flush();
                        smaskImage=null;
                    }

                    GraphicsState gs=new GraphicsState();
                    gs.x=fx;
                    gs.y=fy-image.getHeight();
                    gs.CTM=new float[][]{{image.getWidth(),0,1},{0,image.getHeight(),1},{0,0,0}};

                    //draw as image
                    gs.CTM[2][0]=gs.x;
                    gs.CTM[2][1]=gs.y;
                    current.drawImage(pageNum,image,gs,false,name, PDFImageProcessing.IMAGE_INVERTED, -1);

                }else{

                    oldCurrent= current;
                    boolean oldRenderDirectly= renderDirectly;
                    float mainstrokeAlpha= pdfStreamDecoder.strokeAlpha;
                    float mainnonstrokeAlpha= pdfStreamDecoder.nonStrokeAlpha;
                    pdfStreamDecoder.strokeAlpha=1f;
                    pdfStreamDecoder.nonStrokeAlpha=1f;
                    renderDirectly=false;

                    current=new ScreenDisplay(pageNum, pdfStreamDecoder.objectStoreStreamRef,false);
                    current.setHiResImageForDisplayMode(useHiResImageForDisplay);

                    pdfStreamDecoder.decodeStreamIntoObjects(formData);

                    float alpha= gs.getStrokeAlpha();
                    gs.setStrokeAlpha(mainstrokeAlpha);

                    oldCurrent.drawXForm(current, gs);

                    //restore
                    gs.setStrokeAlpha(alpha);
                    current=oldCurrent;
                    pdfStreamDecoder.nonStrokeAlpha=mainnonstrokeAlpha;
                    pdfStreamDecoder.strokeAlpha=mainstrokeAlpha;
                    renderDirectly=oldRenderDirectly;
                }

            }
            //restore clip if changed
            if(clipChanged){
                gs.setClippingShape(clip);
                current.drawClip(gs,clip) ;
            }

            formLevel--;

            //restore old matrix
            CTM=(float[][]) scalings.get(new Integer(formLevel));
            if(CTM!=null)
                gs.CTM=CTM;

            //flush local refs if duplicates
            //if(formLevel==0)
            //	localXObjects.clear();

            /**restore old colorspace and fonts*/
            gs.strokeColorSpace=mainStrokeColorData;
            gs.nonstrokeColorSpace=mainnonStrokeColorData;
            cache.unresolvedFonts=rawFonts;
            cache.resolvedFonts=rawDecodedFonts;
            pdfStreamDecoder.GraphicsStates=old_gs_state;
            cache.colorspaces=old_ColorSpace_Objects;

            //globalXObjects=old_globalXObjects;
            pdfStreamDecoder.localShadings=old_localShadings;
            pdfStreamDecoder.localXObjects=old_localXObjects;
            pdfStreamDecoder.groupObj=mainGroup;

            indent=oldIndent;
        }
    }

}
