/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2011, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * PdfObjectCache.java
  * ---------------
 */
package org.jpedal.parser;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

/**
 * caches for data
 */
public class PdfObjectCache {

    public static final int ColorspacesUsed=1;

    //int values for all colorspaces
    private final Map colorspacesUsed=new HashMap();

    /**colors*/
    public Map colorspaces=new HashMap();
    public Map colorspacesObjects=new HashMap();
    public final Map XObjectColorspaces=new HashMap();
    public final Map colorspacesSeen=new HashMap();

    public Map imposedImages;

    /**fonts*/
    public Map unresolvedFonts=new Hashtable();
    public Map resolvedFonts=new Hashtable();


    public void put(int type, int key, Object value){
        switch(type){
            case ColorspacesUsed:
                colorspacesUsed.put(key,value);
                break;
        }
    }


    public Iterator iterator(int type){

        Iterator returnValue=null;

        switch(type){
            case ColorspacesUsed:
                returnValue=colorspacesUsed.keySet().iterator();
                break;
        }

        return returnValue;
    }

    public Object get(int key, Object value){

        Object returnValue=null;

        switch(key){
            case ColorspacesUsed:
                returnValue=colorspacesUsed.get(value);
                break;
        }

        return returnValue;
    }

    public void resetFonts() {
        resolvedFonts.clear();
        unresolvedFonts.clear();
    }
}
