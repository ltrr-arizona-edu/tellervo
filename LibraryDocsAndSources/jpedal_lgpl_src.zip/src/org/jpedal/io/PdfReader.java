/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2008, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * PdfReader.java
  * ---------------
 */
package org.jpedal.io;

import org.jpedal.objects.PdfFileInformation;
import org.jpedal.objects.raw.*;
import org.jpedal.constants.PDFflags;
import org.jpedal.exception.PdfException;
import org.jpedal.objects.Javascript;
import org.jpedal.utils.*;
import org.jpedal.utils.repositories.Vector_Int;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 */
public class PdfReader implements PdfObjectReader, Serializable {

    private PdfFileReader objectReader=new PdfFileReader();

    /**file length*/
    private long eof =0;

    private String tempFileName=null;

    private ObjectDecoder objectDecoder= new ObjectDecoder();

    /**names lookup table*/
    private NameLookup nameLookup=null;

    public PdfReader() {}

    /**
     * set password as well
     * @param password
     */
    public PdfReader(String password) {
        super();

        if(password==null)
            password="";

        objectReader.setPassword(password);
    }

    /**
     * close the file
     */
    final public void closePdfFile()
    {
        try
        {
            objectReader.closeFile();


            //ensure temp file deleted
            if(tempFileName!=null){
                File fileToDelete=new File(tempFileName);
                fileToDelete.delete();
                tempFileName=null;
            }

            objectDecoder.flush();

        }
        catch( Exception e )
        {
            LogWriter.writeLog( "Exception " + e + " closing file" );
        }

    }

    /**
     * allow user to access SOME PDF objects
     * currently PdfDictionary.Encryption
     */
    public PdfObject getPDFObject(int key) {

        if(key==PdfDictionary.Encrypt){
            return objectReader.encyptionObj;
        }else
            throw new RuntimeException("Access to "+key+" not supported");
    }

    public ObjectDecoder getObjectDecoder() {
        return objectDecoder;
    }

    public PdfFileReader getObjectReader() {
        return objectReader;
    }

    /**
     * convert name into object ref
     */
    public String convertNameToRef(String value) {

        //see if decoded
        if(nameLookup==null)
            return null;
        else
            return (String)nameLookup.get(value);

    }




///////////////////////////////////////////////////////////////////////////

    /**
     * read FDF
     */
    final public PdfObject readFDF() throws PdfException{


        PdfObject fdfObj;

        try{

            byte[] fileData=objectReader.readFDFData();

            fdfObj=new FDFObject("1 0 R");

            //find /FDF key
            int ii=0;
            while(ii<eof){
                if(fileData[ii]=='/' && fileData[ii+1]=='F'
                        && fileData[ii+2]=='D' && fileData[ii+3]=='F')
                    break;

                ii++;
            }

            ii=ii+4;

            //move beyond <<
            while(ii<eof){
                if(fileData[ii]=='<' && fileData[ii+1]=='<')
                    break;

                ii++;
            }
            ii=ii+2;
            objectDecoder.readDictionaryAsObject(fdfObj, "1 0 R", ii, fileData, fileData.length, false);

        } catch (Exception e) {
            try {
                objectReader.closeFile();
            } catch (IOException e1) {
                LogWriter.writeLog("Exception "+e+" closing file");
            }

            throw new PdfException("Exception " + e + " reading trailer");
        }

        return fdfObj;
    }



    /**
     * read any names into names lookup
     */
    public void readNames(PdfObject nameObject, Javascript javascript, boolean isKid){

        nameLookup=new NameLookup(objectDecoder);
        nameLookup.readNames(nameObject, javascript, isKid);
    }

    public void dispose(){

        //this.objData=null;
        //this.lastRef=null;

        nameLookup=null;

        //this.fields=null;

        if(objectReader!=null)
            objectReader.dispose();
        objectReader=null;

        if(objectDecoder!=null)
            objectDecoder.dispose();
        objectDecoder=null;

    }

    /**
     * open pdf file<br> Only files allowed (not http)
     * so we can handle Random Access of pdf
     */
    final public void openPdfFile( InputStream in) throws PdfException
    {

        try
        {

            //use byte[] directly if small otherwise use Memory Map
            RandomAccessBuffer pdf_datafile = new RandomAccessMemoryMapBuffer(in );

            objectReader.init(pdf_datafile);
            objectDecoder.init(objectReader);

            this.eof = pdf_datafile.length();
            //pdf_datafile = new RandomAccessFile( filename, "r" );

        }catch( Exception e )
        {
            LogWriter.writeLog( "Exception " + e + " accessing file" );
            throw new PdfException( "Exception " + e + " accessing file" );
        }

    }

    /**
     * open pdf file<br> Only files allowed (not http)
     * so we can handle Random Access of pdf
     */
    final public void openPdfFile( String filename ) throws PdfException
    {


        RandomAccessBuffer pdf_datafile=null;

        //isFDF=filename.toLowerCase().endsWith(".fdf");

        try
        {
            //<start-wrap>
            /**
             //<end-wrap>
             //possible alternatve - 160420ommnd09- tested on MAc and no obvious gains
             //pdf_datafile = new RandomAccessMemoryMapBuffer( new File(filename) );
             //pdf_datafile = new RandomAccessFileChannelBuffer(this.getClass().getResourceAsStream("/org/jpedal/file.pdf"));
             if(filename.equals("/org/jpedal/file.pdf")){
             pdf_datafile = new RandomAccessFileChannelBuffer(this.getClass().getResourceAsStream("/org/jpedal/file.pdf"));
             }else
             pdf_datafile = new RandomAccessFileBuffer( filename, "r" );

             //<start-wrap>
             /**/
            pdf_datafile = new RandomAccessFileBuffer( filename, "r" );
            //pdf_datafile = new RandomAccessFCTest( new FileInputStream(filename));
            //<end-wrap>

            objectReader.init(pdf_datafile);
            objectDecoder.init(objectReader);

            this.eof = pdf_datafile.length();

        }
        catch( Exception e )
        {
            LogWriter.writeLog( "Exception " + e + " accessing file" );
            throw new PdfException( "Exception " + e + " accessing file" );
        }

    }

    /**
     * open pdf file using a byte stream - By default files under 16384 bytes are cached to disk
     * but this can be altered by setting PdfFileReader.alwaysCacheInMemory to a maximimum size or -1 (always keep in memory)
     */
    final public void openPdfFile( byte[] data ) throws PdfException
    {

        RandomAccessBuffer pdf_datafile=null;

        try
        {
            //use byte[] directly if small otherwise use Memory Map
            if(PdfFileReader.alwaysCacheInMemory ==-1 || data.length<PdfFileReader.alwaysCacheInMemory)
                pdf_datafile = new RandomAccessDataBuffer( data );
            else{ //cache as file and access via RandomAccess

                //pdf_datafile = new RandomAccessMemoryMapBuffer( data ); old version very slow

                try {

                    File file=File.createTempFile("page",".bin", new File(ObjectStore.temp_dir));
                    tempFileName=file.getAbsolutePath();

                    //file.deleteOnExit();

                    java.io.FileOutputStream a =new java.io.FileOutputStream(file);

                    a.write(data);
                    a.flush();
                    a.close();

                    pdf_datafile = new RandomAccessFileBuffer( tempFileName,"r");
                } catch (Exception e) {
                    e.printStackTrace();
                    //LogWriter.writeLog("Unable to save jpeg " + name);

                }
            }

            objectReader.init(pdf_datafile);

            objectDecoder.init(objectReader);

            eof = pdf_datafile.length();
            //pdf_datafile = new RandomAccessFile( filename, "r" );

        }catch( Exception e ){

            LogWriter.writeLog( "Exception " + e + " accessing file" );
            throw new PdfException( "Exception " + e + " accessing file" );
        }
    }



    /**handle onto JS object*/
    private Javascript javascript;

    /**pass in Javascript object from JPedal*/
    public void setJavaScriptObject(Javascript javascript) {
        this.javascript=javascript;
    }

    public void checkResolved(PdfObject pdfObject) {
        objectDecoder.checkResolved(pdfObject);
    }


    public byte[] readStream(PdfObject obj, boolean cacheValue, boolean decompress, boolean keepRaw, boolean isMetaData, boolean isCompressedStream, String cacheFile) {
        return objectDecoder.readStream(obj, cacheValue, decompress, keepRaw, isMetaData, isCompressedStream, cacheFile);
    }

    public void readObject(PdfObject pdfObject) {
        objectDecoder.readObject(pdfObject);
    }


}