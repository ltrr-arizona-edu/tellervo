/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2011, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * CCITT.java
  * ---------------
 */
package org.jpedal.io.filter;

import org.jpedal.io.*;
import org.jpedal.objects.raw.PdfDictionary;
import org.jpedal.objects.raw.PdfObject;
import org.jpedal.sun.TIFFFaxDecoder;
import org.jpedal.utils.LogWriter;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.util.Map;

/**
 * CCITT
 */
public class CCITT extends BaseFilter implements PdfFilter {

    private final int width;
    private final int height;

    private boolean EncodedByteAligned=false;


    public CCITT(PdfObject decodeParms, int width, int height) {

        super(decodeParms);

        this.width=width;
        this.height=height;

        // check JAI loaded on first call
        JAIHelper.confirmJAIOnClasspath();

        //get EncodedByteAligned
        if(decodeParms!=null)
            EncodedByteAligned=decodeParms.getBoolean(PdfDictionary.EncodedByteAlign);

    }

    public byte[] decode(byte[] data) throws Exception {

        /**
         * if NOT byte aligned
         * try new tiff decoder using JAI first fixes several
         * bugs in old code -note it has some new bugs missing
         * in the old code :-(
         */

        // flag set to ensure that only new code gets execued
        data = decodeCCITT(data);


        return data;
    }

    public void decode(BufferedInputStream bis, BufferedOutputStream streamCache, String cacheName, Map cachedObjects) throws Exception {

        int size = bis.available();
        byte[] data = new byte[size];
        bis.read(data);
        data = decodeCCITT(data);


        streamCache.write(data);
    }

    private byte[] decodeCCITT(byte[] data) throws Exception {
        /**
         * if NOT byte aligned
         * try new tiff decoder using JAI first fixes several
         * bugs in old code -note it has some new bugs missing
         * in the old code :-(
         */

        // flag set to ensure that only new code gets execued
        final boolean newCCITT = true;


        //System.out.println("-> K = " + DecodeParms.getInt(PdfDictionary.K) + " width = " +width);
        /** if it fails or not called, fall back to old version */

        if(newCCITT  && decodeParms.getInt(PdfDictionary.K)==0){
            org.jpedal.decompression.CCITTFactory ccitt = new org.jpedal.decompression.CCITTFactory(data, width, height, decodeParms);
            data = ccitt.decode();
            //@mariusz
            //}else if (newCCITT  && DecodeParms.getInt(PdfDictionary.K)>0){
            //CCITTMix mix = new CCITTMix(data, width, height, DecodeParms);
            //mix.dummy();
        }else{

            //<start-me>
            //not currently used
            if (1==2 && !EncodedByteAligned &&(JAIHelper.isJAIused() && data != null)) {
                TiffDecoder decode = new TiffDecoder(width, height,decodeParms, data);
                data = decode.getRawBytes();
            }else

                //<end-me>
                data = ccittDecode(data, decodeParms, width,height);
        }
        return data;
    }


    /**
     * ccitt decode using Sun class
     */
    private static byte[] ccittDecode(byte[] data, PdfObject DecodeParms, int width, int height) throws Exception {

        // flag to show if default is black or white
        boolean isBlack = false;
        int columns = 1728;
        int rows = height;
        int k = 0;
        boolean isByteAligned = false;

        if(DecodeParms!=null){

            isBlack = DecodeParms.getBoolean(PdfDictionary.BlackIs1);

            int columnsSet = DecodeParms.getInt(PdfDictionary.Columns);
            if(columnsSet!=-1)
                columns=columnsSet;

            isByteAligned = DecodeParms.getBoolean(PdfDictionary.EncodedByteAlign);

            k = DecodeParms.getInt(PdfDictionary.K);

            int rowsSet = DecodeParms.getInt(PdfDictionary.Rows);
            if(rowsSet!=-1)
                rows=rowsSet;
        }

        return sunCCITTDecode(data, isBlack, columns, rows, k, isByteAligned);
    }

    private static byte[] sunCCITTDecode(byte[] data, boolean isBlack, int columns,
                                         int rows, int k, boolean isByteAligned) {
        byte[] processed_data = new byte[rows * ((columns + 7) >> 3)]; // will
        // be
        // resized
        // if
        // needed
        // 9allow
        // for
        // not a
        // full
        // 8
        // bits

        try {

            TIFFFaxDecoder tiff_decode = new TIFFFaxDecoder(1, columns, rows);

            // use Sun TIFFFaxDecoder class
            if (k == 0)
                tiff_decode.decode1D(processed_data, data, 0, rows);
            else if (k > 0)
                tiff_decode.decode2D(processed_data, data, 0, rows, 1);
            else if (k < 0)
                tiff_decode.decodeT6(processed_data, data, 0, rows, 0,
                        isByteAligned);

            // invert image if needed -
            // ultimately will be quicker to add into decode
            if (!isBlack) {
                for (int i = 0; i < processed_data.length; i++)
                    processed_data[i] = (byte) (255 - processed_data[i]);
            }
        } catch (Exception e) {
            LogWriter.writeLog("Exception " + e + " accessing CCITT filter "
                    + e);

        }

        return processed_data;
    }
}
