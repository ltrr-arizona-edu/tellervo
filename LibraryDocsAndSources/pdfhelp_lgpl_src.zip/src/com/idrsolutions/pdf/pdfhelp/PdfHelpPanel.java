package com.idrsolutions.pdf.pdfhelp;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.Map.Entry;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;

import org.jpedal.PdfDecoder;
import org.jpedal.examples.simpleviewer.Commands;
import org.jpedal.examples.simpleviewer.SimpleViewer;
import org.jpedal.examples.simpleviewer.Values;
import org.jpedal.examples.simpleviewer.utils.FileFilterer;
import org.jpedal.exception.PdfException;
import org.jpedal.grouping.DefaultSearchListener;
import org.jpedal.grouping.PdfGroupingAlgorithms;
import org.jpedal.grouping.SearchType;
import org.jpedal.objects.PdfPageData;
import org.jpedal.utils.BrowserLauncher;
import org.jpedal.utils.SwingWorker;

import com.idrsolutions.pdf.pdfhelp.gui.FileNode;
import com.idrsolutions.pdf.pdfhelp.gui.FileTreeCellRenderer;
import com.idrsolutions.pdf.pdfhelp.gui.JTabbedPaneWithCloseIcons;
import com.idrsolutions.pdf.pdfhelp.gui.NonWordWrapTextPane;
import com.idrsolutions.pdf.pdfhelp.gui.ResultNode;
import com.idrsolutions.pdf.pdfhelp.gui.URLDownloader;

public class PdfHelpPanel extends JPanel implements Serializable {
	private JTree files;
	private String[] fileList;
	private JTextField searchBox;
	private Map filesAndNodes = new LinkedHashMap();
	private JProgressBar overallProgress, fileProgress;
	private JLabel currentFileLabel;
	private SwingWorker searcher;

	private boolean isSearch = false;
	private JButton searchButton;
	private JTabbedPaneWithCloseIcons resultTabs;

	private Map viewers = new HashMap();
	private JSplitPane splitPane;

	private String openLocation;


	
	final private static String separator = System.getProperty("file.separator");
	final private static String PDFcache = System.getProperty("user.dir") + separator + ".pdfhelp" + separator;
	
	private List checkedEncryptedFiles = new ArrayList();
	

	/** can user add additional file*/
	private final boolean developerMode;

	public final static String version="20110421";


	/**
	 * Main constructor for initializing the PdfHelpPanel.  Two parameters are needed.  A list of default
	 * file locations, and a flag indicating whether or not to run in developer mode. <br/><br/>
	 * 
	 * Array of locations for the PDF files.
	 * <UL>
	 * <li>Can be an absolute file path of a local location on disk <br/>
	 * <li>A directory path which will be scanned recursively, adding all PDFs found to the file list<br/>
	 * <li>A URL<br/>
	 * <li>A classpath location <br/><br/>
	 * </UL>
	 * Examples:-
	 * <UL>
	 * <li>"C:/file.pdf"
	 * <li>"C:/PdfFiles/"
	 * <li>"http://www.jpedal.org/jpedal.pdf"
	 * <li>"jar:/com/idrsolutions/pdf/pdfhelp/res/jpedal.pdf"
	 * </UL>
	 * 
	 * @param locations Default locations to automatically add to file list.  If you don't wish
	 * to pass in any files by default, either pass in an empty String array, or null.
	 * @param developerMode If true, the application will be run in developer mode so the
	 * user can add and remove files from the list.  If false, end user mode will be enabled, so
	 * only the given files will be displayed, and the user won't be able to add or remove any files.
	 */
	public PdfHelpPanel(String[] locations, boolean developerMode) {
		this.developerMode = developerMode;
		init(locations);
	}

	/**
	 * array of locations for the PDF files.
	 * Can be filepath, directory path, URL or classpath
	 * Examples:-
	 * "C:/file.pdf", "C:/PdfFiles/", "http://www.jpedal.org/jpedal.pdf", "/org/application/pdfs/file.pdf"
	 */
//	public PdfHelpPanel(String[] locations){
//		developerMode = false;
//		init(locations);
//	}


	/**
	 * single PDF to open
	 */
	public PdfHelpPanel(String pdfFile) {
		developerMode = false;
		
		String[] locations;
		if(pdfFile == null) {
			locations = null;
		} else {
			locations = new String[] { pdfFile };
		}
		init(locations);
	}

	public PdfHelpPanel() {
		developerMode = false;
		init(null);
	}
	
	private void init(String[] locations) {
		if(locations == null)
			fileList = new String[] {""};
		else
			fileList = locations;

		setupWindow();
        
		File cacheLocation = new File(PDFcache);
		if(!cacheLocation.exists())
			cacheLocation.mkdirs();
		
        new SwingWorker() {
			public Object construct() {
				loadPDFs();
				return null;
			}
		}.start();
    }

	/** method to access through bean */
	public void setFileLocations(String[] fileLocations) {
		
		/** reset/remove all locations so far */
		loadPDFs();
		resultTabs.removeAll();
		overallProgress.setValue(0);
		fileProgress.setValue(0);
		
		/** add files */
		this.fileList = fileLocations;
		loadPDFs();
	}
	
	private void searchPDFs() throws InterruptedException {
		/** if running terminate first */
		if ((searcher != null))
			searcher.interrupt();

		resetTree();

		searchButton.setText("Stop");
		isSearch = true;
		searcher = new SwingWorker() {
			public Object construct() {
				
				List results = new ArrayList();
				FileNode fileNode = null;
				
				try {
					int filesProcessed = 0;
					overallProgress.setValue(0);

					for (Iterator it = filesAndNodes.keySet().iterator(); it.hasNext();) {
						if (Thread.interrupted()) {
							throw new InterruptedException();
						}

						results.clear();
						
						fileProgress.setValue(0);
						
						boolean checkedContinue = false;

						String absoluteFilePath = (String) it.next();

						fileNode = (FileNode) filesAndNodes.get(absoluteFilePath);
						
						File fileObject = new File(absoluteFilePath);

						String fileName = fileObject.getName();
						currentFileLabel.setText("File: " + fileName);

						PdfDecoder decodePdf = null;
						try {
							decodePdf = new PdfDecoder(false);
							decodePdf.setExtractionMode(PdfDecoder.TEXT); //extract just text
							decodePdf.init(true);

							if(absoluteFilePath.toLowerCase().startsWith("jar:/")) { // PDF is stored on the classpath (in the jar)
								byte[] bytes = getClasspathBytes(absoluteFilePath.replaceFirst("jar:", ""));

								decodePdf.openPdfArray(bytes);
							} else if (absoluteFilePath.toLowerCase().startsWith("http:/")) { // PDF is stored as a URL
								String cacheLocation = PDFcache + separator + fileName;
								
								URL url = new URL(absoluteFilePath);
								
								File cacheFile = new File(PDFcache);
								if (!cacheFile.exists())
									cacheFile.mkdirs();

								/** download if not stored or load from cache */
								final File tmpFile = new File(cacheLocation);
								if (!tmpFile.exists()) {
									
									URLDownloader downloader = new URLDownloader(url, tmpFile, PdfHelpPanel.this);
									downloader.setVisible(true);

									if(downloader.wasCancelled()) {
										fileProgress.setValue(fileProgress.getMaximum());
										addMatchesToFileNode(results, fileNode);

										decodePdf.flushObjectValues(true); //flush any text data read

										/**close the pdf file*/
										decodePdf.closePdfFile();

										tmpFile.delete();
										
										filesProcessed++;
										overallProgress.setValue(filesProcessed);

										continue;

									}  
								}
								
								//URL cached on disk so load from there
								decodePdf.openPdfFile(cacheLocation);
								
							} else { // PDF is stored locally on the users computer
								decodePdf.openPdfFile(absoluteFilePath);
							}
						} catch (Exception ex) {
							if(ex.getMessage().indexOf("encrypt") != -1) { // encryption exception
								
								if(!checkedEncryptedFiles.contains(absoluteFilePath)) {
									checkedEncryptedFiles.add(absoluteFilePath);
									JOptionPane.showMessageDialog(getTopLevelAncestor(), fileName + " is encrypted and JPedal needs an additional library to decode on the classpath (we recommend bouncycastle library)." +
										"There is additional explanation at http://www.jpedal.org/support_AddJars.php", "Encryption", JOptionPane.ERROR_MESSAGE);
								}
								
								fileProgress.setValue(fileProgress.getMaximum());
								
								addMatchesToFileNode(results, fileNode);

								decodePdf.flushObjectValues(true); //flush any text data read

								/**close the pdf file*/
								decodePdf.closePdfFile();

								filesProcessed++;
								overallProgress.setValue(filesProcessed);

								continue;
							} else {
							}
						}
						
						//page range
						int start = 1, end = decodePdf.getPageCount();
						
						fileProgress.setMaximum(end);

						String textToFind = searchBox.getText();

						int matchesFoundInFile = 0;
						
						for (int page = start; page < end + 1; page++) { //read pages
							if (Thread.interrupted()) {
								throw new InterruptedException();
							}

							if(matchesFoundInFile > 1000 && !checkedContinue) {
								int result = JOptionPane.showConfirmDialog(PdfHelpPanel.this, "Over 1000 matches have been found in " + fileNode.getFileName() + 
										", do you wish to continue searching this PDF?", "Continue Searching?", JOptionPane.YES_NO_OPTION, 
										JOptionPane.QUESTION_MESSAGE);
								
								if(result == JOptionPane.YES_OPTION) { //continue searching
									checkedContinue = true;
								} else { // stop searching this file, and move onto the next
									fileProgress.setValue(fileProgress.getMaximum());
									
									break;
								}
							}
							
							//decode the page
							decodePdf.decodePage(page);

							/** create a grouping object to apply grouping to data*/
							PdfGroupingAlgorithms currentGrouping = decodePdf.getGroupingObject();
							if (currentGrouping != null) {

								PdfPageData currentPageData = decodePdf.getPdfPageData();

								currentGrouping.generateTeasers();

								currentGrouping.setIncludeHTML(true);

								int x1 = currentPageData.getMediaBoxX(page);
								int x2 = currentPageData.getMediaBoxWidth(page);
								int y1 = currentPageData.getMediaBoxY(page);
								int y2 = currentPageData.getMediaBoxHeight(page);

								try {
									SortedMap highlightsWithTeasers = currentGrouping.findMultipleTermsInRectangleWithMatchingTeasers(
											x1, y1, x2, y2, currentPageData.getRotation(page), page,
											new String[] { textToFind },
											SearchType.DEFAULT,
											new DefaultSearchListener());

									Iterator iter = highlightsWithTeasers.entrySet().iterator();
									while (iter.hasNext()) {
										Map.Entry e = (Map.Entry) iter.next();

										Rectangle highlight = (Rectangle) e.getKey();

										String teaser = (String) e.getValue();

										ResultNode result = new ResultNode(teaser, highlight, absoluteFilePath, fileName, page);
										results.add(result);
										
										matchesFoundInFile++;
									}
								} catch (PdfException ex) {
									decodePdf.closePdfFile();
								}
							}

							//remove data once written out
							decodePdf.flushObjectValues(false);

							fileProgress.setValue(page);
						}

						addMatchesToFileNode(results, fileNode);

						/**
						 * flush data structures - not strictly required but included
						 * as example
						 */
						decodePdf.flushObjectValues(true); //flush any text data read

						/**close the pdf file*/
						decodePdf.closePdfFile();

						filesProcessed++;
						overallProgress.setValue(filesProcessed);
					}

					searchButton.setText("Search");
					isSearch = false;

					currentFileLabel.setText("File: ");
				} catch (InterruptedException e) {
					
					/** 
					 * thread has been interupted, so we need to add whatever matches we have so far, 
					 * and then stop searching 
					 */
					if(results != null && fileNode != null)
						addMatchesToFileNode(results, fileNode);
					
				} catch (Exception e) {
				}

				return null;
			}
		};

		searcher.start();
	}

	private void openPDF(final String absoluteFilePath, final String fileName, final int pageNumber, final Rectangle highlight) {

		if(checkedEncryptedFiles.contains(absoluteFilePath)) {
			JOptionPane.showMessageDialog(getTopLevelAncestor(), fileName + " is encrypted and JPedal needs an additional library to decode on the classpath (we recommend bouncycastle library)." +
					"There is additional explanation at http://www.jpedal.org/support_AddJars.php", "Encryption", JOptionPane.ERROR_MESSAGE);
			
			return;
		}
		
		final JPanel panel = new JPanel();

		if(viewers.containsKey(absoluteFilePath)) {
			SimpleViewer viewer = (SimpleViewer) viewers.get(absoluteFilePath);

            //viewer.setupViewer();
            
			initSimpleViewer(absoluteFilePath, fileName, pageNumber, highlight, viewer, true);

			int index = resultTabs.indexOfTab(fileName);

			resultTabs.setSelectedIndex(index);
		} else {

			/** check to see if we're dealing with an un-downloaded URL first */
			if(absoluteFilePath.toLowerCase().startsWith("http:/")) {
				try {
					String cacheLocation = PDFcache + separator + fileName;
					final File tmpFile = new File(cacheLocation);
					if (!tmpFile.exists()) {
						URLDownloader downloader = new URLDownloader(new URL(absoluteFilePath), tmpFile, PdfHelpPanel.this);
						downloader.setVisible(true);
						
						if(downloader.wasCancelled()) {
							tmpFile.delete();
							return;
						}
					}
				} catch (Exception e) {
				}
			}
			
			JPanel progressPanel = new JPanel();
			progressPanel.setLayout(new BoxLayout(progressPanel, BoxLayout.Y_AXIS));
			
			JProgressBar bar = new JProgressBar();
			bar.setAlignmentX(JComponent.LEFT_ALIGNMENT);
			bar.setIndeterminate(true);
			
			progressPanel.add(Box.createVerticalGlue());
			progressPanel.add(new JLabel("Loading PDF ..."));
			progressPanel.add(bar);
			progressPanel.add(Box.createVerticalGlue());
			
			resultTabs.addTab(absoluteFilePath, progressPanel);
			
			final int indexOfNewTab = resultTabs.getTabCount() - 1;
			resultTabs.setSelectedIndex(indexOfNewTab);
			
			new SwingWorker() {
				public Object construct() {
		            SimpleViewer viewer = new SimpleViewer(panel, SimpleViewer.PREFERENCES_PDFHELP);
		            
		            viewer.setupViewer();
		            
		            boolean success = initSimpleViewer(absoluteFilePath, fileName, pageNumber, highlight, viewer, false);
		            
		            if(success) {
		            	resultTabs.setComponentAt(indexOfNewTab, panel);
		            	viewers.put(absoluteFilePath, viewer);
		            } else {
		            	resultTabs.removeTabAt(indexOfNewTab);
		            }
		            
		            return null;
				}
			}.start();
        }
	}

	private boolean initSimpleViewer(String absoluteFilePath, String fileName, int pageNumber, 
			Rectangle highlight, final SimpleViewer viewer, boolean isFileOpen) {
		
		if(!isFileOpen) {
			try {
				if(absoluteFilePath.toLowerCase().startsWith("jar:/")) { // load from classpath

					byte[] bytes = getClasspathBytes(absoluteFilePath.replaceFirst("jar:", ""));

					Object[] input = new Object[]{bytes, absoluteFilePath};
					viewer.executeCommand(Commands.OPENFILE, input);

				} else if(absoluteFilePath.toLowerCase().startsWith("http:/")) { // load from URL 
					String cacheLocation = PDFcache + separator + fileName;
					Object[] input = new Object[]{cacheLocation};
					viewer.executeCommand(Commands.OPENFILE, input);
				} else {
					Object[] input = new Object[]{absoluteFilePath};
					viewer.executeCommand(Commands.OPENFILE, input);
				}
			} catch (Exception e) {
				if(e.getMessage().indexOf("encrypt") != -1) { // encryption exception
					JOptionPane.showMessageDialog(getTopLevelAncestor(), fileName + " is encrypted and JPedal needs an additional library to decode on the classpath (we recommend bouncycastle library)." +
							"There is additional explanation at http://www.jpedal.org/support_AddJars.php", "Encryption", JOptionPane.ERROR_MESSAGE);
				
					checkedEncryptedFiles.add(absoluteFilePath);
				} else {
				}
				
				return false;
			}
		}

		/**
		 * we need to wait till page 1 is loaded before loading the page
		 * we need to jump to, else when trying to load the new page we
		 * will be locked out, so our page changing request will be ignored
		 */
		pause(100);

        viewer.executeCommand(Commands.GOTO, new String[]{String.valueOf(pageNumber)});

        pause(100);
        
    	viewer.executeCommand(Commands.HIGHLIGHT, new Object[]{new Rectangle[]{highlight},new Integer(pageNumber)});

		viewer.executeCommand(Commands.SCROLL, new Rectangle[]{highlight});
		
		return true;
	}

	private void pause(long time) {
		while(Values.isProcessing()) {
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
			}
		}
	}

	private void execute() {
		if(!isSearch){
			if(searchBox.getText().length() == 0) {
				JOptionPane.showMessageDialog(getTopLevelAncestor(), "Please enter a term to search for", "Search", JOptionPane.ERROR_MESSAGE);
			} else if (filesAndNodes.isEmpty()) {
				JOptionPane.showMessageDialog(getTopLevelAncestor(), "There are no PDF files open to search in", "Search", JOptionPane.ERROR_MESSAGE);
			} else {
			
				try {
					searchPDFs();
				} catch (Exception e) {
				}
			}
		}else{
			searcher.interrupt();
			isSearch = false;
			searchButton.setText("Search");

			overallProgress.setValue(overallProgress.getMaximum());
			fileProgress.setValue(fileProgress.getMaximum());
			currentFileLabel.setText("File: ");
		}
	}

	private void addFile() {
		
		boolean finished = false;
		
		while (!finished) {
			final JFileChooser chooser = new JFileChooser(openLocation);
	
			chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
	
			String[] pdf = new String[] { "pdf" };
			chooser.addChoosableFileFilter(new FileFilterer(pdf, "Pdf (*.pdf)"));
	
			final int state = chooser.showOpenDialog(PdfHelpPanel.this);
	
			final File file = chooser.getSelectedFile();
	
			if (file != null && state == JFileChooser.APPROVE_OPTION) {
				openLocation = file.getAbsolutePath();
	
				if(filesAndNodes.containsKey(openLocation)) {
					JOptionPane.showMessageDialog(getTopLevelAncestor(), "This file already exists in your list. "
							+ "Please choose another file", "Invalid File", JOptionPane.ERROR_MESSAGE);
				} else if (!openLocation.toLowerCase().endsWith(".pdf")) {
					JOptionPane.showMessageDialog(getTopLevelAncestor(), "You can only add valid PDF files to the file list", 
							"Invalid File", JOptionPane.ERROR_MESSAGE);
				} else {
					FileNode node = new FileNode(file.getAbsolutePath(), file.getName());
					
					filesAndNodes.put(file.getAbsolutePath(), node);
					
					DefaultTreeModel model = (DefaultTreeModel) files.getModel();
					DefaultMutableTreeNode root = (DefaultMutableTreeNode) model.getRoot();
					root.insert(node, root.getChildCount());
					model.reload();
					
					int newMaximum = filesAndNodes.size();
					
					//is overallProgress full? If so keep it full
					if(overallProgress.getValue() == overallProgress.getMaximum() && overallProgress.getValue() != 0) {
						overallProgress.setMaximum(newMaximum);
						overallProgress.setValue(newMaximum);
					} else {
						overallProgress.setMaximum(newMaximum);
					}
					
					finished = true;
				}
			} else {
				finished = true;
			}
		}
	}

	private void addURL() {
		boolean finished = false;
		
		String absoluteFilePath = "";
		while (!finished) {
			absoluteFilePath = JOptionPane.showInputDialog(getTopLevelAncestor(), "Please enter the pdf URL:", absoluteFilePath);
			if (absoluteFilePath == null)
				return;

			boolean exists = doesURLExist(absoluteFilePath);
			
			String[] bits = absoluteFilePath.split("/");
			
			String fileName = bits[bits.length - 1];

			if (!exists || !fileName.toLowerCase().endsWith(".pdf")) { //either invalid entry or URL does not exist
				JOptionPane.showMessageDialog(getTopLevelAncestor(), "The URL you have entered does not point to a valid PDF. "
						+ "Please re-enter a valid URL", "Invalid URL", JOptionPane.ERROR_MESSAGE);
			} else {

				if(filesAndNodes.containsKey(absoluteFilePath)) {
					JOptionPane.showMessageDialog(getTopLevelAncestor(), "This file already exists in your list. "
							+ "Please re-enter a valid URL", "Invalid URL", JOptionPane.ERROR_MESSAGE);
				} else {
					FileNode node = new FileNode(absoluteFilePath, fileName);
	
					filesAndNodes.put(absoluteFilePath, node);
	
					DefaultTreeModel model = (DefaultTreeModel) files.getModel();
					DefaultMutableTreeNode root = (DefaultMutableTreeNode) model.getRoot();
					root.insert(node, root.getChildCount());
					model.reload();
	
					int newMaximum = filesAndNodes.size();
					
					//is overallProgress full? If so keep it full
					if(overallProgress.getValue() == overallProgress.getMaximum()) {
						overallProgress.setMaximum(newMaximum);
						overallProgress.setValue(newMaximum);
					} else {
						overallProgress.setMaximum(newMaximum);
					}
					
					finished = true;
				}
			}
		}
	}
	
	private void removeFile() {
		TreePath selectionPath = files.getSelectionPath();

		if(selectionPath != null) {
			DefaultMutableTreeNode selection = (DefaultMutableTreeNode) selectionPath.getLastPathComponent();

			if (selection instanceof FileNode) {
				FileNode fileNode = (FileNode) selection;

				int result = JOptionPane.showConfirmDialog(this, "Are you sure you with to remove " + selection.getUserObject() + " from your file list?","Remove?",JOptionPane.YES_NO_OPTION);

				if(result == JOptionPane.YES_OPTION) {
					String absoluteFilePath = fileNode.getAbsoluteFilePath();

                    filesAndNodes.remove(absoluteFilePath);
                    viewers.remove(absoluteFilePath);

                    for(int i = 0; i < resultTabs.getTabCount(); i++) {
						String tooltip = resultTabs.getToolTipTextAt(i);
						if(tooltip.equals(absoluteFilePath)) {
							resultTabs.removeTabAt(i);

							break;
						}
					}

					selection.removeFromParent();
					((DefaultTreeModel) files.getModel()).reload();
					
					//is overallProgress full? If so keep it full
					if(overallProgress.getValue() == overallProgress.getMaximum()) {
						int newMaximum = filesAndNodes.size();
						
						if(newMaximum == 0) {
							overallProgress.setValue(1);
							overallProgress.setMaximum(1);
						} else {
							overallProgress.setMaximum(newMaximum);
						}
					} else { 
						//otherwise overallProgress is empty, so keep it empty
					}
				}
			}
		}
	}

	private void resetFileList() {
		int result = JOptionPane.showConfirmDialog(this, "Are you sure you wish to reset your file list?",
				"Reset?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

		if (result == JOptionPane.YES_OPTION) {
			loadPDFs();
			resultTabs.removeAll();
			overallProgress.setValue(0);
			fileProgress.setValue(0);
		}
	}

	private void produceFileList() {
		final NonWordWrapTextPane textPane = new NonWordWrapTextPane ();
		JScrollPane scrollPane = new JScrollPane(textPane);
		scrollPane.getViewport().setBackground(Color.white);

		SimpleAttributeSet plain = new SimpleAttributeSet();
        Document doc = textPane.getDocument();

		SimpleAttributeSet mauve = new SimpleAttributeSet();
		StyleConstants.setForeground(mauve, new Color(127, 0, 85));
		StyleConstants.setBold(mauve, true);

        SimpleAttributeSet blue = new SimpleAttributeSet();
        StyleConstants.setForeground(blue, Color.blue);

		try {
			doc.insertString(doc.getLength(), "String[] locations = ", plain);
			doc.insertString(doc.getLength(), "new ", mauve);
			doc.insertString(doc.getLength(), "String[] {\n", plain);

			for (Iterator it = filesAndNodes.keySet().iterator(); it.hasNext();) {
				String absoluteFilePath = (String) it.next();
				
				absoluteFilePath = absoluteFilePath.replaceAll("\\\\", "/");
				
				doc.insertString(doc.getLength(), "\t\"" + absoluteFilePath + "\" ", blue);
				doc.insertString(doc.getLength(), ",\n", plain);
			}

			doc.insertString(doc.getLength(), "};\n\n", plain);
			doc.insertString(doc.getLength(), "PdfHelpPanel pdfHelpPanel = ", plain);
			doc.insertString(doc.getLength(), "new ", mauve);
			doc.insertString(doc.getLength(), "PdfHelpPanel(locations, ", plain);
			doc.insertString(doc.getLength(), "false", mauve);
			doc.insertString(doc.getLength(), ");\n\n", plain);
            doc.insertString(doc.getLength(), "//pdfHelpPanel.displayHelp(); //display in a popup\n\n", plain);
            doc.insertString(doc.getLength(), "//or look at \n", plain);
            doc.insertString(doc.getLength(), "// com.idrsolutions.pdf.pdfhelp.examples.Example for sample code\n", plain);
            doc.insertString(doc.getLength(), "//PdfHelpPanel is a JPanel so you can use Standard Swing containers", plain);

		} catch (BadLocationException e) {
		}

		textPane.setEditable(false);
		scrollPane.setAlignmentX(JComponent.LEFT_ALIGNMENT);

		JPanel topPanel = new JPanel();
		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
		JLabel comp = new JLabel("Add this code to your Java program");
		comp.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 0));
		comp.setAlignmentX(JComponent.LEFT_ALIGNMENT);
		topPanel.add(comp);
		topPanel.add(scrollPane);

		final JDialog dialog = new JDialog((JFrame) null, "File List", true);
		dialog.setLayout(new BorderLayout());
		dialog.add(topPanel, BorderLayout.CENTER);

		JButton copy = new JButton("Copy Code To Clipboard");
		copy.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Toolkit.getDefaultToolkit().getSystemClipboard().setContents(
						new StringSelection(textPane.getText()), null);
			}
		});

		JButton close = new JButton("Close");
		close.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				dialog.setVisible(false);
			}
		});

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.add(copy);
		buttonPanel.add(close);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));

		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
		bottomPanel.add(new JSeparator(JSeparator.HORIZONTAL));
		bottomPanel.add(buttonPanel);

		dialog.add(bottomPanel, BorderLayout.SOUTH);

		dialog.setSize(550,300);
		dialog.setLocationRelativeTo(getTopLevelAncestor());
		dialog.setVisible(true);
	}
	
	private byte[] getClasspathBytes(String fileName) {
		byte[] data = null;
		try {
			InputStream is = getClass().getResourceAsStream(fileName);

			BufferedInputStream bis = new BufferedInputStream(is);
			data = new byte[bis.available()];
			bis.read(data);

		} catch (Exception e) {
		}

		return data;
	}
	
	public void recurseDirectories(File fileObject, DefaultMutableTreeNode root, ArrayList nonExistantFiles) {
		if (fileObject.isDirectory()) {
			String[] children = fileObject.list();
			for (int i = 0; i < children.length; i++) {
				recurseDirectories(new File(fileObject, children[i]), root, nonExistantFiles);
			}
		} else {
			String absoluteFilePath = fileObject.getAbsolutePath();
			if(fileObject.exists()) {
				if(absoluteFilePath.toLowerCase().endsWith(".pdf")) {
					FileNode node = new FileNode(absoluteFilePath, fileObject.getName());
	
					filesAndNodes.put(absoluteFilePath, node);
	
					root.insert(node, root.getChildCount());
				}
			} else {
				nonExistantFiles.add(absoluteFilePath);
			}
		}
	}

	private void loadPDFs() {
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("File List");
		DefaultTreeModel defaultTreeModel = new DefaultTreeModel(root);

        //@simon - causes Mac to just hang unless called via SwingUtilities
        files.setModel(defaultTreeModel);

        filesAndNodes.clear();
		viewers.clear();

		ArrayList nonExistantFiles = new ArrayList();
		
		for (int i = 0; i < fileList.length; i++) {
			String absoluteFilePath = fileList[i];
			
			if(absoluteFilePath.length()  == 0)
				continue;
			
			File fileObject = new File(absoluteFilePath);

            if(fileObject.isDirectory()) {
				recurseDirectories(fileObject, root, nonExistantFiles);
			} else {
				String fileName = fileObject.getName();
				if(absoluteFilePath.toLowerCase().startsWith("jar:")) { // is classpath
					String replaceFirst = absoluteFilePath.replaceFirst("jar:", "");
					boolean doesResourceExist = getClass().getResource(replaceFirst) != null;
					
					if(doesResourceExist) {
						FileNode node = new FileNode(absoluteFilePath, fileName);
						filesAndNodes.put(absoluteFilePath, node);
						root.insert(node, root.getChildCount());
						
					} else {
						nonExistantFiles.add(absoluteFilePath);
					}
				} else if(absoluteFilePath.toLowerCase().startsWith("http:")) { // is URL
					boolean doesResourceExist = doesURLExist(absoluteFilePath);
					
					if(doesResourceExist) {
						if(absoluteFilePath.toLowerCase().endsWith(".pdf")) {
							FileNode node = new FileNode(absoluteFilePath, fileName);
							filesAndNodes.put(absoluteFilePath, node);
							root.insert(node, root.getChildCount());
						}
						
					} else {
						nonExistantFiles.add(absoluteFilePath);
					}
				} else { // is local
					if(fileObject.exists()) {
						FileNode node = new FileNode(absoluteFilePath, fileName);
						filesAndNodes.put(absoluteFilePath, node);
						root.insert(node, root.getChildCount());
					} else {
						nonExistantFiles.add(absoluteFilePath);
					}
				}
			}
		}

		if(!nonExistantFiles.isEmpty()) {
			displayNonExistantFilesBox(nonExistantFiles);
		}
		
        overallProgress.setMinimum(0);
        if(!filesAndNodes.isEmpty())
        	overallProgress.setMaximum(filesAndNodes.size());

		files.expandRow(0);
		
		try {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					files.updateUI();
				}
			});
		} catch (Exception e) {
		}
    }

	private void displayNonExistantFilesBox(ArrayList nonExistantFiles) {
		final NonWordWrapTextPane textPane = new NonWordWrapTextPane ();
		JScrollPane scrollPane = new JScrollPane(textPane);
		scrollPane.getViewport().setBackground(Color.white);

		SimpleAttributeSet plain = new SimpleAttributeSet();
		Document doc = textPane.getDocument();

		try {
			for (Iterator it = nonExistantFiles.iterator(); it.hasNext();) {
				String absoluteFilePath = (String) it.next();
				doc.insertString(doc.getLength(), absoluteFilePath + "\n", plain);
			}
		} catch (BadLocationException e) {
		}

		textPane.setEditable(false);
		scrollPane.setAlignmentX(JComponent.LEFT_ALIGNMENT);

		JPanel topPanel = new JPanel();
		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
		JLabel comp = new JLabel("The following PDFs could not be found, so were not added to the File List:");
		comp.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 0));
		comp.setAlignmentX(JComponent.LEFT_ALIGNMENT);
		topPanel.add(comp);
		topPanel.add(scrollPane);

		final JDialog dialog = new JDialog((JFrame) null, "Non Existant Files", true);
		dialog.setLayout(new BorderLayout());
		dialog.add(topPanel, BorderLayout.CENTER);

		JButton close = new JButton("Close");
		close.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				dialog.setVisible(false);
			}
		});
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.add(close);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));

		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
		bottomPanel.add(new JSeparator(JSeparator.HORIZONTAL));
		bottomPanel.add(buttonPanel);

		dialog.add(bottomPanel, BorderLayout.SOUTH);

		dialog.setSize(550,300);
		dialog.setLocationRelativeTo(getTopLevelAncestor());
		dialog.setVisible(true);
	}

	private boolean doesURLExist(String absoluteFilePath) {
		boolean doesURLExist = true;
		try {
			URL testExists = new URL(absoluteFilePath);
			URLConnection conn = testExists.openConnection();

			if (conn.getContent() == null)
				doesURLExist = false;
			
		} catch (Exception e) {
			doesURLExist = false;
		}
		
		return doesURLExist;
	}

	private void resetTree() {
		Set set = filesAndNodes.entrySet();
		for (Iterator iterator = set.iterator(); iterator.hasNext();) {
			Entry entry = (Entry) iterator.next();
			FileNode fileNode = (FileNode) entry.getValue();
			fileNode.removeAllChildren();
			fileNode.setState(FileNode.UNSET);
			fileNode.setUserObject(fileNode.getFileName());
		}

		DefaultTreeModel root = (DefaultTreeModel) files.getModel();
		root.reload();
	}

	private void setupWindow(){
		resultTabs = new JTabbedPaneWithCloseIcons(this);

		resultTabs.setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);

		setLayout(new BorderLayout());

		JPanel searchWindow = getSearchWindow();
		splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, searchWindow, resultTabs);
		splitPane.setDividerLocation(300);
		splitPane.setOneTouchExpandable(true);
		add(splitPane, BorderLayout.CENTER);
		
		setPreferredSize(new Dimension(700, 400));
	}
	
	public void removeViewerFromCollection(String absoluteFilePath) {
		viewers.remove(absoluteFilePath);
	}
	
	private JPanel getSearchWindow() {
		JPanel searchWindowPanel = new JPanel();

		searchWindowPanel.setLayout(new GridBagLayout());

		GridBagConstraints mainWindowConstraints = new GridBagConstraints();
		mainWindowConstraints.gridx = 0;
		mainWindowConstraints.gridy = 0;
		mainWindowConstraints.weightx = 1;
		mainWindowConstraints.fill = GridBagConstraints.BOTH;
		mainWindowConstraints.anchor = GridBagConstraints.NORTH;

		JToolBar toolbar = new JToolBar();
		toolbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.black));
		toolbar.setFloatable(false);
		if(developerMode) {

			JButton insertFile = new JButton();
			insertFile.setIcon(new ImageIcon(getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/insert_file.png")));
			insertFile.setToolTipText("Add File To List");
			insertFile.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					addFile();
				}
			});

			toolbar.add(insertFile);

			JButton insertURL = new JButton();
			insertURL.setIcon(new ImageIcon(getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/insert_url.png")));
			insertURL.setToolTipText("Add URL To List");
			insertURL.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					addURL();
				}
			});

			toolbar.add(insertURL);
			
			JButton remove = new JButton();
			remove.setIcon(new ImageIcon(getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/remove.png")));
			remove.setToolTipText("Remove File From List");
			remove.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					removeFile();
				}
			});

			toolbar.add(remove);

			JButton reset = new JButton();
			reset.setIcon(new ImageIcon(getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/reset.png")));
			reset.setToolTipText("Reset File List");
			reset.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					resetFileList();
				}
			});

			toolbar.add(reset);

			JButton view = new JButton();
			view.setIcon(new ImageIcon(getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/code.png")));
			view.setToolTipText("Produce PDF Help Initialization Code");
			view.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					produceFileList();
				}

			});
			toolbar.add(view);

		}       

		
		
		searchWindowPanel.add(toolbar, mainWindowConstraints);

		JButton info = new JButton(new ImageIcon(getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/information.png")));
		info.setToolTipText("PDF Help Info");
		info.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayInfoBox();
			}
		});
		JToolBar infoBar = new JToolBar();
		infoBar.setFloatable(false);
		infoBar.add(info);
		
		JPanel searchBoxPanel = new JPanel();
		searchBoxPanel.setLayout(new GridBagLayout());
		GridBagConstraints searchBoxPanelConstraints = new GridBagConstraints();
		searchBoxPanelConstraints.fill = GridBagConstraints.HORIZONTAL;
		searchBoxPanelConstraints.gridx = 0;
		searchBoxPanelConstraints.gridy = 0;
		JLabel label = new JLabel("Search Term:");
		label.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 2));
//		searchBoxPanel.add(label, searchBoxPanelConstraints);

		searchBoxPanelConstraints.gridx = 1;
		searchBoxPanelConstraints.weightx = 1;
        searchBoxPanelConstraints.insets = new Insets(0, 3, 0, 0);

		searchButton = new JButton("Search");
		searchButton.setToolTipText("Search PDF Documents");
		searchBox = new JTextField();
		searchBox.setPreferredSize(new Dimension(searchBox.getPreferredSize().width, searchButton.getPreferredSize().height));
		searchBoxPanel.add(searchBox, searchBoxPanelConstraints);

		searchBoxPanelConstraints.gridx = 2;
		searchBoxPanelConstraints.weightx = 0;
		searchBoxPanelConstraints.insets = new Insets(0,3,0,3);
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				execute();
			}
		});
		
		searchBox.addKeyListener(new KeyListener(){
			public void keyPressed(KeyEvent e) {}

			public void keyReleased(KeyEvent e) {}

			public void keyTyped(KeyEvent e) {
				if (e.getID() == KeyEvent.KEY_TYPED) {
					char key=e.getKeyChar();

					if(key=='\n'){
						execute();
					}
				}
			}
		});

		searchBoxPanel.add(searchButton, searchBoxPanelConstraints);

		searchBoxPanelConstraints.gridx = 3;
		searchBoxPanelConstraints.weightx = 0;
		
		searchBoxPanelConstraints.insets = new Insets(0,0,0,3);
		searchBoxPanel.add(infoBar, searchBoxPanelConstraints);
		
		mainWindowConstraints.gridx = 0;
		mainWindowConstraints.gridy = 1;
		mainWindowConstraints.weightx = 1;
		mainWindowConstraints.ipady = 10;
		searchWindowPanel.add(searchBoxPanel, mainWindowConstraints);

		files = new JTree();
		final TreeCellRenderer ftcr = new FileTreeCellRenderer();
		
		/** needs to be in an invokeAndWait to make work on Linux, and possibly the MAC*/
		if(SwingUtilities.isEventDispatchThread()) {
			try {
				SwingUtilities.invokeLater(new Runnable(){
					public void run() {
						files.setCellRenderer(ftcr);
					}
				});
			} catch (Exception e) {
			}
		}else {
			try {
				SwingUtilities.invokeAndWait(new Runnable(){
					public void run() {
						files.setCellRenderer(ftcr);
					}
				});
			} catch (Exception e) {
			}
		}
		
		final JPopupMenu popup = new JPopupMenu();
	    JMenuItem menuItem = new JMenuItem("Open PDF");
	    menuItem.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				FileNode fileNode = (FileNode) files.getSelectionPath().getLastPathComponent();
				openPDF(fileNode.getAbsoluteFilePath(), fileNode.getFileName(), 1, null);
			}
	    });
	    popup.add(menuItem);

		files.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 2) {
					TreePath selectionPath = files.getSelectionPath();

					if(selectionPath != null) {
						final DefaultMutableTreeNode selection = (DefaultMutableTreeNode) selectionPath.getLastPathComponent();

						if (selection instanceof ResultNode) {
                            ResultNode result = (ResultNode) selection;
                            openPDF(result.getAbsoluteFilePath(), result.getFileName(), result.getPageNumber(), result.getHighlight());
						} else if (selection instanceof FileNode){
                            FileNode result = (FileNode) selection;
                            openPDF(result.getAbsoluteFilePath(), result.getFileName(), 1, null);
                        }
					}
				}
			}

			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
			public void mousePressed(MouseEvent e) {
				maybeShowPopup(e);
		    }

		    public void mouseReleased(MouseEvent e) {
		        maybeShowPopup(e);
		    }

		    private void maybeShowPopup(MouseEvent e) {
		    	TreePath path = files.getPathForLocation(e.getX(), e.getY());
				if (path == null)
					return;
				files.setSelectionPath(path);
				
		    	if (e.isPopupTrigger()) {
		    		if(path != null) {
		    			final DefaultMutableTreeNode selection = (DefaultMutableTreeNode) path.getLastPathComponent();

		    			if (selection instanceof FileNode) {
		    				popup.show(e.getComponent(), e.getX(), e.getY());
		    			}
		    		}
		    	}
		    }
		});

		JScrollPane filesScrollPane = new JScrollPane(files,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridBagLayout());
		GridBagConstraints centerPanelConstraints = new GridBagConstraints();
		centerPanelConstraints.fill = GridBagConstraints.BOTH;
		centerPanelConstraints.gridx = 0;
		centerPanelConstraints.gridy = 0;

		centerPanelConstraints.gridx = 1;
		centerPanelConstraints.weightx = 1;
		centerPanelConstraints.weighty = 1;
		centerPanel.add(filesScrollPane, centerPanelConstraints);

		mainWindowConstraints.weighty = 1;
		mainWindowConstraints.gridy = 2;
		mainWindowConstraints.anchor = GridBagConstraints.CENTER;
		searchWindowPanel.add(centerPanel, mainWindowConstraints);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

		JButton cancel = new JButton("Cancel");
		JButton OK = new JButton("OK");

		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.add(cancel);
		buttonPanel.add(OK);

		JPanel progressPanel = new JPanel();

		progressPanel.setLayout(new BoxLayout(progressPanel, BoxLayout.Y_AXIS));
		currentFileLabel = new JLabel("File: ");
		currentFileLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		progressPanel.add(currentFileLabel);

		fileProgress = new JProgressBar(0, 1);
		fileProgress.setAlignmentX(Component.LEFT_ALIGNMENT);
		fileProgress.setStringPainted(true);
		progressPanel.add(fileProgress);

		JLabel label3 = new JLabel("Overall");
		label3.setAlignmentX(Component.LEFT_ALIGNMENT);
		progressPanel.add(label3);

		overallProgress = new JProgressBar();
		overallProgress.setAlignmentX(Component.LEFT_ALIGNMENT);
		overallProgress.setStringPainted(true);
		progressPanel.add(overallProgress);

		mainWindowConstraints.ipady = 0;
		mainWindowConstraints.gridy = 3;
		mainWindowConstraints.weighty = 0;
		searchWindowPanel.add(progressPanel, mainWindowConstraints);

		mainWindowConstraints.gridy = 3;
		mainWindowConstraints.anchor = GridBagConstraints.SOUTH;

		return searchWindowPanel;
	}

	private void addMatchesToFileNode(List results, final FileNode fileNode) {
		if(results.isEmpty()) {
			fileNode.setState(FileNode.NO_MATCH);
			fileNode.setUserObject(fileNode.getFileName());
		} else {
			for (Iterator it = results.iterator(); it.hasNext();) {
				ResultNode result = (ResultNode) it.next();

				fileNode.insert(result, fileNode.getChildCount());
			}

			fileNode.setState(FileNode.MATCH);
			int noOfMatches = fileNode.getChildCount();
			fileNode.setUserObject(fileNode.getFileName() + " (" + noOfMatches + ")");
		}

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				((DefaultTreeModel) files.getModel()).nodeStructureChanged(fileNode);
			}
		});
	}
	
	private void displayInfoBox() {
		final JDialog dialog = new JDialog();
		dialog.setTitle("PDF Help");
		Container contentPane = dialog.getContentPane();
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		
		JLabel ceo = new JLabel(new ImageIcon(getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/ceo.jpg")));
		ceo.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
		ceo.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		contentPane.add(ceo);
		
		JTextPane xml=new JTextPane();
		xml.setFont(ceo.getFont());
		xml.setContentType("text/html");
		xml.setOpaque(false);
		xml.setText("<html><center>PDF Help Version: "+PdfDecoder.version + "<br>" + "Java version " + System.getProperty("java.version"));
		xml.setEditable(false);
		xml.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
		contentPane.add(xml);
		xml.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		final JLabel url=new JLabel("<html><center>http://www.idrsolutions.com");
		url.setForeground(Color.blue);
		url.setHorizontalAlignment(JLabel.CENTER);
		url.setAlignmentX(Component.CENTER_ALIGNMENT);
		url.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        url.addMouseListener(new MouseListener() {
			public void mouseEntered(MouseEvent e) {
				dialog.setCursor(new Cursor(Cursor.HAND_CURSOR));
				url.setText("<html><center>http://www.idrsolutions.com");
			}

			public void mouseExited(MouseEvent e) {
				dialog.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				url.setText("<html><center>http://www.idrsolutions.com");
			}

			public void mouseClicked(MouseEvent e) {
				try {
					BrowserLauncher.openURL("http://www.idrsolutions.com");
				} catch (IOException e1) {
				}
			}

			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});
		
        contentPane.add(url);
        
        JButton close = new JButton("Close");
        close.setAlignmentX(JComponent.CENTER_ALIGNMENT);
        close.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				dialog.setVisible(false);
			}
        });
        contentPane.add(close);
        
        contentPane.add(Box.createRigidArea(new Dimension(0, 5)));
        
        dialog.pack();
        
        dialog.setSize(dialog.getPreferredSize().width + 50, dialog.getPreferredSize().height);
        
        dialog.setLocationRelativeTo(this);
        dialog.setModal(true);
        dialog.setResizable(false);
        dialog.setVisible(true);
	}
	
	public void getRSSBox() {
		final JPanel panel = new JPanel();

		JPanel top = new JPanel();
		top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));

		JPanel labelPanel = new JPanel();
		labelPanel.setLayout(new BoxLayout(labelPanel, BoxLayout.X_AXIS));
		labelPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		JLabel label = new JLabel("Click on the link below to load a web browser and sign up to our RSS feed.");
		label.setAlignmentX(JLabel.LEFT_ALIGNMENT);

		labelPanel.add(label);
		labelPanel.add(Box.createHorizontalGlue());

		top.add(labelPanel);

		JPanel linkPanel = new JPanel();
		linkPanel.setLayout(new BoxLayout(linkPanel, BoxLayout.X_AXIS));
		linkPanel.add(Box.createHorizontalGlue());
		linkPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		final JLabel url=new JLabel("<html><center>"+"http://www.jpedal.org/jpedal.rss");
		url.setAlignmentX(JLabel.LEFT_ALIGNMENT);

		url.setForeground(Color.blue);
		url.setHorizontalAlignment(JLabel.CENTER);

		//@kieran - cursor
		url.addMouseListener(new MouseListener() {
			public void mouseEntered(MouseEvent e) {
				panel.getTopLevelAncestor().setCursor(new Cursor(Cursor.HAND_CURSOR));
				url.setText("<html><center><a>http://www.jpedal.org/jpedal.rss</a></center>");
			}

			public void mouseExited(MouseEvent e) {
				panel.getTopLevelAncestor().setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				url.setText("<html><center>http://www.jpedal.org/jpedal.rss");
			}

			public void mouseClicked(MouseEvent e) {
				try {
					BrowserLauncher.openURL("http://www.jpedal.org/jpedal.rss");
				} catch (IOException e1) {

					JPanel errorPanel = new JPanel();
					errorPanel.setLayout(new BoxLayout(errorPanel, BoxLayout.Y_AXIS));

					JLabel errorMessage = new JLabel("Your web browser could not be successfully loaded.  " +
					"Please copy and paste the URL below, manually into your web browser.");
					errorMessage.setAlignmentX(JLabel.LEFT_ALIGNMENT);
					errorMessage.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

					JTextArea textArea = new JTextArea("http://www.jpedal.org/jpedal.rss");
					textArea.setEditable(false);
					textArea.setRows(5);
					textArea.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
					textArea.setAlignmentX(JTextArea.LEFT_ALIGNMENT);

					errorPanel.add(errorMessage);
					errorPanel.add(textArea);

					JOptionPane.showMessageDialog(getTopLevelAncestor(),errorPanel,"Error loading web browser",JOptionPane.PLAIN_MESSAGE);

				}
			}

			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});

		linkPanel.add(url);
		linkPanel.add(Box.createHorizontalGlue());
		top.add(linkPanel);

		JLabel image = new JLabel(new ImageIcon(getClass().getResource("/org/jpedal/examples/simpleviewer/res/rss.png")));
		image.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));

		JPanel imagePanel = new JPanel();
		imagePanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.X_AXIS));
		imagePanel.add(Box.createHorizontalGlue());
		imagePanel.add(image);
		imagePanel.add(Box.createHorizontalGlue());

		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(top);
		panel.add(imagePanel);

		JOptionPane.showMessageDialog(getTopLevelAncestor(),panel,"Subscribe to JPedal RSS Feed",JOptionPane.PLAIN_MESSAGE);
	}


    /**
     * show onscreen
     */
    public void displayHelp(){

        JFrame PdfHelpDisplay=new JFrame();

        PdfHelpDisplay.setTitle("PDF Help " + PdfHelpPanel.version);

		PdfHelpDisplay.getContentPane().setLayout(new BorderLayout());

        PdfHelpDisplay.getContentPane().add(this, BorderLayout.CENTER);

		PdfHelpDisplay.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int) (d.width / 1.5), height = (int) (d.height / 1.5);

		int minimumScreenWidth = 700;
		if (width < minimumScreenWidth)
			width = minimumScreenWidth;

		PdfHelpDisplay.setSize(width, height);

		PdfHelpDisplay.setLocationRelativeTo(null);
		PdfHelpDisplay.setVisible(true);
    }
}
