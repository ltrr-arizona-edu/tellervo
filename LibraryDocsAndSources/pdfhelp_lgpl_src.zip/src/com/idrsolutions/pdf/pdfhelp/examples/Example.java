package com.idrsolutions.pdf.pdfhelp.examples;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.UIManager;



import com.idrsolutions.pdf.pdfhelp.PdfHelpPanel;

public class Example extends JFrame {

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel( UIManager.getSystemLookAndFeelClassName() );
		}catch (Exception e) { 
		}
		
		new Example();
	}
	
	public Example(){
		setTitle("PDF Help " + PdfHelpPanel.version);
		
		getContentPane().setLayout(new BorderLayout());

		/**
		 * Array of locations for the PDF files.
		 * 
		 * Elements can be: -
		 * 		An absolute file path of a local location on disk
		 * 		A directory path which will be scanned recursively, adding all PDFs found to the file list
		 * 		A URL
		 * 		A classpath location
		 * 
		 * Examples: -
		 * 		"C:/file.pdf"
		 *		"C:/PdfFiles/"
		 * 		"http://www.jpedal.org/jpedal.pdf"
		 * 		"jar:/com/idrsolutions/pdf/pdfhelp/res/jpedal.pdf"
		 */
		String[] locations = new String[] {
                "jar:/com/idrsolutions/pdf/pdfhelp/res/jpedal.pdf" ,
		};

		/**
		 * The PdfHelpPanel can be run in two modes, either
		 * developer mode or and end-user mode.  By enabling developer mode - by
		 * passing a value of true into the constructor - you
		 * can add and remove PDFs from the list of files to be searched.
		 * When you list is complete you can generate the source code required
		 * to initialize the end-user version of the PdfHelpPanel.
		 */
		PdfHelpPanel pdfHelpPanel = new PdfHelpPanel(locations, true);
		
		/** 
		 * Pass false in the constructor when you are ready to build PdfHelpPanel 
		 * into your end-user applications.  The files you pass in here will be 
		 * fixed for the user - they won't be able to add or remove any files.
		 */
		//PdfHelpPanel pdfHelpPanel = new PdfHelpPanel(locations, false);
		
		getContentPane().add(pdfHelpPanel, BorderLayout.CENTER);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int) (d.width / 1.5), height = (int) (d.height / 1.5);
		
		int minimumScreenWidth = 700;
		if (width < minimumScreenWidth)
			width = minimumScreenWidth;

		setSize(width, height);
		
		setLocationRelativeTo(null);
		setVisible(true);
	}
}
