package com.idrsolutions.pdf.pdfhelp.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

import org.jpedal.utils.SwingWorker;

public class URLDownloader extends JDialog {
	private JLabel completed;
	private JProgressBar progress;
	private boolean isCancelled = false;

	public URLDownloader(URL url, File location, JPanel parent) {
		super((JFrame) null, "URL Download", true);

		JLabel message = new JLabel("Downloading: " + location.getName());
		message.setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));
		message.setAlignmentX(JComponent.LEFT_ALIGNMENT);

		completed = new JLabel("Data read = ");
		completed.setBorder(BorderFactory.createEmptyBorder(5, 5, 10, 5));
		completed.setAlignmentX(JComponent.LEFT_ALIGNMENT);

		try {
			int fileLength = url.openConnection().getContentLength();
			progress = new JProgressBar(0, fileLength);
		} catch (Exception e) {
		}
		progress.setAlignmentX(JComponent.LEFT_ALIGNMENT);
		progress.setStringPainted(true);

		getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

		getContentPane().add(message);
		getContentPane().add(completed);
		getContentPane().add(progress);
		getContentPane().add(Box.createVerticalGlue());

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setAlignmentX(JComponent.LEFT_ALIGNMENT);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		buttonPanel.add(Box.createHorizontalGlue());

		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				isCancelled = true;
			}
		});
		buttonPanel.add(cancel);

		buttonPanel.add(Box.createHorizontalGlue());

		getContentPane().add(buttonPanel);

		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		setResizable(false);

		pack();

		setSize(400, getPreferredSize().height + 20);

		setLocationRelativeTo(parent);

		downloadFile(url, location);
	}

	public boolean wasCancelled() {
		return isCancelled;
	}

	private void downloadFile(final URL url, final File cacheLocation) {
		new SwingWorker() {
			public Object construct() {
				try {
					InputStream is = url.openStream();
					FileOutputStream fos = new FileOutputStream(cacheLocation);
					int value, count = 0, update = 0;

					while ((value = is.read()) != -1) {
						fos.write(value);

						progress.setValue(count);

						if (update > 1000) {
							if (count < 1024)
								completed.setText("Data read = " + count + " bytes (file will be cached for future use)");
							else if (count > 1024 * 1024)
								completed.setText("Data read = " + ((10 * count) / (1024 * 1024)) / 10f + " M (file will be cached for future use)");
							else
								completed.setText("Data read = " + count / (1024) + " K (file will be cached for future use)");

							update = 0;
						}

						update++;
						count++;

						if(isCancelled) {
							is.close();
							fos.close();

							break;
						}
					}

					is.close();
					fos.close();

					setVisible(false);
				} catch (Exception e) {
				}

				return null;
			}
		}.start();
	}
}
