package com.idrsolutions.pdf.pdfhelp.gui;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JTree;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeCellRenderer;

public class FileTreeCellRenderer extends JPanel implements TreeCellRenderer {
    private Icon icon;

    public Icon getLeafIcon() {
        return icon;
    }
    
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean isSelected,
                                                  boolean expanded, boolean leaf, int row, boolean hasFocus) {

    	boolean isMatch = true;
    	
    	if (value instanceof FileNode) {
			FileNode fileNode = (FileNode) value;
			int state = fileNode.getState();
			
			URL resource = null;
			switch (state) {
			case FileNode.UNSET:
				resource = getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/pdf.png");
				break;

			case FileNode.MATCH:
				resource = getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/tick.png");
				break;
				
			case FileNode.NO_MATCH:
				resource = getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/cross.png");
				break;
			}
			
			icon = new ImageIcon(resource);
			
			if(state == FileNode.NO_MATCH)
				isMatch = false;
			
		} else {
			icon = null;
		}
    	
        DefaultMutableTreeNode node = ((DefaultMutableTreeNode) value);
		value = node.getUserObject();
		int level = node.getLevel();
		
		if (level == 2) {
        	URL resource = getClass().getResource("/com/idrsolutions/pdf/pdfhelp/res/page_find.png");
        	icon = new ImageIcon(resource);
        }
		
        setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
        
        removeAll();
        
        add(new JLabel(icon));
        
        JTextPane textPane = new JTextPane();
        
        Document doc = textPane.getDocument();
        
        SimpleAttributeSet plain = new SimpleAttributeSet();

        SimpleAttributeSet bold = new SimpleAttributeSet();
        StyleConstants.setBold(bold, true);
        
        String text = value.toString();
        text = text.replaceAll("</b>", "<b>");
        
        
        
        try {
			if(text.indexOf("<b>") != -1) {
				String[] splitText = text.split("<b>");
				
//				System.out.println(text+" <<<>> " + splitText.length);
//				
//				System.out.println(splitText[0]+" <<<>> " + splitText[1]);
				
				doc.insertString(0, splitText[0], plain);
				doc.insertString(splitText[0].length(), splitText[1], bold);
				
				if(splitText.length == 3)
					doc.insertString(splitText[0].length() + splitText[1].length(), splitText[2], plain);
			} else {
				doc.insertString(0, text, plain);
			}
		} catch (BadLocationException e) {
		}
        
        textPane.setBorder(BorderFactory.createEmptyBorder());
        
        if (isSelected) {
//        	if(isMatch){
        		textPane.setBackground(new Color(236, 233, 216));
        		textPane.setForeground(Color.BLACK);
//        	}
        } else {
        	textPane.setBackground(tree.getBackground());
        	textPane.setForeground(tree.getForeground());
        }
        
        if(!isMatch){
        	textPane.setForeground(Color.gray);
        }
        
        Font treeFont = tree.getFont();
        textPane.setFont(treeFont);
        
        textPane.setOpaque(true);
        
        setOpaque(false);
        
        add(Box.createRigidArea(new Dimension(5,5)));
        
		add(textPane);

        return this;
    }
}