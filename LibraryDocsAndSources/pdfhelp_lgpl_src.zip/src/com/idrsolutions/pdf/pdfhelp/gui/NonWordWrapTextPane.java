package com.idrsolutions.pdf.pdfhelp.gui;

import javax.swing.JTextPane;

public class NonWordWrapTextPane extends JTextPane {
	public NonWordWrapTextPane() {
		super();

	}

	public boolean getScrollableTracksViewportWidth() {
		return false;
	}
}
