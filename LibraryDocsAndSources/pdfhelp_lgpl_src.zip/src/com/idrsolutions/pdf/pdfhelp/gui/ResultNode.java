package com.idrsolutions.pdf.pdfhelp.gui;

import java.awt.Rectangle;

import javax.swing.tree.DefaultMutableTreeNode;

public class ResultNode extends DefaultMutableTreeNode {
	private String absoluteFilePath;
	private Rectangle highlight;
	private int pageNumber;
	private String fileName;

	public ResultNode(String text, Rectangle highlight, String absoluteFilePath, String fileName, int pageNumber) {
		super(text);
		
		this.highlight = highlight;
		this.absoluteFilePath = absoluteFilePath;
		this.fileName = fileName;
		this.pageNumber = pageNumber;
	}

	public String getAbsoluteFilePath() {
		return absoluteFilePath;
	}

	public String getFileName() {
		return fileName;
	}

	public Rectangle getHighlight() {
		return highlight;
	}
	
	public int getPageNumber() {
		return pageNumber;
	}
}
