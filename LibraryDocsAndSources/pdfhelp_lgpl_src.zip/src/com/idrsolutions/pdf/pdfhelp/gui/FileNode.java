package com.idrsolutions.pdf.pdfhelp.gui;

import javax.swing.tree.DefaultMutableTreeNode;

public class FileNode extends DefaultMutableTreeNode {
	
	private int state;
	private String absoluteFilePath, fileName;
	public final static int UNSET = 0;
	public final static int MATCH = 1;
	public final static int NO_MATCH = 2;
	
	public FileNode(String absoluteFilePath, String fileName){
		super(fileName);
		
		this.absoluteFilePath = absoluteFilePath;
		this.fileName = fileName;
		
		state = UNSET;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}
	
	public String getAbsoluteFilePath() {
		return absoluteFilePath;
	}
	
	public String getFileName() {
		return fileName;
	}
}
