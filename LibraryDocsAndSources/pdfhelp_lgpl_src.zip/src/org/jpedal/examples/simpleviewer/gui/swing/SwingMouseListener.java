package org.jpedal.examples.simpleviewer.gui.swing;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import org.jpedal.Display;
import org.jpedal.PdfDecoder;
import org.jpedal.examples.simpleviewer.Commands;
import org.jpedal.examples.simpleviewer.Values;
import org.jpedal.examples.simpleviewer.gui.SwingGUI;
import org.jpedal.examples.simpleviewer.gui.generic.GUIMouseHandler;
import org.jpedal.examples.simpleviewer.gui.swing.SwingMouseSelection.AutoScrollThread;

public class SwingMouseListener implements GUIMouseHandler, MouseListener, MouseMotionListener, MouseWheelListener {

	private PdfDecoder decode_pdf;
	private SwingGUI currentGUI;
	private Values commonValues;
	private Commands currentCommands;
	
	SwingMouseSelector selectionFunctions;
	SwingMousePanMode panningFunctions;
	SwingMousePageTurn pageTurnFunctions;

	private long timeOfLastPageChange;
	
	/**current cursor position*/
	private int cx,cy;
	
	/**tells user if we enter a link*/
	private String message="";
	
	private AutoScrollThread scrollThread = new AutoScrollThread();
	
	public SwingMouseListener(PdfDecoder decode_pdf, SwingGUI currentGUI,
			Values commonValues,Commands currentCommands) {

		this.decode_pdf=decode_pdf;
		this.currentGUI=currentGUI;
		this.commonValues=commonValues;
		this.currentCommands=currentCommands;
		
		selectionFunctions = new SwingMouseSelector(decode_pdf, currentGUI, commonValues, currentCommands);
		panningFunctions = new SwingMousePanMode(decode_pdf);
		pageTurnFunctions = new SwingMousePageTurn(decode_pdf, currentGUI, commonValues, currentCommands);

		if (SwingUtilities.isEventDispatchThread()){
            scrollThread.init();
        }else {
            final Runnable doPaintComponent = new Runnable() {
                public void run() {
                    scrollThread.init();
                }
            };
            SwingUtilities.invokeLater(doPaintComponent);
        }
	}

	public void setupExtractor() {
		System.out.println("Set up extractor called");
		decode_pdf.addMouseMotionListener(this);
		decode_pdf.addMouseListener(this);

	}

	public void setupMouse() {
		/**
		 * track and display screen co-ordinates and support links
		 */
		decode_pdf.addMouseMotionListener(this);
		decode_pdf.addMouseListener(this);
		decode_pdf.addMouseWheelListener(this);

		//set cursor
		currentGUI.setCursor(SwingGUI.DEFAULT_CURSOR);

	}

	public void updateRectangle() {
		switch(decode_pdf.getMouseMode()){

		case PdfDecoder.MOUSE_MODE_TEXT_SELECT : 
			selectionFunctions.updateRectangle();
			break;

		case PdfDecoder.MOUSE_MODE_PANNING : 
			break;

		}
	}

	public void mouseClicked(MouseEvent e) {
		switch(decode_pdf.getMouseMode()){

		case PdfDecoder.MOUSE_MODE_TEXT_SELECT : 
			selectionFunctions.mouseClicked(e);
			break;

		case PdfDecoder.MOUSE_MODE_PANNING : 
			//Does Nothing so ignore
			break;

		}
		
		if (decode_pdf.turnoverOn && decode_pdf.getDisplayView()==Display.FACING){
			pageTurnFunctions.mouseClicked(e);
		}
	}

	public void mouseEntered(MouseEvent e) {
		switch(decode_pdf.getMouseMode()){

		case PdfDecoder.MOUSE_MODE_TEXT_SELECT : 
			//Text selection does nothing here
			//selectionFunctions.mouseEntered(e);
			break;

		case PdfDecoder.MOUSE_MODE_PANNING : 
			//Does Nothing so ignore
			break;

		}
		
		if (decode_pdf.turnoverOn && decode_pdf.getDisplayView()==Display.FACING){
			pageTurnFunctions.mouseEntered(e);
		}
	}

	public void mouseExited(MouseEvent e) {
		
		//If mouse leaves viewer, stop scrolling
        scrollThread.setAutoScroll(false, 0, 0, 0);
        
		switch(decode_pdf.getMouseMode()){

		case PdfDecoder.MOUSE_MODE_TEXT_SELECT : 
			selectionFunctions.mouseExited(e);
			break;

		case PdfDecoder.MOUSE_MODE_PANNING : 
			//Does Nothing so ignore
			break;

		}
		
		if (decode_pdf.turnoverOn && decode_pdf.getDisplayView()==Display.FACING){
			pageTurnFunctions.mouseExited(e);
		}
	}

	public void mousePressed(MouseEvent e) {
		switch(decode_pdf.getMouseMode()){

		case PdfDecoder.MOUSE_MODE_TEXT_SELECT : 
			selectionFunctions.mousePressed(e);
			break;

		case PdfDecoder.MOUSE_MODE_PANNING : 
			panningFunctions.mousePressed(e);
			break;

		}
		
		if (decode_pdf.turnoverOn && decode_pdf.getDisplayView()==Display.FACING){
			pageTurnFunctions.mousePressed(e);
		}
	}

	public void mouseReleased(MouseEvent e) {
		switch(decode_pdf.getMouseMode()){

		case PdfDecoder.MOUSE_MODE_TEXT_SELECT :
			selectionFunctions.mouseReleased(e);
			break;

		case PdfDecoder.MOUSE_MODE_PANNING : 
			panningFunctions.mouseReleased(e);
			break;

		}
		
		if (decode_pdf.turnoverOn && decode_pdf.getDisplayView()==Display.FACING){
			pageTurnFunctions.mouseReleased(e);
		}
	}

	public void mouseDragged(MouseEvent e) {
		scrollAndUpdateCoords(e);
		
		switch(decode_pdf.getMouseMode()){

		case PdfDecoder.MOUSE_MODE_TEXT_SELECT : 
			selectionFunctions.mouseDragged(e);
			break;

		case PdfDecoder.MOUSE_MODE_PANNING : 
			panningFunctions.mouseDragged(e);
			break;

		}
		
		if (decode_pdf.turnoverOn && decode_pdf.getDisplayView()==Display.FACING){
			pageTurnFunctions.mouseDragged(e);
		}
	}

	public void mouseMoved(MouseEvent e) {
		
		//int[] values = selectionFunctions.updateXY(e.getX(), e.getY());
		int x =e.getX();
		int y =e.getY();
		int page = commonValues.getCurrentPage();
		//decode_pdf.getObjectUnderneath(x, y);
		
		//<start-adobe>
		//Update cursor position if over page in single mode        
		if (currentGUI.useNewLayout) {
			int[] flag = new int[2];
			flag[0] = SwingGUI.CURSOR;

			Rectangle pageArea = null;

			flag[1]=0;

			int xAdjustment = 0;

			switch(decode_pdf.getDisplayView()){
			case Display.SINGLE_PAGE:
				//get raw w and h
				int pageWidth,pageHeight;
				if (currentGUI.getRotation()%180==90) {
					pageWidth = decode_pdf.getPdfPageData().getScaledCropBoxHeight(page);
					pageHeight = decode_pdf.getPdfPageData().getScaledCropBoxWidth(page);
				} else {
					pageWidth = decode_pdf.getPdfPageData().getScaledCropBoxWidth(page);
					pageHeight = decode_pdf.getPdfPageData().getScaledCropBoxHeight(page);
				}

				pageArea = new Rectangle(
						(decode_pdf.getWidth()/2) - (pageWidth/2),
						decode_pdf.getInsetH(),
						pageWidth, 
						pageHeight);

				if (pageArea.contains(e.getPoint()))
					//set displayed
					flag[1] = 1;
				else
					//set not displayed
					flag[1] = 0;

				break;
			case Display.CONTINUOUS:

				//In continuous pages are centred so we need make 
				xAdjustment = (decode_pdf.getWidth()/2) - (decode_pdf.getPdfPageData().getScaledCropBoxWidth(page)/2);
				if(xAdjustment<0)
					xAdjustment = 0;
				else{
					//This adjustment is the correct position.
					//Offset removed to that when used later we get either offset unaltered or correct position
					xAdjustment = xAdjustment-decode_pdf.getPageOffsets(page).x;
				}

				pageArea = new Rectangle(decode_pdf.getPageOffsets(page).x+xAdjustment,
						decode_pdf.getPageOffsets(page).y,
						decode_pdf.getPdfPageData().getScaledCropBoxWidth(page),
						decode_pdf.getPdfPageData().getScaledCropBoxHeight(page));
				if(pageArea.contains(e.getPoint())){
					//set displayed
					flag[1] = 1;
				}



				if(flag[1]==0){
					if(y<pageArea.y && page>1){
						while(flag[1]==0 && page>1){
							page--;
							pageArea = new Rectangle(decode_pdf.getPageOffsets(page).x+xAdjustment,
									decode_pdf.getPageOffsets(page).y,
									decode_pdf.getPdfPageData().getScaledCropBoxWidth(page),
									decode_pdf.getPdfPageData().getScaledCropBoxHeight(page));
							if(pageArea.contains(e.getPoint())){
								//set displayed
								flag[1] = 1;
							}
						}
					}else{
						if(y>pageArea.getMaxY() && page<commonValues.getPageCount()){
							while(flag[1]==0 && page<commonValues.getPageCount()){
								page++;
								pageArea = new Rectangle(decode_pdf.getPageOffsets(page).x+xAdjustment,
										decode_pdf.getPageOffsets(page).y,
										decode_pdf.getPdfPageData().getScaledCropBoxWidth(page),
										decode_pdf.getPdfPageData().getScaledCropBoxHeight(page));
								if(pageArea.contains(e.getPoint())){
									//set displayed
									flag[1] = 1;
								}
							}
						}
					}
				}

				//Tidy coords for multipage views
				y= ((decode_pdf.getPageOffsets(page).y+decode_pdf.getPdfPageData().getScaledCropBoxHeight(page))+decode_pdf.getInsetH()) - y;
				break;

			case Display.FACING: 
				//get raw w and h
				//                int pageW,pageH;
				//                if (currentGUI.getRotation()%180==90) {
				//                	pageW = decode_pdf.getPdfPageData().getScaledCropBoxHeight(page);
				//                	pageH = decode_pdf.getPdfPageData().getScaledCropBoxWidth(page);
				//                } else {
				//                	pageW = decode_pdf.getPdfPageData().getScaledCropBoxWidth(page);
				//                	pageH = decode_pdf.getPdfPageData().getScaledCropBoxHeight(page);
				//                }
				//                System.out.println("page=="+page);
				//                System.out.println("decode_pdf.getWidth()=="+decode_pdf.getWidth());
				//                System.out.println("offset=="+decode_pdf.getPageOffsets(page));
				//                System.out.println("mouse point =="+e.getPoint());
				//                if(page==1){
				//                	pageArea = new Rectangle(
				//                			(decode_pdf.getWidth()/2),
				//                			decode_pdf.getInsetH(),
				//                			pageW, 
				//                			pageH);
				//                }else if(page==commonValues.getPageCount()){
				//                	pageArea = new Rectangle(
				//                			(decode_pdf.getWidth()/2) - (pageW),
				//                			decode_pdf.getInsetH(),
				//                			pageW, 
				//                			pageH);
				//                }else{
				//                	pageArea = new Rectangle(
				//                			(decode_pdf.getWidth()/2) - (pageW),
				//                			decode_pdf.getInsetH(),
				//                			pageW+decode_pdf.getPdfPageData().getScaledCropBoxHeight(page+1), 
				//                			pageH);
				//                }
				//                
				//                if (pageArea.contains(e.getPoint()))
				//                    //set displayed
				//                    flag[1] = 1;
				//                else
				//                    //set not displayed
				flag[1] = 0;

				break;

			case Display.CONTINUOUS_FACING:

				//Check if we are in the region of the left or right pages
				if(x>(decode_pdf.getWidth()/2) && page<commonValues.getPageCount()){// && x>pageArea.x){
					page++;
				}

				//Set the adjustment for page position
				xAdjustment = (decode_pdf.getWidth()/2) - (decode_pdf.getPdfPageData().getScaledCropBoxWidth(page))-(decode_pdf.getInsetW());

				//Unsure if this is needed. Still checking
				if(xAdjustment<0){
					System.err.println("x adjustment is less than 0");
					xAdjustment = 0;
				}
				
				//Check to see if pagearea contains the mouse
				pageArea = new Rectangle(decode_pdf.getPageOffsets(page).x+xAdjustment,
						decode_pdf.getPageOffsets(page).y,
						decode_pdf.getPdfPageData().getScaledCropBoxWidth(page),
						decode_pdf.getPdfPageData().getScaledCropBoxHeight(page));
				if(pageArea.contains(e.getPoint())){
					//set displayed
					flag[1] = 1;
				}


				//If neither of the two current pages contain the mouse start checking the other pages
				//Could be improved to minimise on the loops and calls to decode_pdf.getPageOffsets(page)
				if(flag[1]==0){
					if(y<pageArea.y && page>1){
						while(flag[1]==0 && page>1){
							page--;
							xAdjustment = (decode_pdf.getWidth()/2) - (decode_pdf.getPdfPageData().getScaledCropBoxWidth(page))-(decode_pdf.getInsetW());
							if(xAdjustment<0)
								xAdjustment = 0;
							pageArea = new Rectangle(decode_pdf.getPageOffsets(page).x+xAdjustment,
									decode_pdf.getPageOffsets(page).y,
									decode_pdf.getPdfPageData().getScaledCropBoxWidth(page),
									decode_pdf.getPdfPageData().getScaledCropBoxHeight(page));
							if(pageArea.contains(e.getPoint())){
								//set displayed
								flag[1] = 1;
							}

						}
					}else{
						if(y>pageArea.getMaxY() && page<commonValues.getPageCount()){
							while(flag[1]==0 && page<commonValues.getPageCount()){
								page++;
								xAdjustment = (decode_pdf.getWidth()/2) - (decode_pdf.getPdfPageData().getScaledCropBoxWidth(page))-(decode_pdf.getInsetW());
								if(xAdjustment<0)
									xAdjustment = 0;
								pageArea = new Rectangle(decode_pdf.getPageOffsets(page).x+xAdjustment,
										decode_pdf.getPageOffsets(page).y,
										decode_pdf.getPdfPageData().getScaledCropBoxWidth(page),
										decode_pdf.getPdfPageData().getScaledCropBoxHeight(page));
								if(pageArea.contains(e.getPoint())){
									//set displayed
									flag[1] = 1;
								}

							}
						}
					}
				}

				//Tidy coords for multipage views
				if(page>1){
					y= y - (decode_pdf.getPageOffsets(page).y-decode_pdf.getInsetH());
				}

				x = x - ((decode_pdf.getPageOffsets(page).x)-decode_pdf.getInsetW());
				break;
			default : break;
			}

			currentGUI.setMultibox(flag);
		}
		//<end-adobe>

		updateCoords(x, y, e.isShiftDown());

		int[] values = selectionFunctions.updateXY(e.getX(), e.getY());
		x =values[0];
		y =values[1];
		decode_pdf.getObjectUnderneath(x, y);

		/*
		 * Mouse mode specidifc code
		 */
		switch(decode_pdf.getMouseMode()){

		case PdfDecoder.MOUSE_MODE_TEXT_SELECT :
			selectionFunctions.mouseMoved(e);
			break;

		case PdfDecoder.MOUSE_MODE_PANNING : 
			//Does Nothing so ignore
			break;

		}

		if (decode_pdf.turnoverOn && decode_pdf.getDisplayView()==Display.FACING){
			pageTurnFunctions.mouseMoved(e);
		}
	}
	
	class AutoScrollThread implements Runnable{

        Thread scroll;
        boolean autoScroll = false;
        int x = 0;
        int y = 0;
        int interval = 0;

        public AutoScrollThread(){
            scroll = new Thread(this);
        }

        public void setAutoScroll(boolean autoScroll, int x, int y, int interval){
            this.autoScroll = autoScroll;
            this.x = currentGUI.AdjustForAlignment(x);
            this.y = y;
            this.interval = interval;
        }

        public void init(){
            scroll.start();
        }

        int usedX,usedY;

        public void run() {

            while (Thread.currentThread().equals(scroll)) {

                //New autoscroll code allow for diagonal scrolling from corner of viewer

                //@kieran - you will see if you move the mouse to right or bottom of page, repaint gets repeatedly called
                //we need to add 2 test to ensure only redrawn if on page (you need to covert x and y back to PDF and
                //check fit in width and height - see code in this class
                //if(autoScroll && usedX!=x && usedY!=y && x>0 && y>0){
                if(autoScroll){
                    final Rectangle visible_test=new Rectangle(x-interval,y-interval,interval*2,interval*2);
                    final Rectangle currentScreen=decode_pdf.getVisibleRect();

                    if(!currentScreen.contains(visible_test)){

                        if (SwingUtilities.isEventDispatchThread()){
                            decode_pdf.scrollRectToVisible(visible_test);
                        }else {
                            final Runnable doPaintComponent = new Runnable() {
                                public void run() {
                                    decode_pdf.scrollRectToVisible(visible_test);
                                }
                            };
                            SwingUtilities.invokeLater(doPaintComponent);
                        }

                        //Check values modified by (interval*2) as visible rect changed by interval
                        if(x-(interval*2)<decode_pdf.getVisibleRect().x)
                            x = x-interval;
                        else if((x+(interval*2))>(decode_pdf.getVisibleRect().x+decode_pdf.getVisibleRect().width))
                            x = x+interval;

                        if(y-(interval*2)<decode_pdf.getVisibleRect().y)
                            y = y-interval;
                        else if((y+(interval*2))>(decode_pdf.getVisibleRect().y+decode_pdf.getVisibleRect().height))
                            y = y+interval;

                        //thrashes box if constantly called

                        //System.out.println("redraw on scroll");
                        //decode_pdf.repaint();
                    }

                    usedX=x;
                    usedY=y;

                }

                //Delay to check for mouse leaving scroll edge)
                try {
                    Thread.sleep(250);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }
    }

	public void mouseWheelMoved(MouseWheelEvent event) {

		switch(decode_pdf.getDisplayView()){
		case Display.PAGEFLOW3D : 
			break;

		case Display.FACING : 
			if(decode_pdf.turnoverOn)
				pageTurnFunctions.mouseWheelMoved(event);
			break;
		default :

			if(currentGUI.getProperties().getValue("allowScrollwheelZoom").toLowerCase().equals("true") && event.isControlDown()){
				//zoom
				int scaling = currentGUI.getSelectedComboIndex(Commands.SCALING);
				if(scaling!=-1){
					scaling = (int)decode_pdf.getDPIFactory().removeScaling(decode_pdf.getScaling()*100);
				}else{
					String numberValue = (String)currentGUI.getSelectedComboItem(Commands.SCALING);
					try{
						scaling= (int)Float.parseFloat(numberValue);
					}catch(Exception e){
						scaling=-1;
						//its got characters in it so get first valid number string
						int length=numberValue.length();
						int ii=0;
						while(ii<length){
							char c=numberValue.charAt(ii);
							if(((c>='0')&&(c<='9'))|(c=='.'))
								ii++;
							else
								break;
						}

						if(ii>0)
							numberValue=numberValue.substring(0,ii);

						//try again if we reset above
						if(scaling==-1){
							try{
								scaling = (int)Float.parseFloat(numberValue);
							}catch(Exception e1){scaling=-1;}
						}
					}
				}

				float value = event.getWheelRotation();

				if(scaling!=1 || value<0){
					if(value<0){
						value = 1.25f;
					}else{
						value = 0.8f;
					}
					if(!(scaling+value<0)){
						float currentScaling = (scaling*value);

						//kieran - is this one of yours?
						//
						if(((int)currentScaling)==(scaling))
							currentScaling=scaling+1;
						else
							currentScaling = ((int)currentScaling);

						if(currentScaling<1)
							currentScaling=1;

						if(currentScaling>1000)
							currentScaling=1000;

						//store mouse location
						final Rectangle r = decode_pdf.getVisibleRect();
						final double x = event.getX()/decode_pdf.getBounds().getWidth();
						final double y = event.getY()/decode_pdf.getBounds().getHeight();

						//update scaling
						currentGUI.snapScalingToDefaults(currentScaling);

						//center on mouse location
						Thread t = new Thread() {
							public void run() {
								try {
									decode_pdf.scrollRectToVisible(new Rectangle(
											(int)((x*decode_pdf.getWidth())-(r.getWidth()/2)),
											(int)((y*decode_pdf.getHeight())-(r.getHeight()/2)),
											(int)decode_pdf.getVisibleRect().getWidth(),
											(int)decode_pdf.getVisibleRect().getHeight()));
									decode_pdf.repaint();
								} catch (Exception e) {e.printStackTrace();}
							}
						};
						t.start();
						SwingUtilities.invokeLater(t);
					}
				}
			} else {

				final JScrollBar scroll = ((JScrollPane)decode_pdf.getParent().getParent()).getVerticalScrollBar();
				if ((scroll.getValue()>=scroll.getMaximum()-scroll.getHeight() || scroll.getHeight()==0) &&
						event.getUnitsToScroll() > 0 &&
						timeOfLastPageChange+700 < System.currentTimeMillis() &&
						currentGUI.getPageNumber() < decode_pdf.getPageCount()) {

					//change page
					timeOfLastPageChange = System.currentTimeMillis();
					currentCommands.executeCommand(Commands.FORWARDPAGE, null);

					//update scrollbar so at top of page
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							scroll.setValue(scroll.getMinimum());
						}
					});

				} else if (scroll.getValue()==scroll.getMinimum() &&
						event.getUnitsToScroll() < 0 &&
						timeOfLastPageChange+700 < System.currentTimeMillis() &&
						currentGUI.getPageNumber() > 1) {

					//change page
					timeOfLastPageChange = System.currentTimeMillis();
					currentCommands.executeCommand(Commands.BACKPAGE, null);

					//update scrollbar so at bottom of page
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							scroll.setValue(scroll.getMaximum());
						}
					});

				} else {
					//scroll
					Area rect = new Area(decode_pdf.getVisibleRect());
					AffineTransform transform = new AffineTransform();
					transform.translate(0, event.getUnitsToScroll() * decode_pdf.getScrollInterval());
					rect = rect.createTransformedArea(transform);
					decode_pdf.scrollRectToVisible(rect.getBounds());
				}
			}

			break;
		}
		//		//Not used in text selection or panning modes
		//		if (decode_pdf.turnoverOn && decode_pdf.getDisplayView()==Display.FACING){
		//			pageTurnFunctions.mouseWheelMoved(event);
		//		}
	}
	
	/**
	 * scroll to visible Rectangle and update Coords box on screen
	 */
	protected void scrollAndUpdateCoords(MouseEvent event) {
        //scroll if user hits side
        int interval=decode_pdf.getScrollInterval();
		Rectangle visible_test=new Rectangle(currentGUI.AdjustForAlignment(event.getX()),event.getY(),interval,interval);
		if((currentGUI.allowScrolling())&&(!decode_pdf.getVisibleRect().contains(visible_test)))
                decode_pdf.scrollRectToVisible(visible_test);

        updateCoords(event.getX(), event.getY(), event.isShiftDown());
    }
	
	/**update current page co-ordinates on screen
	 */
	public void updateCoords(/*MouseEvent event*/int x, int y, boolean isShiftDown){
		
		float scaling=currentGUI.getScaling();
		int inset=currentGUI.getPDFDisplayInset();
		int rotation=currentGUI.getRotation();

		int ex=currentGUI.AdjustForAlignment(x)-inset;
		int ey=y-inset;

		//undo any viewport scaling
		if(commonValues.maxViewY!=0){ // will not be zero if viewport in play
			ex=(int)(((ex-(commonValues.dx*scaling))/commonValues.viewportScale));
			ey=(int)((currentGUI.mediaH-((currentGUI.mediaH-(ey/scaling)-commonValues.dy)/commonValues.viewportScale))*scaling);
		}

		cx=(int)((ex)/scaling);
		cy=(int)((ey/scaling));


		if(decode_pdf.getDisplayView()!=Display.SINGLE_PAGE){
			
			if(SwingMouseSelection.activateMultipageHighlight){
				
				//@kieran remove when facing is working correctly
				if(decode_pdf.getDisplayView()==Display.FACING){
					cx=0;
					cy=0;
				}
			}else{
				cx=0;
				cy=0;
			}
			//cx=decode_pdf.getMultiPageOffset(scaling,cx,commonValues.getCurrentPage(),Display.X_AXIS);
			//cy=decode_pdf.getMultiPageOffset(scaling,cy,commonValues.getCurrentPage(),Display.Y_AXIS);
		} else if(rotation==90){
			int tmp=(cx+currentGUI.cropY);
			cx = (cy+currentGUI.cropX);
			cy =tmp;	
		}else if((rotation==180)){
			cx =(currentGUI.cropW+currentGUI.cropX)-cx;
			cy =(cy+currentGUI.cropY);
		}else if((rotation==270)){
			int tmp=(currentGUI.cropH+currentGUI.cropY)-cx;
			cx =(currentGUI.cropW+currentGUI.cropX)-cy;
			cy =tmp;
		}else{
			cx = (cx+currentGUI.cropX);
			cy =(currentGUI.cropH+currentGUI.cropY)-cy;
		}


		if((commonValues.isProcessing())|(commonValues.getSelectedFile()==null))
			currentGUI.setCoordText("  X: "+ " Y: " + ' ' + ' '); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
		else
			currentGUI.setCoordText("  X: " + cx + " Y: " + cy+ ' ' + ' ' +message); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

	}
	
	 public int[] getCursorLocation() {
	        return new int[]{cx,cy};
	    }
	
}
