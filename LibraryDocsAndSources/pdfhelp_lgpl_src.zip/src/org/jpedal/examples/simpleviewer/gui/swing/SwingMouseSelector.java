package org.jpedal.examples.simpleviewer.gui.swing;

import java.awt.Cursor;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.filechooser.FileFilter;

import org.jpedal.Display;
import org.jpedal.PdfDecoder;
import org.jpedal.examples.simpleviewer.Commands;
import org.jpedal.examples.simpleviewer.SimpleViewer;
import org.jpedal.examples.simpleviewer.Values;
import org.jpedal.examples.simpleviewer.gui.SwingGUI;
import org.jpedal.exception.PdfException;
import org.jpedal.grouping.SearchType;
import org.jpedal.io.Speech;
import org.jpedal.render.DynamicVectorRenderer;
import org.jpedal.utils.Messages;

public class SwingMouseSelector {

	private PdfDecoder decode_pdf;
	private SwingGUI currentGUI;
	private Values commonValues;
	private Commands currentCommands;

	//Experimental multi page highlight flag
	protected static boolean activateMultipageHighlight = true;

	//Variables to keep track of multiple clicks
	private int clickCount = 0;
	private long lastTime = -1;

	/*
	 * ID of objects found during selection
	 */
	public int id = -1;
	public int lastId =-1;

	//used to track changes when dragging rectangle around
	private int old_m_x2=-1,old_m_y2=-1;

	//Use alt to extract only within exact area
	boolean altIsDown = false;

	private JPopupMenu rightClick = new JPopupMenu();
	private boolean menuCreated = false;

	//Right click options
	JMenuItem copy;
	//======================================
	JMenuItem selectAll, deselectall;
	//======================================
	JMenu extract;
	JMenuItem extractText, extractImage;
	ImageIcon snapshotIcon;
	JMenuItem snapShot;
	//======================================
	JMenuItem find;
	//======================================
	JMenuItem speakHighlighted;

	public SwingMouseSelector(PdfDecoder decode_pdf, SwingGUI currentGUI,
			Values commonValues,Commands currentCommands) {

		this.decode_pdf=decode_pdf;
		this.currentGUI=currentGUI;
		this.commonValues=commonValues;
		this.currentCommands=currentCommands;

		//		decode_pdf.addExternalHandler(this, Options.SwingMouseHandler);

	}

	public void updateRectangle() {
		// TODO Auto-generated method stub

	}


	/**
	 * Mouse Button Listener
	 */
	public void mouseClicked(MouseEvent event) {

		if(decode_pdf.getDisplayView()==Display.SINGLE_PAGE || activateMultipageHighlight){
			long currentTime = new Date().getTime();

			if(lastTime+500 < currentTime)
				clickCount=0;

			lastTime = currentTime;

			if(event.getButton()==MouseEvent.BUTTON1){
				//Single mode actions
				if(clickCount!=4)
					clickCount++;

				//highlight image on page if over
				//int[] c = smh.getCursorLocation();
				float scaling=currentGUI.getScaling();
				int inset=currentGUI.getPDFDisplayInset();
				int mouseX = (int)((currentGUI.AdjustForAlignment(event.getX())-inset)/scaling);
				int mouseY = (int)(decode_pdf.getPdfPageData().getCropBoxHeight(commonValues.getCurrentPage())-((event.getY()-inset)/scaling));

				id = decode_pdf.getDynamicRenderer().isInsideImage(mouseX,mouseY);
				
				if(lastId!=id && id!=-1){
					Rectangle imageArea = decode_pdf.getDynamicRenderer().getArea(id);


					if(imageArea!=null){
						int h= imageArea.height;
						int w= imageArea.width;
						
						int x= imageArea.x;
						int y= imageArea.y;
						decode_pdf.getDynamicRenderer().setneedsHorizontalInvert(false);
						decode_pdf.getDynamicRenderer().setneedsVerticalInvert(false);
						//						Check for negative values
						if(w<0){
							decode_pdf.getDynamicRenderer().setneedsHorizontalInvert(true);
							w =-w;
							x =x-w;
						}
						if(h<0){
							decode_pdf.getDynamicRenderer().setneedsVerticalInvert(true);
							h =-h;
							y =y-h;
						}

						if(decode_pdf.isImageExtractionAllowed()){
							decode_pdf.setHighlightedImage(new int[]{x,y,w,h});
						}

					}
					lastId = id;
				}else{
					if(decode_pdf.isImageExtractionAllowed()){
						decode_pdf.setHighlightedImage(null);
					}
					lastId = -1;
				}

				if(id==-1){
					if(clickCount>1){
						switch(clickCount){
						case 1 : //single click adds caret to page
							/**
							 * Does nothing yet. IF above prevents this case from ever happening
							 * Add Caret code here and add shift click code for selection.
							 * Also remember to comment out "if(clickCount>1)" from around this switch to activate
							 */
							break;
						case 2 : //double click selects line
							Rectangle[] lines = decode_pdf.getLineAreas(commonValues.getCurrentPage());
							Rectangle point = new Rectangle(mouseX,mouseY,1,1);

							if(lines!=null) { //Null is page has no lines
								for(int i=0; i!=lines.length; i++){
									if(lines[i].intersects(point)){
										currentGUI.setRectangle(lines[i]);
										decode_pdf.updateCursorBoxOnScreen(lines[i],PdfDecoder.highlightColor);
										decode_pdf.addHighlights(new Rectangle[]{lines[i]}, false, commonValues.getCurrentPage());
										//decode_pdf.setMouseHighlightArea(lines[i]);
									}
								}
							}
							break;
						case 3 : //triple click selects paragraph
							Rectangle para = decode_pdf.setFoundParagraph(mouseX,mouseY, commonValues.getCurrentPage());
							if(para!=null){
								currentGUI.setRectangle(para);
								decode_pdf.updateCursorBoxOnScreen(para,PdfDecoder.highlightColor);
								//decode_pdf.repaint();
								//decode_pdf.setMouseHighlightArea(para);
							}
							break;
						case 4 : //quad click selects page
							currentGUI.currentCommands.executeCommand(Commands.SELECTALL, null);
							break;
						}
					}
				}
			}else if(event.getButton()==MouseEvent.BUTTON2){

			}else if(event.getButton()==MouseEvent.BUTTON3){

			}
		}		
	}

	public void mousePressed(MouseEvent event) {

		if(decode_pdf.getDisplayView()== Display.SINGLE_PAGE || activateMultipageHighlight){
			if(event.getButton()==MouseEvent.BUTTON1){
				/** remove any outline and reset variables used to track change */

				currentGUI.setRectangle(null);
				decode_pdf.updateCursorBoxOnScreen(null, null); //remove box
				decode_pdf.setHighlightedImage(null);// remove image highlight
				decode_pdf.clearHighlights();

				//Remove focus from form is if anywhere on pdf panel is clicked / mouse dragged
				decode_pdf.grabFocus();

				int[] values = updateXY(event.getX(), event.getY());
				commonValues.m_x1=values[0];
				commonValues.m_y1=values[1];

			}
		}		
	}

	public void mouseReleased(MouseEvent event) {

		if(decode_pdf.getDisplayView()==Display.SINGLE_PAGE || activateMultipageHighlight){
			if(event.getButton()==MouseEvent.BUTTON1){
				//						old_m_x2 = -1;
				//						old_m_y2 = -1;

				decode_pdf.repaintArea(new Rectangle(commonValues.m_x1-currentGUI.cropX, commonValues.m_y2+currentGUI.cropY, commonValues.m_x2 - commonValues.m_x1+currentGUI.cropX,
						(commonValues.m_y1 - commonValues.m_y2)+currentGUI.cropY), currentGUI.mediaH);//redraw
				decode_pdf.repaint();

				//dragged = false;

				if(decode_pdf.isExtractingAsImage()){

					/** remove any outline and reset variables used to track change */
					currentGUI.setRectangle(null);
					decode_pdf.updateCursorBoxOnScreen(null, null); //remove box
					decode_pdf.clearHighlights(); //remove highlighted text
					decode_pdf.setHighlightedImage(null);// remove image highlight

					decode_pdf.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

					currentGUI.currentCommands.extractSelectedScreenAsImage();
					decode_pdf.setExtractingAsImage(false);

				}
			} else if(event.getButton()==MouseEvent.BUTTON3){
				if(currentGUI.getProperties().getValue("allowRightClick").toLowerCase().equals("true")){
					if (!menuCreated)
						createRightClickMenu();

					if(decode_pdf.getHighlightImage()==null)
						extractImage.setEnabled(false);
					else
						extractImage.setEnabled(true);

					if(decode_pdf.getHighlightedAreas(commonValues.getCurrentPage())==null){
						extractText.setEnabled(false);
						find.setEnabled(false);
						speakHighlighted.setEnabled(false);
						copy.setEnabled(false);
					}else{
						extractText.setEnabled(true);
						find.setEnabled(true);
						speakHighlighted.setEnabled(true);
						copy.setEnabled(true);
					}

					//<start-wrap>
					if(decode_pdf!=null && decode_pdf.isOpen())
						rightClick.show(decode_pdf, event.getX(), event.getY());
					//<end-wrap>
				}
			}
		}		
	}


	/**
	 * Mouse Motion Listener
	 */
	public void mouseEntered(MouseEvent arg0) {

	}

	public void mouseExited(MouseEvent arg0) {

	}

	public void mouseDragged(MouseEvent event) {

		altIsDown = event.isAltDown();

		int[] values = updateXY(event.getX(), event.getY());
		commonValues.m_x2=values[0];
		commonValues.m_y2=values[1];

		if(commonValues.isPDF())
			generateNewCursorBox();


	}

	public void mouseMoved(MouseEvent event) {

		//Update cursor for this position
//		int[] values = updateXY(event.getX(), event.getY());
//		int x =values[0];
//		int y =values[1];
//		decode_pdf.getObjectUnderneath(x, y);


	}


	/**
	 * get raw co-ords and convert to correct scaled units
	 * @return int[] of size 2, [0]=new x value, [1] = new y value
	 */
	protected int[] updateXY(int originalX, int originalY) {

		float scaling=currentGUI.getScaling();
		int inset=currentGUI.getPDFDisplayInset();
		int rotation=currentGUI.getRotation();

		//get co-ordinates of top point of outine rectangle
		int x=(int)(((currentGUI.AdjustForAlignment(originalX))-inset)/scaling);
		int y=(int)((originalY-inset)/scaling);

		//undo any viewport scaling
		if(commonValues.maxViewY!=0){ // will not be zero if viewport in play
			x=(int)(((x-(commonValues.dx*scaling))/commonValues.viewportScale));
			y=(int)((currentGUI.mediaH-((currentGUI.mediaH-(y/scaling)-commonValues.dy)/commonValues.viewportScale))*scaling);
		}

		int[] ret=new int[2];
		if(rotation==90){	        
			ret[1] = x+currentGUI.cropY;
			ret[0] =y+currentGUI.cropX;
		}else if((rotation==180)){
			ret[0]=currentGUI.mediaW- (x+currentGUI.mediaW-currentGUI.cropW-currentGUI.cropX);
			ret[1] =y+currentGUI.cropY;
		}else if((rotation==270)){
			ret[1] =currentGUI.mediaH- (x+currentGUI.mediaH-currentGUI.cropH-currentGUI.cropY);
			ret[0]=currentGUI.mediaW-(y+currentGUI.mediaW-currentGUI.cropW-currentGUI.cropX);
		}else{
			ret[0] = x+currentGUI.cropX;
			ret[1] =currentGUI.mediaH-(y+currentGUI.mediaH-currentGUI.cropH-currentGUI.cropY);    
		}
		return ret;
	}


	/**
	 * Create right click menu if does not exist
	 */
	private void createRightClickMenu(){

		copy = new JMenuItem(Messages.getMessage("PdfRightClick.copy"));
		selectAll = new JMenuItem(Messages.getMessage("PdfRightClick.selectAll"));
		deselectall = new JMenuItem(Messages.getMessage("PdfRightClick.deselectAll"));
		extract = new JMenu(Messages.getMessage("PdfRightClick.extract"));
		extractText = new JMenuItem(Messages.getMessage("PdfRightClick.extractText"));
		extractImage = new JMenuItem(Messages.getMessage("PdfRightClick.extractImage"));
		snapshotIcon = new ImageIcon(getClass().getResource("/org/jpedal/examples/simpleviewer/res/snapshot_menu.gif"));
		snapShot = new JMenuItem(Messages.getMessage("PdfRightClick.snapshot"), snapshotIcon);
		find = new JMenuItem(Messages.getMessage("PdfRightClick.find"));
		speakHighlighted = new JMenuItem("Speak Highlighted text");

		rightClick.add(copy);
		copy.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				currentGUI.currentCommands.executeCommand(Commands.COPY, null);
			}
		});

		rightClick.addSeparator();


		rightClick.add(selectAll);
		selectAll.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				currentGUI.currentCommands.executeCommand(Commands.SELECTALL, null);
			}
		});

		rightClick.add(deselectall);
		deselectall.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				currentGUI.currentCommands.executeCommand(Commands.DESELECTALL, null);
			}
		});

		rightClick.addSeparator();

		rightClick.add(extract);

		extract.add(extractText);
		extractText.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(decode_pdf.getDisplayView()==1)
					currentGUI.currentCommands.extractSelectedText();
				else{
					if(SimpleViewer.showMessages)
						JOptionPane.showMessageDialog(currentGUI.getFrame(),"Text Extraction is only avalible in single page display mode");
				}
			}
		});

		extract.add(extractImage);
		extractImage.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(decode_pdf.getHighlightImage()==null){
					if(SimpleViewer.showMessages)
						JOptionPane.showMessageDialog(decode_pdf, "No image has been selected for extraction.", "No image selected", JOptionPane.ERROR_MESSAGE);
				}else{
					if(decode_pdf.getDisplayView()==1){
						JFileChooser jf = new JFileChooser();
						FileFilter ff1 = new FileFilter(){
							public boolean accept(File f){
								return f.isDirectory() || f.getName().toLowerCase().endsWith(".jpg") || f.getName().toLowerCase().endsWith(".jpeg");
							}
							public String getDescription(){
								return "JPG (*.jpg)" ;
							}
						};
						FileFilter ff2 = new FileFilter(){
							public boolean accept(File f){
								return f.isDirectory() || f.getName().toLowerCase().endsWith(".png");
							}
							public String getDescription(){
								return "PNG (*.png)" ;
							}
						};
						FileFilter ff3 = new FileFilter(){
							public boolean accept(File f){
								return f.isDirectory() || f.getName().toLowerCase().endsWith(".tif") || f.getName().toLowerCase().endsWith(".tiff");
							}
							public String getDescription(){
								return "TIF (*.tiff)" ;
							}
						};
						jf.addChoosableFileFilter(ff3);
						jf.addChoosableFileFilter(ff2);
						jf.addChoosableFileFilter(ff1);
						jf.showSaveDialog(null);

						File f = jf.getSelectedFile();
						boolean failed = false;
						if(f!=null){
							String filename = f.getAbsolutePath();
							String type = jf.getFileFilter().getDescription().substring(0,3).toLowerCase();

							//Check to see if user has entered extension if so ignore filter
							if(filename.indexOf('.')!=-1){
								String testExt = filename.substring(filename.indexOf('.')+1).toLowerCase();
								if(testExt.equals("jpg") || testExt.equals("jpeg"))
									type = "jpg";
								else
									if(testExt.equals("png"))
										type = "png";
									else //*.tiff files using JAI require *.TIFF
										if(testExt.equals("tif") || testExt.equals("tiff"))
											type = "tiff";
										else{
											//Unsupported file format
											if(SimpleViewer.showMessages)
												JOptionPane.showMessageDialog(null, "Sorry, we can not currently save images to ."+testExt+" files.");
											failed = true;
										}
							}

							//JAI requires *.tiff instead of *.tif
							if(type.equals("tif"))
								type = "tiff";

							//Image saved in All files filter, default to .png
							if(type.equals("all"))
								type = "png";

							//If no extension at end of name, added one
							if(!filename.toLowerCase().endsWith('.' +type))
								filename = filename+ '.' +(type);

							//If valid extension was choosen
							if(!failed)
								decode_pdf.getDynamicRenderer().saveImage(id, filename, type);
						}
					}
				}
			}
		});

		extract.add(snapShot);
		snapShot.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				currentGUI.currentCommands.executeCommand(Commands.SNAPSHOT, null);
			}
		});

		rightClick.addSeparator();

		rightClick.add(find);
		find.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {

				/**ensure co-ords in right order*/
				Rectangle coords= decode_pdf.getCursorBoxOnScreen();
				if(coords==null){
					if(SimpleViewer.showMessages)
						JOptionPane.showMessageDialog(decode_pdf, "There is no text selected.\nPlease highlight the text you wish to search.", "No Text selected", JOptionPane.ERROR_MESSAGE);
					return;
				}

				String textToFind=currentGUI.showInputDialog(Messages.getMessage("PdfViewerMessage.GetUserInput"));

				//if cancel return to menu.
				if(textToFind==null || textToFind.length()<1){
					return;
				}


				int t_x1=coords.x;
				int t_x2=coords.x+coords.width;
				int t_y1=coords.y;
				int t_y2=coords.y+coords.height;

				if(t_y1<t_y2){
					int temp = t_y2;
					t_y2=t_y1;
					t_y1=temp;
				}

				if(t_x1>t_x2){
					int temp = t_x2;
					t_x2=t_x1;
					t_x1=temp;
				}

				if(t_x1<currentGUI.cropX)
					t_x1 = currentGUI.cropX;
				if(t_x1>currentGUI.mediaW-currentGUI.cropX)
					t_x1 = currentGUI.mediaW-currentGUI.cropX;

				if(t_x2<currentGUI.cropX)
					t_x2 = currentGUI.cropX;
				if(t_x2>currentGUI.mediaW-currentGUI.cropX)
					t_x2 = currentGUI.mediaW-currentGUI.cropX;

				if(t_y1<currentGUI.cropY)
					t_y1 = currentGUI.cropY;
				if(t_y1>currentGUI.mediaH-currentGUI.cropY)
					t_y1 = currentGUI.mediaH-currentGUI.cropY;

				if(t_y2<currentGUI.cropY)
					t_y2 = currentGUI.cropY;
				if(t_y2>currentGUI.mediaH-currentGUI.cropY)
					t_y2 = currentGUI.mediaH-currentGUI.cropY;

				//<start-demo>
				/**<end-demo>
                 if(SimpleViewer.showMessages)
                 JOptionPane.showMessageDialog(currentGUI.getFrame(),Messages.getMessage("PdfViewerMessage.FindDemo"));
                 textToFind=null;
                 /**/

				int searchType = SearchType.DEFAULT;

				int caseSensitiveOption=currentGUI.showConfirmDialog(Messages.getMessage("PdfViewercase.message"),
						null,	JOptionPane.YES_NO_OPTION);

				if(caseSensitiveOption==JOptionPane.YES_OPTION)
					searchType |= SearchType.CASE_SENSITIVE;

				int findAllOption=currentGUI.showConfirmDialog(Messages.getMessage("PdfViewerfindAll.message"),
						null,	JOptionPane.YES_NO_OPTION);

				if(findAllOption==JOptionPane.NO_OPTION)
					searchType |= SearchType.FIND_FIRST_OCCURANCE_ONLY;

				int hyphenOption=currentGUI.showConfirmDialog(Messages.getMessage("PdfViewerfindHyphen.message"),
						null,	JOptionPane.YES_NO_OPTION);

				if(hyphenOption==JOptionPane.YES_OPTION)
					searchType |= SearchType.MUTLI_LINE_RESULTS;

				if(textToFind!=null){
					try {
						float[] co_ords;

//						if((searchType & SearchType.MUTLI_LINE_RESULTS)==SearchType.MUTLI_LINE_RESULTS)
//							co_ords = decode_pdf.getGroupingObject().findTextInRectangleAcrossLines(t_x1,t_y1,t_x2,t_y2,commonValues.getCurrentPage(),textToFind,searchType);
//						else
//							co_ords = decode_pdf.getGroupingObject().findTextInRectangle(t_x1,t_y1,t_x2,t_y2,commonValues.getCurrentPage(),textToFind,searchType);

						co_ords = decode_pdf.getGroupingObject().findText(new Rectangle(t_x1,t_y1,t_x2-t_x1,t_y2-t_y1),commonValues.getCurrentPage(),new String[]{textToFind},searchType);

						if(co_ords!=null){
							if(co_ords.length<3)
								currentGUI.showMessageDialog(Messages.getMessage("PdfViewerMessage.Found")+ ' ' +co_ords[0]+ ',' +co_ords[1]);
							else{
								StringBuffer displayCoords = new StringBuffer();
								String coordsMessage = Messages.getMessage("PdfViewerMessage.FoundAt");
								for(int i=0;i<co_ords.length;i=i+5){
									displayCoords.append(coordsMessage).append(' ');
									displayCoords.append(co_ords[i]);
									displayCoords.append(',');
									displayCoords.append(co_ords[i+1]);

									//										//Other two coords of text
									//										displayCoords.append(',');
									//										displayCoords.append(co_ords[i+2]);
									//										displayCoords.append(',');
									//										displayCoords.append(co_ords[i+3]);

									displayCoords.append('\n');
									if(co_ords[i+4]==-101){
										coordsMessage = Messages.getMessage("PdfViewerMessage.FoundAtHyphen");
									}else{
										coordsMessage = Messages.getMessage("PdfViewerMessage.FoundAt");
									}

								}
								currentGUI.showMessageDialog(displayCoords.toString());
							}
						}else
							currentGUI.showMessageDialog(Messages.getMessage("PdfViewerMessage.NotFound"));

					} catch (PdfException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
			}

		});



		menuCreated = true;
		decode_pdf.add(rightClick);
	}

	/**
	 * generate new  cursorBox and highlight extractable text,
	 * if hardware acceleration off and extraction on<br>
	 * and update current cursor box displayed on screen
	 */
	protected void generateNewCursorBox() {

		//redraw rectangle of dragged box onscreen if it has changed significantly
		if ((old_m_x2!=-1)|(old_m_y2!=-1)|(Math.abs(commonValues.m_x2-old_m_x2)>5)|(Math.abs(commonValues.m_y2-old_m_y2)>5)) {	

			//allow for user to go up
			int top_x = commonValues.m_x1;
			if (commonValues.m_x1 > commonValues.m_x2)
				top_x = commonValues.m_x2;
			int top_y = commonValues.m_y1;
			if (commonValues.m_y1 > commonValues.m_y2)
				top_y = commonValues.m_y2;
			int w = Math.abs(commonValues.m_x2 - commonValues.m_x1);
			int h = Math.abs(commonValues.m_y2 - commonValues.m_y1);

			//add an outline rectangle  to the display
			Rectangle currentRectangle=new Rectangle (top_x,top_y,w,h);
			currentGUI.setRectangle(currentRectangle);

			//tell JPedal to highlight text in this area (you can add other areas to array)
			decode_pdf.updateCursorBoxOnScreen(currentRectangle,PdfDecoder.highlightColor);
			if(!decode_pdf.isExtractingAsImage()){
				int type = decode_pdf.getDynamicRenderer().getObjectUnderneath(commonValues.m_x1, commonValues.m_y1);

				if((altIsDown &&
						(type!=DynamicVectorRenderer.TEXT && type!=DynamicVectorRenderer.TRUETYPE && 
								type!=DynamicVectorRenderer.TYPE1C && type!=DynamicVectorRenderer.TYPE3))){

					//Remove previous highlights to prevent overlaps
					decode_pdf.clearHighlights();

					if(decode_pdf.getDisplayView()!=Display.SINGLE_PAGE &&
							decode_pdf.getDisplayView()!=Display.PAGEFLOW &&
							decode_pdf.getDisplayView()!=Display.PAGEFLOW3D){
						int page = commonValues.getCurrentPage();
						while(currentRectangle.y<(decode_pdf.getPageOffsets(page).y/decode_pdf.getScaling()) && page>0){
							page--;
							decode_pdf.addHighlights(new Rectangle[]{currentRectangle}, true, page);
						}

						page = commonValues.getCurrentPage();
						while(currentRectangle.y>(decode_pdf.getPageOffsets(page).y/decode_pdf.getScaling())+decode_pdf.getPdfPageData().getCropBoxHeight(page) && page>0){
							page++;
							decode_pdf.addHighlights(new Rectangle[]{currentRectangle}, true, page);
						}
					}
					//Highlight all within the rectangle
					decode_pdf.addHighlights(new Rectangle[]{currentRectangle}, true, commonValues.getCurrentPage());
					//decode_pdf.setMouseHighlightArea(currentRectangle);

				}else{ //Find start and end locations and highlight all object in order in between
					Rectangle r = new Rectangle(commonValues.m_x1, commonValues.m_y1,commonValues.m_x2 - commonValues.m_x1, commonValues.m_y2-commonValues.m_y1);

					//When not in single page mode coords are handled backward
					if(decode_pdf.getDisplayView()!=Display.SINGLE_PAGE)
						r = new Rectangle(commonValues.m_x1, commonValues.m_y1,commonValues.m_x2 - commonValues.m_x1, commonValues.m_y1-commonValues.m_y2);

					if(decode_pdf.getDisplayView()!=Display.SINGLE_PAGE &&
							decode_pdf.getDisplayView()!=Display.PAGEFLOW &&
							decode_pdf.getDisplayView()!=Display.PAGEFLOW3D){
						int page = commonValues.getCurrentPage();
						while((-r.y)<(decode_pdf.getPageOffsets(page).y/decode_pdf.getScaling()) && page>0){
							page--;
							Rectangle highlight = new Rectangle((r.x-decode_pdf.getPageOffsets(page).x)+decode_pdf.getInsetW(), (r.y-decode_pdf.getPageOffsets(page).y)+decode_pdf.getInsetH(), r.width, -r.height);
							decode_pdf.addHighlights(new Rectangle[]{highlight}, false, page);
						}

						page = commonValues.getCurrentPage();
						while((-r.y)>(decode_pdf.getPageOffsets(page).y/decode_pdf.getScaling())+decode_pdf.getPdfPageData().getCropBoxHeight(page) && page<commonValues.getPageCount()){
							page++;
							Rectangle highlight = new Rectangle(r.x-decode_pdf.getPageOffsets(page).x, (r.y)-decode_pdf.getPageOffsets(page).y, r.width, -r.height);
							decode_pdf.addHighlights(new Rectangle[]{highlight}, false, page);
						}
						Rectangle highlight = new Rectangle((r.x-decode_pdf.getPageOffsets(page).x)+decode_pdf.getInsetW(), (r.y-decode_pdf.getPageOffsets(page).y)+decode_pdf.getInsetH(), r.width, -r.height);
						decode_pdf.addHighlights(new Rectangle[]{highlight}, false, commonValues.getCurrentPage());

					}else{
						//System.out.println(r);
						decode_pdf.addHighlights(new Rectangle[]{r}, false, commonValues.getCurrentPage());
						//decode_pdf.setFoundTextPoints(new Point(commonValues.m_x1, commonValues.m_y1), new Point(commonValues.m_x2, commonValues.m_y2));
					}
				}
			}
			//reset tracking
			old_m_x2=commonValues.m_x2;
			old_m_y2=commonValues.m_y2;

		}
	}


}
