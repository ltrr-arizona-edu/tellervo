/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2011, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * StreamDecoderStatus.java
  * ---------------
 */
package org.jpedal.parser;

import org.jpedal.PdfDecoder;
import org.jpedal.constants.PDFImageProcessing;

/**
 * hold all the status flag we have
 */
public class StreamDecoderStatus {

    /**flag to show if page content or a substream*/
    public boolean isPageContent = true;

    /**images on page*/
    public int imageCount=0;

    public boolean getSamplingOnly=false;


    public boolean sharpenDownsampledImages=false;

    //used internally to show optimisations
    private int optionsApplied= PDFImageProcessing.NOTHING;

    public boolean imagesProcessedFully;

    /**flag to show raw images extracted*/
    public boolean finalImagesExtracted=true;

    public boolean extractRawCMYK=false;

    /**flag to show if we physical generate a scaled version of the
     * images extracted*/
    boolean createScaledVersion = true;

    /**flag to show content is being rendered*/
    boolean renderImages=false;

    public float samplingUsed=-1;

    /**custom upscale val for JPedal settings*/
    public float multiplyer = 1;

    /**copy of flag to tell program whether to create
     * (and possibly update) screen display
     */
    public boolean renderPage = false;

    /**flag to show raw images extracted*/
    public boolean clippedImagesExtracted=true;

    /**flag to show being used for printing onto G2*/
    public boolean isPrinting;

    /**flag to show raw images extracted*/
    public boolean rawImagesExtracted=true;

    /**flag to show if YCCK images*/
    public boolean hasYCCKimages=false;

    public int streamType= ValueTypes.UNSET;

    public String fileName="";


    public StreamDecoderStatus(){

        String nodownsamplesharpen=System.getProperty("org.jpedal.sharpendownsampledimages");
        if(nodownsamplesharpen!=null)
            this.sharpenDownsampledImages=(nodownsamplesharpen.toLowerCase().indexOf("true")!=-1);
    }

    public void init(boolean pageContent, int extractionMode, int renderMode, boolean renderPage) {

        this.isPageContent=pageContent;
        this.renderPage=renderPage;

        finalImagesExtracted=(extractionMode & PdfDecoder.FINALIMAGES) == PdfDecoder.FINALIMAGES;

        extractRawCMYK=(extractionMode &PdfDecoder.CMYKIMAGES)==PdfDecoder.CMYKIMAGES;
        rawImagesExtracted=(extractionMode & PdfDecoder.RAWIMAGES) == PdfDecoder.RAWIMAGES;

        clippedImagesExtracted=(extractionMode &PdfDecoder.CLIPPEDIMAGES)==PdfDecoder.CLIPPEDIMAGES;

        renderImages=renderPage &&(renderMode & PdfDecoder.RENDERIMAGES )== PdfDecoder.RENDERIMAGES;

        createScaledVersion = finalImagesExtracted || renderImages;

    }

    public void setName(String name) {
        if(name!=null){
            this.fileName=name.toLowerCase();

            /**check no separators*/
            int sep=fileName.lastIndexOf(47); // '/'=47
            if(sep!=-1)
                fileName=fileName.substring(sep+1);
            sep=fileName.lastIndexOf(92); // '\\'=92
            if(sep!=-1)
                fileName=fileName.substring(sep+1);
            sep=fileName.lastIndexOf(46); // "."=46
            if(sep!=-1)
                fileName=fileName.substring(0,sep);
        }
    }
}
