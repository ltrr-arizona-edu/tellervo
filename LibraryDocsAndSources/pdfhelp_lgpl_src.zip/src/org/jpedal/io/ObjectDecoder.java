/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2011, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * ObjectDecoder.java
  * ---------------
 */
package org.jpedal.io;

import org.bouncycastle.crypto.RuntimeCryptoException;
import org.jpedal.objects.raw.*;
import org.jpedal.color.ColorSpaces;
import org.jpedal.constants.PDFflags;
import org.jpedal.exception.PdfException;
import org.jpedal.exception.PdfSecurityException;
import org.jpedal.objects.Javascript;

import org.jpedal.objects.PdfFileInformation;
import org.jpedal.utils.*;
import org.jpedal.utils.repositories.Vector_Int;

import java.io.*;
import java.util.Arrays;import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 */
public class ObjectDecoder implements Serializable {

    private PdfFileReader objectReader=null;

    /**list of cached objects to delete*/
    private Map cachedObjects=new HashMap();

    //Colorspaces
    private Map cachedColorspaces=new HashMap();

    private LinearizedHintTable linHintTable;

    private DecryptionFactory decryption=null;

    private int newCacheSize=-1;

    /**used to cache last compressed object*/
    private byte[] lastCompressedStream=null;

    /**used to cache last compressed object*/
    private Map lastOffsetStart,lastOffsetEnd;

    private PdfObject compressedObj;

    /**used to cache last compressed object*/
    private int lastFirst=-1,lastCompressedID=-1;

    final static byte[] endPattern = { 101, 110, 100, 111, 98, 106 }; //pattern endobj

    private final static byte[] endObj = { 32, 111, 98, 106 }; //pattern endobj

    private final static byte[] lengthString = { 47, 76, 101, 110, 103, 116, 104}; //pattern /Length
    private final static byte[] startStream = { 115, 116, 114, 101, 97, 109};

    boolean refTableInvalid=false;

    private static final boolean debugFastCode =false; //objRef.equals("68 0 R")

    /**used in debuggin output*/
    private static String padding="";

    /**copy so we can access in other routine*/
    PdfObject linearObj;

    public void init(PdfFileReader objectReader){
        this.objectReader=objectReader;
    }

    public void setDecryption(DecryptionFactory decryption){
        this.decryption=decryption;

    }

/**
     * set size over which objects kept on disk
     */
    public void setCacheSize(int miniumumCacheSize) {

        newCacheSize=miniumumCacheSize;

    }


    /**
     * read a dictionary object
     */
    public int readDictionaryAsObject(PdfObject pdfObject, String objRef, int i, byte[] raw, int endPt, boolean isInlineImage){

        //used to debug issues by printing out details for obj
        //(set to non-final above)
        //debugFastCode =objRef.equals("68 0 R");

        if(debugFastCode)
            padding = padding +"   ";

        Object PDFkey;
        int PDFkeyInt,pdfKeyType,level=0;
        final int length=raw.length;
        boolean isMap;

        //allow for no << at start
        if(isInlineImage)
            level=1;

        //show details in debug mode
        if(debugFastCode)
            ObjectUtils.showData(level, objRef, pdfObject, i, length, raw, padding);

        /**
         * main loop for read all values from Object data and store in PDF object
         */
        i = readObjectDataValues(pdfObject, objRef, i, raw, endPt, isInlineImage, level, length);

        /**
         * look for stream afterwards
         */
        if(!pdfObject.ignoreStream() && pdfObject.getGeneralType(-1)!=PdfDictionary.ID)
            readStreamData(pdfObject, i, raw, length);

        /**
         * we need full names for Forms
         */
        if(FormObject.newfieldnameRead && pdfObject.getObjectType()==PdfDictionary.Form)
            setFieldNames(pdfObject);

        if(debugFastCode){
            int len=padding.length();

            if(len>3)
                padding = padding.substring(0,len-3);
        }

        return i;

    }

    private int readObjectDataValues(PdfObject pdfObject, String objRef, int i, byte[] raw, int endPt, boolean isInlineImage, int level, int length) {
        int pdfKeyType;
        Object PDFkey;
        int PDFkeyInt;
        boolean isMap;
        while(true){

            if(i>=length)
                break;

            if(raw[i]==37){ //allow for comment and ignore

                while(i<length && raw[i]!=10 && raw[i]!=13)
                    i++;

                //move cursor to start of text
                while(i<length &&(raw[i]==9 || raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==60))
                    i++;
            }else if(raw[i]=='s' && raw[i+1]=='t' && raw[i+2]=='r' && raw[i+3]=='e' && raw[i+4]=='a' && raw[i+5]=='m')
                break;

            /**
             * exit conditions
             */
            if ((i>=length ||(endPt !=-1 && i>= endPt))||(raw[i] == 101 && raw[i + 1] == 110 && raw[i + 2] == 100 && raw[i + 3] == 111))
                break;

            /**
             * process value
             */
            if(raw[i]==60 && raw[i+1]==60){
                i++;
                level++;

                if(debugFastCode)
                    System.out.println(padding +"Enter Level "+level);

            }else if(raw[i]==62 && i+1!=length && raw[i+1]==62){
                i++;
                level--;

                if(debugFastCode)
                    System.out.println(padding +"Exit Level "+level);

                if(level==0)
                    break;
            }else if (raw[i] == 47 && (raw[i+1] == 47 || raw[i+1]==32)) { //allow for oddity of //DeviceGray  and / /DeviceGray in colorspace
                i++;
            }else  if (raw[i] == 47) { //everything from /

                i++; //skip /

                int keyLength=0,keyStart=i;

                while (true) { //get key up to space or [ or / or ( or < or carriage return

                    if (raw[i] == 32 || raw[i] == 13 || raw[i] == 9 || raw[i] == 10 || raw[i] == 91 ||
                            raw[i]==47 || raw[i]==40 || raw[i]==60 || raw[i]==62)
                        break;

                    i++;
                    keyLength++;

                    if(i==length)
                        break;
                }

                if(i==length)
                    break;

                int type=pdfObject.getObjectType();

                //if BDC see if string
                boolean isStringPair=false;
                if(pdfObject.getID()== PdfDictionary.BDC){
                    int len=raw.length;
                    for(int aa=i;aa<len;aa++){
                        if(raw[aa]=='('){
                            aa=len;
                            isStringPair=true;
                        }else if(raw[aa]=='/' || raw[aa]=='>' || raw[aa]=='<' || raw[aa]=='[' || raw[aa]=='R'){
                            aa=len;
                        }else if(raw[aa]=='M' && raw[aa+1]=='C' && raw[aa+2]=='I' && raw[aa+3]=='D'){
                            aa=len;
                        }
                    }
                }

                if(debugFastCode)
                    System.out.println("type="+type+" "+" "+pdfObject.getID()+" chars="+(char)raw[i-1]+(char)raw[i]+" "+pdfObject+" i="+i+" "+isStringPair);

                //ensure all go into 'pool'
                if(type==PdfDictionary.MCID && (pdfObject.getID()==PdfDictionary.RoleMap ||
                        (pdfObject.getID()==PdfDictionary.BDC && isStringPair) ||
                        (pdfObject.getID()==PdfDictionary.A && raw[i-2]=='/'))){

                    pdfKeyType=PdfDictionary.VALUE_IS_NAME;
                    PDFkey=PdfDictionary.getKey(keyStart,keyLength,raw);
                    PDFkeyInt=PdfDictionary.MCID;
                    isMap=true;

                }else{
                    isMap=false;
                    PDFkey=null;

                    /**
                     * get Dictionary key and type of value it takes
                     */
                    if(debugFastCode)//used in debug
                        PDFkey=PdfDictionary.getKey(keyStart,keyLength,raw);

                    PDFkeyInt=PdfDictionary.getIntKey(keyStart,keyLength,raw);

                    //correct mapping
                    if(PDFkeyInt==PdfDictionary.Indexed && (type==PdfDictionary.MK ||type==PdfDictionary.Form || type==PdfDictionary.Linearized))
                        PDFkeyInt=PdfDictionary.I;

                    if(isInlineImage)
                        PDFkeyInt= PdfObjectFactory.getInlineID(PDFkeyInt);

                    if(type==PdfDictionary.Resources && (PDFkeyInt==PdfDictionary.ColorSpace
                            || PDFkeyInt==PdfDictionary.ExtGState || PDFkeyInt==PdfDictionary.Shading
                            || PDFkeyInt==PdfDictionary.XObject || PDFkeyInt==PdfDictionary.Font|| PDFkeyInt==PdfDictionary.Pattern)){
                        pdfKeyType=PdfDictionary.VALUE_IS_DICTIONARY_PAIRS;
                        //}else if (type==PdfDictionary.Form && pdfObject.getID()== PdfDictionary.AA && PDFkeyInt== PdfDictionary.K){
                        //     pdfKeyType= PdfDictionary.VALUE_IS_UNREAD_DICTIONARY;
                    }else if (type==PdfDictionary.Outlines && PDFkeyInt== PdfDictionary.D){
                        PDFkeyInt= PdfDictionary.Dest;
                        pdfKeyType= PdfDictionary.VALUE_IS_MIXED_ARRAY;
                    }else if ((type==PdfDictionary.Form || type==PdfDictionary.MK) && PDFkeyInt== PdfDictionary.D){
                        if(pdfObject.getID()==PdfDictionary.AP || pdfObject.getID()==PdfDictionary.AA){
                            pdfKeyType= PdfDictionary.VALUE_IS_VARIOUS;
                        }else if(pdfObject.getID()==PdfDictionary.Win){
                            pdfKeyType= PdfDictionary.VALUE_IS_TEXTSTREAM;
                        }else{
                            PDFkeyInt= PdfDictionary.Dest;
                            pdfKeyType= PdfDictionary.VALUE_IS_MIXED_ARRAY;
                        }
                    }else if ((type==PdfDictionary.Form || type==PdfDictionary.MK) && (pdfObject.getID()==PdfDictionary.AP || pdfObject.getID()==PdfDictionary.AA) && PDFkeyInt== PdfDictionary.A){
                        pdfKeyType= PdfDictionary.VALUE_IS_VARIOUS;
                    }else if (PDFkeyInt== PdfDictionary.Order && type==PdfDictionary.OCProperties){
                        pdfKeyType= PdfDictionary. VALUE_IS_OBJECT_ARRAY;
                    }else if (PDFkeyInt== PdfDictionary.Name && type==PdfDictionary.OCProperties){
                        pdfKeyType= PdfDictionary.VALUE_IS_TEXTSTREAM;
                    }else if ((type==PdfDictionary.ColorSpace || type==PdfDictionary.Function) && PDFkeyInt== PdfDictionary.N){
                        pdfKeyType= PdfDictionary.VALUE_IS_FLOAT;
                    }else if(PDFkeyInt==PdfDictionary.Gamma && type==PdfDictionary.ColorSpace &&
                            pdfObject.getParameterConstant(PdfDictionary.ColorSpace)== ColorSpaces.CalGray){ //its a number not an array
                        pdfKeyType= PdfDictionary.VALUE_IS_FLOAT;
                    }else if(pdfObject.getID()==PdfDictionary.Win && pdfObject.getObjectType()==PdfDictionary.Form &&
                            (PDFkeyInt==PdfDictionary.P || PDFkeyInt==PdfDictionary.O)){
                        pdfKeyType= PdfDictionary.VALUE_IS_TEXTSTREAM;
                    }else if (isInlineImage && PDFkeyInt==PdfDictionary.ColorSpace){
                        pdfKeyType= PdfDictionary.VALUE_IS_DICTIONARY;
                    }else
                        pdfKeyType=PdfDictionary.getKeyType(PDFkeyInt,type);

                    //allow for other values in D,N,R definitions
                    if((pdfKeyType==-1 && pdfObject.getID()== PdfDictionary.ClassMap) ||
                            ((pdfKeyType==-1 || (keyLength==1 &&
                                    (pdfObject.getID()==PdfDictionary.N || pdfObject.getID()==PdfDictionary.D || pdfObject.getID()==PdfDictionary.R))) &&
                                    pdfObject.getParentID()==PdfDictionary.AP &&
                                    pdfObject.getObjectType()==PdfDictionary.Form
                                    && (pdfObject.getID()==PdfDictionary.D ||  pdfObject.getID()==PdfDictionary.N || pdfObject.getID()==PdfDictionary.R))
                            ){
                        pdfKeyType = getPairedValues(pdfObject, i, raw, pdfKeyType, length, keyLength, keyStart);
                    }

                    //DecodeParms can be an array as well as a dictionary so check next char and alter if so
                    if(PDFkeyInt==PdfDictionary.DecodeParms){

                        int ii=i;

                        //roll onto first valid char
                        while(ii<length && (raw[ii]==32 || raw[ii]==9 || raw[ii]==13 || raw[ii]==10))
                            ii++;

                        //see if might be object arrays
                        if(raw[ii]!='<'){

                            //roll onto first valid char
                            while(ii<length && (raw[ii]==32 || raw[ii]==9 || raw[ii]==13 || raw[ii]==10 || raw[ii]==91))
                                ii++;

                            if(raw[ii]=='<')
                                pdfKeyType=PdfDictionary.VALUE_IS_OBJECT_ARRAY;

                        }
                    }

                    //special case for K in AA object
                    //if (type==PdfDictionary.Form && pdfObject.getID()== PdfDictionary.AA && PDFkeyInt== PdfDictionary.K && pdfKeyType==PdfDictionary.VALUE_IS_DICTIONARY)
                    //    pdfKeyType= PdfDictionary.VALUE_IS_UNREAD_DICTIONARY;

                    if(debugFastCode && pdfKeyType==-1 &&  pdfObject.getObjectType()!=PdfDictionary.Page){
                        System.out.println(pdfObject.getID()+" "+type);
                        System.out.println(padding +PDFkey+" NO type setting for "+PdfDictionary.getKey(keyStart,keyLength,raw)+" id="+pdfObject.getID());
                    }
                }

                if(raw[i]==47 || raw[i]==40 || raw[i] == 91) //move back cursor
                    i--;

                //check for unknown value and ignore
                if(pdfKeyType==-1)
                    i = ObjectUtils.handleUnknownType(i, raw, length);

                /**
                 * now read value
                 */
                if(PDFkeyInt==-1 || pdfKeyType==-1){
                    if(debugFastCode)
                        System.out.println(padding + objRef +" =================Not implemented="+PDFkey+" pdfKeyType="+pdfKeyType);

                }else{

                    //if we only need top level do not read whole tree
                    boolean ignoreRecursion=pdfObject.ignoreRecursion();

                    if(debugFastCode)
                        System.out.println(padding + objRef +" =================Reading value for key="+PDFkey+" ("+PDFkeyInt+") type="+PdfDictionary.showAsConstant(pdfKeyType) +" ignorRecursion="+ignoreRecursion+" "+pdfObject);

                    //resolve now in this case as we need to ensure all parts present
                    if(pdfKeyType==PdfDictionary.VALUE_IS_UNREAD_DICTIONARY && pdfObject.isDataExternal())
                        pdfKeyType=PdfDictionary.VALUE_IS_DICTIONARY;


                    switch(pdfKeyType){

                        //read text stream (this is text)
                        //and also special case of [] in W in CID Fonts
                        case PdfDictionary.VALUE_IS_TEXTSTREAM:{

                            i = setTextStreamValue(pdfObject, objRef, i, raw, PDFkeyInt, ignoreRecursion);

                            break;

                        }case PdfDictionary.VALUE_IS_NAMETREE:{

                            boolean isRef=false;

                            //move to start
                            while(raw[i]!='[' ){ //can be number as well

                                if(raw[i]=='('){ //allow for W (7)
                                    isRef=false;
                                    break;
                                }

                                //allow for number as in refer 9 0 R
                                if(raw[i]>='0' && raw[i]<='9'){
                                    isRef=true;
                                    break;
                                }

                                i++;
                            }

                            //allow for direct or indirect
                            byte[] data=raw;

                            int start=i,j=i;

                            int count=0;

                            //read ref data and slot in
                            if(isRef){
                                //number
                                int keyStart2=i;
                                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                                    i++;

                                int number= NumberUtils.parseInt(keyStart2, i, raw);

                                //generation
                                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                                    i++;

                                keyStart2=i;
                                //move cursor to end of reference
                                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                                    i++;
                                int generation= NumberUtils.parseInt(keyStart2, i, raw);

                                //move cursor to start of R
                                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                                    i++;

                                if(raw[i]!=82) //we are expecting R to end ref
                                    throw new RuntimeException("3. Unexpected value in file "+raw[i]+" - please send to IDRsolutions for analysis");

                                if(!ignoreRecursion){

                                    //read the Dictionary data
                                    data=readObjectAsByteArray(pdfObject, objRef, objectReader.isCompressed(number, generation),number,generation);

                                    //allow for data in Linear object not yet loaded
                                    if(data==null){
                                        pdfObject.setFullyResolved(false);

                                        if(debugFastCode)
                                            System.out.println(padding +"Data not yet loaded");

                                        LogWriter.writeLog("[Linearized] " + objRef + " not yet available (1)");
                                        i=length;
                                        break;
                                    }

                                    //lose obj at start
                                    j=3;
                                    while(data[j-1]!=106 && data[j-2]!=98 && data[j-3]!=111)
                                        j++;

                                    //skip any spaces after
                                    while(data[j]==10 || data[j]==13 || data[j]==32)// || data[j]==47 || data[j]==60)
                                        j++;

                                    //reset pointer
                                    start=j;

                                }
                            }

                            //move to end
                            while(j<data.length){

                                if(data[j]=='[' || data[j]=='(')
                                    count++;
                                else if(data[j]==']' || data[j]==')')
                                    count--;

                                if(count==0)
                                    break;

                                j++;
                            }

                            if(!ignoreRecursion){
                                int stringLength=j-start+1;
                                byte[] newString=new byte[stringLength];

                                System.arraycopy(data, start, newString, 0, stringLength);
                                if(pdfObject.getObjectType()!=PdfDictionary.Encrypt && decryption!=null){
                                    try {
                                        newString=decryption.decrypt(newString, objRef, false,null, false,false,null);
                                    } catch (PdfSecurityException e) {
                                        e.printStackTrace();
                                    }
                                }


                                pdfObject.setTextStreamValue(PDFkeyInt, newString);

                                if(debugFastCode)
                                    System.out.println(padding +"name="+new String(newString)+" set in "+pdfObject);
                            }

                            //roll on
                            if(!isRef)
                                i=j;

                            break;

                            //readDictionary keys << /A 12 0 R /B 13 0 R >>
                        }case PdfDictionary.VALUE_IS_DICTIONARY_PAIRS:{

                            if(debugFastCode)
                                System.out.println(padding + ">>>Reading Dictionary Pairs i=" + i + " " + (char) raw[i] + (char) raw[i + 1] + (char) raw[i + 2] + (char) raw[i + 3] + (char) raw[i + 4] + (char) raw[i + 5]+(char)raw[i+6]);

                            //move cursor to start of text
                            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47)
                                i++;

                            //set data which will be switched below if ref
                            byte[] data=raw;
                            int j=i;

                            //get next key to see if indirect
                            boolean isRef=data[j]!='<';

                            if(isRef){

                                //number
                                int keyStart2=i;
                                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                                    i++;

                                int number= NumberUtils.parseInt(keyStart2, i, raw);

                                //generation
                                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                                    i++;

                                keyStart2=i;
                                //move cursor to end of reference
                                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                                    i++;
                                int generation= NumberUtils.parseInt(keyStart2, i, raw);

                                //move cursor to start of R
                                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                                    i++;

                                if(raw[i]!=82) //we are expecting R to end ref
                                    throw new RuntimeException("3. Unexpected value in file "+raw[i]+" - please send to IDRsolutions for analysis");

                                if(!ignoreRecursion){

                                    //read the Dictionary data
                                    data=readObjectAsByteArray(pdfObject, objRef, objectReader.isCompressed(number, generation),number,generation);

                                    //allow for data in Linear object not yet loaded
                                    if(data==null){
                                        pdfObject.setFullyResolved(false);

                                        if(debugFastCode)
                                            System.out.println(padding +"Data not yet loaded");

                                        LogWriter.writeLog("[Linearized] "+ objRef +" not yet available (2)");

                                        i=length;
                                        break;
                                    }

                                    if(data[0]=='<' && data[1]=='<'){
                                        j=0;
                                    }else{
                                        //lose obj at start
                                        j=3;

                                        while(data[j-1]!=106 && data[j-2]!=98 && data[j-3]!=111){

                                            if(data[j]=='/'){  //trap for odd case
                                                j=0;
                                                break;
                                            }

                                            j++;

                                            if(j==data.length){ //some missing obj so catch these
                                                j=0;
                                                break;
                                            }
                                        }

                                        //skip any spaces after
                                        while(data[j]==10 || data[j]==13 || data[j]==32)// || data[j]==47 || data[j]==60)
                                            j++;
                                    }

                                }
                            }

                            //allow for empty object (ie /Pattern <<>> )
                            int endJ=j;
                            while(data[endJ]=='<' || data[endJ]==' ' || data[endJ]==13 ||  data[endJ]==10)
                                endJ++;

                            if(data[endJ]=='>'){ //empty object
                                j=endJ+1;
                            }else{

                                PdfObject valueObj= ObjectFactory.createObject(PDFkeyInt, objRef, pdfObject.getObjectType(), pdfObject.getID());
                                valueObj.setID(PDFkeyInt);

                                /**
                                 * read pairs (stream in data starting at j)
                                 */
                                if(ignoreRecursion) //just skip to end
                                    j=readKeyPairs(PDFkeyInt,data, j,-2, null);
                                else{
                                    //count values first
                                    int count=readKeyPairs(PDFkeyInt,data, j,-1, null);

                                    //now set values
                                    j=readKeyPairs(PDFkeyInt,data, j,count,valueObj);


                                    //store value
                                    pdfObject.setDictionary(PDFkeyInt,valueObj);

                                    if(debugFastCode)
                                        System.out.println(padding +"Set Dictionary "+count+" pairs type "+PDFkey+"  in "+pdfObject+" to "+valueObj);
                                }
                            }

                            //update pointer if direct so at end (if ref already in right place)
                            if(!isRef){
                                i=j;

                                if(debugFastCode)
                                    System.out.println(i+">>>>"+data[i-2]+" "+data[i-1]+" >"+data[i]+"< "+data[i+1]+" "+data[i+2]);
                            }

                            break;

                            //Strings
                        }case PdfDictionary.VALUE_IS_STRING_ARRAY:{

                            i=readArray(ignoreRecursion, i, endPt, PdfDictionary.VALUE_IS_STRING_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                            break;

                            //read Object Refs in [] (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_BOOLEAN_ARRAY:{

                            i=readArray(false, i, endPt, PdfDictionary.VALUE_IS_BOOLEAN_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                            break;

                            //read Object Refs in [] (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_KEY_ARRAY:{

                            i=readArray(ignoreRecursion, i, endPt, PdfDictionary.VALUE_IS_KEY_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                            break;

                            //read numbers in [] (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_MIXED_ARRAY:{

                            i=readArray(ignoreRecursion, i, endPt, PdfDictionary.VALUE_IS_MIXED_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                            break;

                            //read numbers in [] (may be indirect ref)
                            //same as Mixed but allow for recursion and store as objects
                        }case PdfDictionary.VALUE_IS_OBJECT_ARRAY:{

                            i=readArray(false, i, endPt, PdfDictionary.VALUE_IS_OBJECT_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                            break;

                            //read numbers in [] (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_DOUBLE_ARRAY:{

                            i=readArray(false, i, endPt, PdfDictionary.VALUE_IS_DOUBLE_ARRAY, raw, objRef, pdfObject,PDFkeyInt, null, -1);

                            break;

                            //read numbers in [] (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_INT_ARRAY:{

                            i=readArray(false, i, endPt, PdfDictionary.VALUE_IS_INT_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                            break;

                            //read numbers in [] (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_FLOAT_ARRAY:{

                            i=readArray(false, i, endPt, PdfDictionary.VALUE_IS_FLOAT_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                            break;

                            //read String (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_NAME:{

                            i = readNameString(pdfObject, objRef, i, raw, PDFkeyInt, isMap, PDFkey);

                            break;

                            //read true or false
                        }case PdfDictionary.VALUE_IS_BOOLEAN:{

                            i = setBooleanValue(pdfObject, i, raw, PDFkey, PDFkeyInt);

                            break;
                            //read known set of values
                        }case PdfDictionary.VALUE_IS_STRING_CONSTANT:{

                            i = setStringConstantValue(pdfObject, i, raw, PDFkeyInt);

                            break;

                            //read known set of values
                        }case PdfDictionary.VALUE_IS_STRING_KEY:{

                            i++;

                            //move cursor to start of text
                            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47)
                                i++;

                            keyStart=i;
                            keyLength=1;

                            boolean isNull=false;

                            //move cursor to end of text (allow for null)
                            while(raw[i]!='R' && !isNull){

                                //allow for null for Parent
                                if(PDFkeyInt==PdfDictionary.Parent && raw[i]=='n' && raw[i+1]=='u' && raw[i+2]=='l' && raw[i+3]=='l')
                                    isNull=true;

                                i++;
                                keyLength++;
                            }

                            i--;// move back so loop works

                            if(!isNull){

                                //set value
                                byte[] stringBytes=new byte[keyLength];
                                System.arraycopy(raw,keyStart,stringBytes,0,keyLength);

                                //store value
                                pdfObject.setStringKey(PDFkeyInt,stringBytes);


                                if(debugFastCode)
                                    System.out.println(padding +"Set constant "+PDFkey+" in "+pdfObject+" to "+new String(stringBytes));
                            }

                            break;

                            //read number (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_INT:{

                            //roll on
                            i++;

                            //move cursor to start of text
                            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47)
                                i++;

                            i = readNumber(pdfObject, objRef, i, raw, PDFkeyInt, PDFkey);

                            break;

                            //read float number (may be indirect ref)
                        }case PdfDictionary.VALUE_IS_FLOAT:{

                            //roll on
                            i++;

                            //move cursor to start of text
                            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47)
                                i++;

                            keyStart=i;
                            keyLength=0;

                            //move cursor to end of text
                            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){
                                i++;
                                keyLength++;
                            }

                            //actual value or first part of ref
                            float number= NumberUtils.parseFloat(keyStart, i, raw);

                            //roll onto next nonspace char and see if number
                            int jj=i;
                            while(jj<length &&(raw[jj]==32 || raw[jj]==13 || raw[jj]==10))
                                jj++;

                            //check its not a ref (assumes it XX 0 R)
                            if(raw[jj]>= 48 && raw[jj]<=57){ //if next char is number 0-9 its a ref

                                //move cursor to start of generation
                                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                                    i++;

                                /**
                                 * get generation number
                                 */
                                keyStart=i;
                                //move cursor to end of reference
                                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                                    i++;

                                int generation= NumberUtils.parseInt(keyStart, i, raw);

                                //move cursor to start of R
                                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                                    i++;

                                if(raw[i]!=82){ //we are expecting R to end ref
                                    throw new RuntimeException("3. Unexpected value in file - please send to IDRsolutions for analysis");
                                }

                                //read the Dictionary data
                                byte[] data=readObjectAsByteArray(pdfObject, objRef, objectReader.isCompressed((int) number, generation),(int)number,generation);

                                //allow for data in Linear object not yet loaded
                                if(data==null){
                                    pdfObject.setFullyResolved(false);

                                    if(debugFastCode)
                                        System.out.println(padding +"Data not yet loaded");

                                    LogWriter.writeLog("[Linearized] "+ objRef +" not yet available (3)");

                                    i=length;
                                    break;
                                }

                                //lose obj at start
                                int j=3;
                                while(data[j-1]!=106 && data[j-2]!=98 && data[j-3]!=111)
                                    j++;

                                //skip any spaces after
                                while(data[j]==10 || data[j]==13 || data[j]==32)// || data[j]==47 || data[j]==60)
                                    j++;

                                int count=j;

                                //skip any spaces at end
                                while(data[count]!=10 && data[count]!=13 && data[count]!=32){// || data[j]==47 || data[j]==60)
                                    count++;
                                }

                                number= NumberUtils.parseFloat(j, count, data);

                            }

                            //store value
                            pdfObject.setFloatNumber(PDFkeyInt,number);

                            if(debugFastCode)
                                System.out.println(padding +"set key="+PDFkey+" numberValue="+number);//+" in "+pdfObject);

                            i--;// move back so loop works

                            break;

                            //read known Dictionary object which may be direct or indirect

                        }case PdfDictionary.VALUE_IS_UNREAD_DICTIONARY:{

                            i = getUnreadDictionary(pdfObject, objRef, i, raw, isInlineImage, PDFkeyInt);

                            break;

                        }case PdfDictionary.VALUE_IS_VARIOUS:{

                            if(raw[i]!='<')
                                i++;

                            if(debugFastCode)
                                System.out.println(padding +"Various value (first char="+(char)raw[i]+(char)raw[i+1]+" )");

                            if(raw[i]=='/'){
                                i = readNameString(pdfObject, objRef, i, raw, PDFkeyInt, isMap, PDFkey);
                            }else if(raw[i]=='f' && raw[i+1]=='a' && raw[i+2]=='l' && raw[i+3]=='s' && raw[i+4]=='e'){
                                pdfObject.setBoolean(PDFkeyInt,false);
                                i=i+4;
                            }else if(raw[i]=='t' && raw[i+1]=='r' && raw[i+2]=='u' && raw[i+3]=='e') {
                                pdfObject.setBoolean(PDFkeyInt,true);
                                i=i+3;
                            }else if(raw[i]=='(' || (raw[i]=='<' && raw[i-1]!='<' && raw[i+1]!='<')){
                                i = readTextStream(pdfObject, objRef, i, raw, PDFkeyInt, ignoreRecursion);
                            }else if(raw[i]=='['){

                                if(PDFkeyInt== PdfDictionary.XFA)
                                    i=readArray(ignoreRecursion, i, endPt, PdfDictionary.VALUE_IS_MIXED_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);
                                else if(PDFkeyInt== PdfDictionary.K)
                                    i=readArray(ignoreRecursion, i, endPt, PdfDictionary.VALUE_IS_STRING_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                                else if(PDFkeyInt== PdfDictionary.C)
                                    i=readArray(ignoreRecursion, i, endPt, PdfDictionary.VALUE_IS_FLOAT_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);
                                else
                                    i=readArray(ignoreRecursion, i, endPt, PdfDictionary.VALUE_IS_STRING_ARRAY, raw, objRef, pdfObject, PDFkeyInt, null, -1);

                            }else{

                                if(debugFastCode)
                                    System.out.println(padding +"general case "+i);

                                //see if number or ref
                                int jj=i;
                                int j=i+1;
                                byte[] data=raw;
                                int typeFound=0;
                                boolean isNumber=true, isRef=false, isString=false;

                                while(true){

                                    if(data[j]=='R' && !isString){

                                        isRef=true;
                                        int end=j;
                                        j=i;
                                        i=end;

                                        int ref, generation;

                                        //allow for [ref] at top level (may be followed by gap
                                        while (data[j] == 91 || data[j] == 32 || data[j] == 13 || data[j] == 10)
                                            j++;

                                        // get object ref
                                        keyStart = j;
                                        int refStart=j;
                                        //move cursor to end of reference
                                        while (data[j] != 10 && data[j] != 13 && data[j] != 32 && data[j] != 47 && data[j] != 60 && data[j] != 62)
                                            j++;

                                        ref = NumberUtils.parseInt(keyStart, j, data);

                                        //move cursor to start of generation or next value
                                        while (data[j] == 10 || data[j] == 13 || data[j] == 32)// || data[j]==47 || data[j]==60)
                                            j++;

                                        /**
                                         * get generation number
                                         */
                                        keyStart = j;
                                        //move cursor to end of reference
                                        while (data[j] != 10 && data[j] != 13 && data[j] != 32 && data[j] != 47 && data[j] != 60 && data[j] != 62)
                                            j++;

                                        generation = NumberUtils.parseInt(keyStart, j, data);

                                        /**
                                         * check R at end of reference and abort if wrong
                                         */
                                        //move cursor to start of R
                                        while (data[j] == 10 || data[j] == 13 || data[j] == 32 || data[j] == 47 || data[j] == 60)
                                            j++;

                                        if (data[j] != 82)  //we are expecting R to end ref
                                            throw new RuntimeException("ref=" + ref + " gen=" + ref + " 1. Unexpected value " + data[j] + " in file - please send to IDRsolutions for analysis char=" + (char) data[j]);

                                        objRef =new String(data,refStart,1+j-refStart);

                                        //read the Dictionary data
                                        //boolean setting=debugFastCode;
                                        byte[] newData = readObjectAsByteArray(pdfObject, objRef, objectReader.isCompressed(ref, generation), ref, generation);

                                        //stop string with R failing in loop
                                        isString=newData[0]=='(';

                                        if(pdfObject.getID()== PdfDictionary.AA && newData[0]=='<' && newData[1]=='<'){

                                            //create and store stub
                                            PdfObject valueObj= ObjectFactory.createObject(PDFkeyInt,objRef, pdfObject.getObjectType(), pdfObject.getID());
                                            valueObj.setID(PDFkeyInt);

                                            pdfObject.setDictionary(PDFkeyInt,valueObj);
                                            valueObj.setStatus(PdfObject.UNDECODED_DIRECT);
                                            valueObj.setUnresolvedData(newData,PdfObject.UNDECODED_DIRECT);

                                            if(debugFastCode)
                                                System.out.println(padding +"obj ");

                                            isNumber=false;
                                            typeFound=4;

                                            i=j;

                                            break;

                                            //allow for indirect on OpenAction
                                        }else if(PDFkeyInt== PdfDictionary.OpenAction){
                                            readArray(ignoreRecursion, 0, endPt, PdfDictionary.VALUE_IS_MIXED_ARRAY, data, objRef, pdfObject, PDFkeyInt, null, -1);
                                            i=j;
                                            break;
                                        }else{

                                            data=newData;

                                            //allow for data in Linear object not yet loaded
                                            if(data==null){
                                                pdfObject.setFullyResolved(false);

                                                if(debugFastCode)
                                                    System.out.println(padding +"Data not yet loaded");

                                                LogWriter.writeLog("[Linearized] "+ objRef +" not yet available (4)");

                                                i=length;
                                                break;
                                            }

                                            jj=3;

                                            if(data.length<=3){
                                                jj=0;
                                            }else{
                                                while(true){
                                                    if(data[jj-2]=='o' && data[jj-1]=='b' && data[jj]=='j')
                                                        break;

                                                    jj++;

                                                    if(jj==data.length){
                                                        jj=0;
                                                        break;
                                                    }
                                                }
                                            }

                                            if(data[jj]!='(') //do not roll on if text string
                                                jj++;

                                            while (data[jj] == 10 || data[jj] == 13 || data[jj] == 32)// || data[j]==47 || data[j]==60)
                                                jj++;

                                            j=jj;

                                            if(debugFastCode)
                                                System.out.println(j+" >>"+new String(data)+"<<next="+(char)data[j]);
                                        }
                                    }else if(data[j]=='[' || data[j]=='('){
                                        //typeFound=0;
                                        break;
                                    }else if(data[j]=='<'){
                                        typeFound=0;
                                        break;

                                    }else if(data[j]=='>' || data[j]=='/'){
                                        typeFound=1;
                                        break;
                                    }else if(data[j]==32 || data[j]==10 || data[j]==13){
                                    }else if((data[j]>='0' && data[j] <='9')|| data[j]=='.'){ //assume and disprove
                                    }else{
                                        isNumber=false;
                                    }
                                    j++;
                                    if(j==data.length)
                                        break;
                                }

                                //check if name by counting /
                                int count=0;
                                for(int aa=jj+1;aa<data.length;aa++){
                                    if(data[aa]=='/')
                                        count++;
                                }

                                //lose spurious spaces
                                while (data[jj] == 10 || data[jj] == 13 || data[jj] == 32)// || data[j]==47 || data[j]==60)
                                    jj++;

                                if(typeFound==4){//direct ref done above
                                }else if(count==0 && data[jj]=='/'){

                                    if(debugFastCode)
                                        System.out.println(padding +"NameString ");

                                    jj = readNameString(pdfObject, objRef, jj, data, PDFkeyInt, isMap, PDFkey);
                                }else if(data[jj]=='('){

                                    if(debugFastCode)
                                        System.out.println(padding +"Textstream ");

                                    jj = readTextStream(pdfObject, objRef, jj, data, PDFkeyInt, ignoreRecursion);
                                }else if(data[jj]=='['){

                                    if(debugFastCode)
                                        System.out.println(padding +"Array ");

                                    jj=readArray(ignoreRecursion, jj, endPt, PdfDictionary.VALUE_IS_STRING_ARRAY, data, objRef, pdfObject, PDFkeyInt,null, -1);
                                    /**/
                                }else if(typeFound==0){
                                    if(debugFastCode)
                                        System.out.println("Dictionary " + (char) +data[jj]+(char)data[jj+1]);

                                    try{
                                        jj = readDictionaryFromRefOrDirect(-1,pdfObject, objRef,jj , data, PDFkeyInt);

                                    }catch(Exception ee){
                                        ee.printStackTrace();
                                    }

                                }else if(isNumber){

                                    if(debugFastCode)
                                        System.out.println("Number");

                                    jj=readNumber(pdfObject, objRef,jj, data, PDFkeyInt, PDFkey);

                                }else if(typeFound==1){

                                    if(debugFastCode)
                                        System.out.println("Name");

                                    jj = readNameString(pdfObject, objRef, jj, data, PDFkeyInt, isMap,PDFkey);

                                }else if(debugFastCode)
                                    System.out.println(padding +"Not read");

                                if(!isRef)
                                    i=jj;
                            }

                            break;

                        }case PdfDictionary.VALUE_IS_DICTIONARY:{

                            /**
                             * workout actual end as not always returned right
                             */
                            int end=i;
                            int nextC=i;

                            //ignore any gaps
                            while(raw[nextC]==10 || raw[nextC]==32 || raw[nextC]==9)
                                nextC++;

                            //allow for null object
                            if(raw[nextC]=='n' && raw[nextC+1]=='u' && raw[nextC+2]=='l' && raw[nextC+3]=='l'){
                                i=nextC+4;
                                break;
                            }

                            if(raw[i]!='<' && raw[i+1]!='<')
                                end=end+2;

                            boolean inDictionary=true;
                            boolean isKey=raw[end-1]=='/';

                            while(inDictionary){

                                //System.out.println(end+" "+raw.length+" "+(char)raw[end]+" "+isKey);


                                if(raw[end]=='<'&& raw[end+1]=='<'){
                                    int level2=1;
                                    end++;
                                    while(level2>0){

                                        if(raw[end]=='<'&& raw[end+1]=='<'){
                                            level2++;
                                            end=end+2;
                                        }else if(raw[end-1]=='>'&& raw[end]=='>'){
                                            level2--;
                                            if(level2>0)
                                                end=end+2;
                                        }else
                                            end++;
                                    }

                                    inDictionary=false;

                                }else if(raw[end]=='R' ){
                                    inDictionary=false;
                                }else if(isKey && (raw[end]==' ' || raw[end]==13 || raw[end]==10 || raw[end]==9)){
                                    inDictionary=false;
                                }else if(raw[end]=='/'){
                                    inDictionary=false;
                                    end--;
                                }else if(raw[end]=='>' && raw[end+1]=='>'){
                                    inDictionary=false;
                                    end--;
                                }else
                                    end++;
                            }

                            //boolean save=debugFastCode;
                            i = readDictionary(pdfObject, objRef, i, raw, isInlineImage,PDFkeyInt, ignoreRecursion);

                            //use correct value
                            i=end;

                            break;
                        }
                    }
                }
            }

            i++;

        }
        return i;
    }

    private static int setStringConstantValue(PdfObject pdfObject, int i, byte[] raw, int PDFkeyInt) {
        int keyStart;
        int keyLength;
        i++;

        //move cursor to start of text
        while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47)
            i++;

        keyStart=i;
        keyLength=0;

        //move cursor to end of text
        while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){
            i++;
            keyLength++;
        }

        i--;// move back so loop works

        //store value
        int constant=pdfObject.setConstant(PDFkeyInt,keyStart,keyLength,raw);

        if(debugFastCode)
            System.out.println(padding +"Set constant in "+pdfObject+" to "+constant);

        return i;
    }

    private static int setBooleanValue(PdfObject pdfObject, int i, byte[] raw, Object PDFkey, int PDFkeyInt) {
        int keyStart;
        int keyLength;
        i++;

        //move cursor to start of text
        while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47){
            //System.out.println("skip="+raw[i]);
            i++;
        }

        keyStart=i;
        keyLength=0;

        //move cursor to end of text
        while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){
            //System.out.println("key="+raw[i]+" "+(char)raw[i]);
            i++;
            keyLength++;
        }

        i--;// move back so loop works

        //store value
        if(raw[keyStart]=='t' && raw[keyStart+1]=='r' && raw[keyStart+2]=='u' && raw[keyStart+3]=='e') {
            pdfObject.setBoolean(PDFkeyInt,true);

            if(debugFastCode)
                System.out.println(padding +"Set Boolean true "+PDFkey+" in "+pdfObject);

        }else if(raw[keyStart]=='f' && raw[keyStart+1]=='a' && raw[keyStart+2]=='l' && raw[keyStart+3]=='s' && raw[keyStart+4]=='e'){
            pdfObject.setBoolean(PDFkeyInt,false);

            if(debugFastCode)
                System.out.println(padding +"Set Boolean false "+PDFkey+" in "+pdfObject);

        }else
            throw new RuntimeException("Unexpected value for Boolean value for"+PDFkeyInt+"="+PDFkey);
        return i;
    }

    private int setTextStreamValue(PdfObject pdfObject, String objRef, int i, byte[] raw, int PDFkeyInt, boolean ignoreRecursion) {

        if(raw[i+1]==40 && raw[i+2]==41){ //allow for empty stream
            i=i+3;
            pdfObject.setTextStreamValue(PDFkeyInt, new byte[1]);

            if(raw[i]=='/')
                i--;
        }else
            i = readTextStream(pdfObject, objRef, i, raw, PDFkeyInt,ignoreRecursion);
        return i;
    }

    private void setFieldNames(PdfObject pdfObject) {

        String fieldName =pdfObject.getTextStreamValue(PdfDictionary.T);

        if(fieldName!=null ){

            //at this point newString is the raw byte value (99% of the time this is the
            //string but it can be encode in some other ways (like a set of hex values)
            //so we need to use PdfReader.getTextString(newString, false) rather than new String(newString)
            //6 0 obj <</T <FEFF0066006F0072006D0031005B0030005D>
            //
            //Most of the time you can forget about this because getTextStream() handles it for you
            //
            //Except here where we are manipulating the bytes directly...
            String parent = pdfObject.getStringKey(PdfDictionary.Parent);

            // if no name, or parent has one recursively scan tree for one in Parent
            boolean isMultiple=false;

            while (parent != null) {

                FormObject parentObj =new FormObject(parent,false);
                readObject(parentObj);

                String newName = parentObj.getTextStreamValue(PdfDictionary.T);
                if (fieldName == null && newName != null)
                    fieldName = newName;
                else if (newName != null){
                    //we pass in kids data so stop name.name
                    if(!fieldName.equals(newName)) {
                        fieldName = newName + "." + fieldName;
                        isMultiple=true;
                    }
                }
                if (newName == null)
                    break;

                parent = parentObj.getParentRef();
            }

            //set the field name to be the Fully Qualified Name
            if(isMultiple)
                pdfObject.setTextStreamValue(PdfDictionary.T,fieldName.getBytes());
        }
    }

    private void readStreamData(PdfObject pdfObject, int i, byte[] raw, int length) {

        for(int xx=i;xx<length-5;xx++){

            //avoid reading on subobject ie <<  /DecodeParams << >> >>
            if(raw[xx]=='>' && raw[xx+1]=='>')
                break;

            if(raw[xx] == 's' && raw[xx + 1] == 't' && raw[xx + 2] == 'r' &&
                    raw[xx + 3] == 'e' && raw[xx + 4] == 'a' &&
                    raw[xx + 5] == 'm'){

                if(debugFastCode)
                    System.out.println(padding +"1. Stream found afterwards");

                if(!pdfObject.isCached())
                    readStreamIntoObject(pdfObject, xx, raw, pdfObject, padding);

                xx=length;
            }
        }
    }

    private static int getPairedValues(PdfObject pdfObject, int i, byte[] raw, int pdfKeyType, int length, int keyLength, int keyStart) {

        boolean isPair=false;

        int jj=i;

        while(jj<length){

            //ignore any spaces
            while(jj<length && (raw[jj]==32 || raw[jj]==10 || raw[jj]==13 || raw[jj]==10))
                jj++;

            //number (possibly reference)
            if(jj<length && raw[jj]>='0' && raw[jj]<='9'){

                //rest of ref
                while(jj<length && raw[jj]>='0' && raw[jj]<='9')
                    jj++;

                //ignore any spaces
                while(jj<length && (raw[jj]==32 || raw[jj]==10 || raw[jj]==13 || raw[jj]==10))
                    jj++;

                //generation and spaces
                while(jj<length && ((raw[jj]>='0' && raw[jj]<='9')||(raw[jj]==32 || raw[jj]==10 || raw[jj]==13 || raw[jj]==10)))
                    jj++;

                //not a ref
                if(jj>=length || raw[jj]!='R')
                    break;

                //roll past R
                jj++;
            }

            //ignore any spaces
            while(jj<length && (raw[jj]==32 || raw[jj]==10 || raw[jj]==13 || raw[jj]==10))
                jj++;

            //must be next key or end
            if(raw[jj]=='>' && raw[jj+1]=='>'){
                isPair=true;
                break;
            }else if(raw[jj]!='/')
                break;

            jj++;

            //ignore any spaces
            while(jj<length && (raw[jj]!=32 && raw[jj]!=10 && raw[jj]!=13 && raw[jj]!=10))
                jj++;

        }

        if(isPair){
            pdfObject.setCurrentKey(PdfDictionary.getKey(keyStart,keyLength,raw));
            return PdfDictionary.VALUE_IS_UNREAD_DICTIONARY;
        }else
            return pdfKeyType;
    }

    private static int getUnreadDictionary(PdfObject pdfObject, String objectRef, int i, byte[] raw, boolean isInlineImage, int PDFkeyInt) {

        if(raw[i]!='<')  //roll on
            i++;

        while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==9) //move cursor to start of text
            i++;

        int start=i,keyStart,keyLength;

        //create and store stub
        PdfObject valueObj= ObjectFactory.createObject(PDFkeyInt,objectRef, pdfObject.getObjectType(), pdfObject.getID());
        valueObj.setID(PDFkeyInt);

        if(raw[i]=='n' && raw[i+1]=='u' && raw[i+2]=='l' && raw[i+3]=='l'){ //allow for null
        }else
            pdfObject.setDictionary(PDFkeyInt,valueObj);

        int status=PdfObject.UNDECODED_DIRECT; //assume not object and reset below if wrong

        //some objects can have a common value (ie /ToUnicode /Identity-H
        if(raw[i]==47){ //not worth caching

            //move cursor to start of text
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                i++;

            keyStart=i;
            keyLength=0;

            //move cursor to end of text
            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){
                i++;
                keyLength++;
            }

            i--;// move back so loop works

            //store value
            int constant=valueObj.setConstant(PDFkeyInt,keyStart,keyLength,raw);

            if(constant== PdfDictionary.Unknown || isInlineImage){

                byte[] newStr=new byte[keyLength];
                System.arraycopy(raw, keyStart, newStr, 0, keyLength);

                String s=new String(newStr);
                valueObj.setGeneralStringValue(s);

            }

            status=PdfObject.DECODED;

        }else //allow for empty object
            if(raw[i]=='e' && raw[i+1]=='n' && raw[i+2]=='d' && raw[i+3]=='o' && raw[i+4]=='b' ){
            }else{ //we need to ref from ref elsewhere which may be indirect [ref], hence loop

                //roll onto first valid char
                while((raw[i]==91 && PDFkeyInt!=PdfDictionary.ColorSpace)  || raw[i]==32 || raw[i]==13 || raw[i]==10){
                    i++;
                }

                //roll on and ignore
                if(raw[i]=='<' && raw[i+1]=='<'){

                    i=i+2;
                    int reflevel=1;

                    while(reflevel>0){
                        if(raw[i]=='<' && raw[i+1]=='<'){
                            i=i+2;
                            reflevel++;
                        }else if(raw[i]=='>' && i+1==raw.length){
                            reflevel=0;
                        }else if(raw[i]=='>' && raw[i+1]=='>'){
                            i=i+2;
                            reflevel--;
                        }else
                            i++;
                    }
                }else if(raw[i]=='['){

                    i++;
                    int reflevel=1;

                    while(reflevel>0){

                        if(raw[i]=='(' ){ //allow for [[ in stream ie [/Indexed /DeviceRGB 255 (abc[[z

                            i++;
                            while(raw[i]!=')' || ObjectUtils.isEscaped(raw, i))
                                i++;

                        }else if(raw[i]=='[' ){
                            reflevel++;
                        }else if(raw[i]==']'){
                            reflevel--;
                        }

                        i++;
                    }
                    i--;
                }else if(raw[i]=='n' && raw[i+1]=='u' && raw[i+2]=='l' && raw[i+3]=='l'){ //allow for null
                    i=i+4;
                }else{ //must be a ref

                    //assume not object and reset below if wrong
                    status=PdfObject.UNDECODED_REF;

                    while(raw[i]!='R' || raw[i-1]=='e') { //second condition to stop spurious match on DeviceRGB
                        i++;

                        if(i==raw.length)
                            break;
                    }
                    i++;

                    if(i>=raw.length)
                        i=raw.length-1;
                }
            }

        valueObj.setStatus(status);
        if(status!=PdfObject.DECODED){

            int StrLength=i-start;
            byte[] unresolvedData=new byte[StrLength];
            System.arraycopy(raw, start, unresolvedData, 0, StrLength);

            //check for returns in data if ends with R and correct to space
            if(unresolvedData[StrLength-1]==82){

                for(int jj=0;jj<StrLength;jj++){

                    if(unresolvedData[jj]==10 || unresolvedData[jj]==13)
                        unresolvedData[jj]=32;

                }
            }
            valueObj.setUnresolvedData(unresolvedData,PDFkeyInt);

        }

        if(raw[i]=='/' || raw[i]=='>') //move back so loop works
            i--;
        return i;
    }

    int readDictionary(PdfObject pdfObject, String objectRef, int i,
                       byte[] raw, boolean isInlineImage,
                       int PDFkeyInt,
                       boolean ignoreRecursion) {

        int keyLength,keyStart;

        //roll on
        if(raw[i]!='<')
            i++;

        //move cursor to start of text
        while(raw[i]==10 || raw[i]==13 || raw[i]==32)
            i++;

        //some objects can have a common value (ie /ToUnicode /Identity-H
        if(raw[i]==47){

            if(debugFastCode)
                System.out.println(padding+"Indirect");

            //	System.out.println("Starts with /");

            //if it is a < (60) its a direct object, otherwise its a reference so we need to move and move back at end

            //}else if(raw[i]==60 && 1==2){

            //move cursor to start of text
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                i++;

            keyStart=i;
            keyLength=0;

            //move cursor to end of text
            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){
                i++;
                keyLength++;
            }

            i--;// move back so loop works

            if(!ignoreRecursion){

                PdfObject valueObj=ObjectFactory.createObject(PDFkeyInt,objectRef, pdfObject.getObjectType(), pdfObject.getID());
                valueObj.setID(PDFkeyInt);

                //store value
                int constant=valueObj.setConstant(PDFkeyInt,keyStart,keyLength,raw);

                if(constant==PdfDictionary.Unknown || isInlineImage){

                    byte[] newStr=new byte[keyLength];
                    System.arraycopy(raw, keyStart, newStr, 0, keyLength);

                    String s=new String(newStr);
                    valueObj.setGeneralStringValue(s);

                    if(debugFastCode)
                        System.out.println(padding+"Set Dictionary as String="+s+"  in "+pdfObject+" to "+valueObj);

                }else if(debugFastCode)
                    System.out.println(padding+"Set Dictionary as constant="+constant+"  in "+pdfObject+" to "+valueObj);


                //store value
                pdfObject.setDictionary(PDFkeyInt,valueObj);

                if(pdfObject.isDataExternal()){
                    valueObj.isDataExternal(true);
                    if(!this.resolveFully(valueObj))
                        pdfObject.setFullyResolved(false);
                }
            }

        }else //allow for empty object
            if(raw[i]=='e' && raw[i+1]=='n' && raw[i+2]=='d' && raw[i+3]=='o' && raw[i+4]=='b' ){
                //        return i;

                if(debugFastCode)
                    System.out.println(padding+"Empty object"+new String(raw)+"<<");

            }else if(raw[i]=='(' && PDFkeyInt== PdfDictionary.JS){ //ie <</S/JavaScript/JS( for JS
                i++;
                int start=i;
                //find end
                while(i<raw.length){
                    i++;
                    if(raw[i]==')' && !ObjectUtils.isEscaped(raw, i))
                        break;
                }
                byte[] data=readEscapedValue(i,raw,start, false);

                NamesObject JS=new NamesObject(objectRef);
                JS.setDecodedStream(data);
                pdfObject.setDictionary(PdfDictionary.JS, JS);

            }else{ //we need to ref from ref elsewhere which may be indirect [ref], hence loop

                if(debugFastCode)
                    System.out.println(padding+"1.About to read ref orDirect i="+i+" char="+(char)raw[i]+" ignoreRecursion="+ignoreRecursion);


                if(ignoreRecursion){

                    //roll onto first valid char
                    while(raw[i]==91 || raw[i]==32 || raw[i]==13 || raw[i]==10){

                        //if(raw[i]==91) //track incase /Mask [19 19]
                        //	possibleArrayStart=i;

                        i++;
                    }


                    //roll on and ignore
                    if(raw[i]=='<' && raw[i+1]=='<'){

                        i=i+2;
                        int reflevel=1;

                        while(reflevel>0){
                            if(raw[i]=='<' && raw[i+1]=='<'){
                                i=i+2;
                                reflevel++;
                            }else if(raw[i]=='>' && raw[i+1]=='>'){
                                i=i+2;
                                reflevel--;
                            }else
                                i++;
                        }
                        i--;

                    }else{ //must be a ref
                        //                					while(raw[i]!='R')
                        //                						i++;
                        //                					i++;
                        //System.out.println("read ref");
                        i = readDictionaryFromRefOrDirect(PDFkeyInt,pdfObject,objectRef, i, raw, PDFkeyInt);
                    }

                    if(i<raw.length && raw[i]=='/') //move back so loop works
                        i--;

                }else{
                    i = readDictionaryFromRefOrDirect(PDFkeyInt,pdfObject,objectRef, i, raw, PDFkeyInt);
                }
            }
        return i;
    }

    private int readTextStream(PdfObject pdfObject, String objectRef, int i, byte[] raw, int PDFkeyInt, boolean ignoreRecursion) {

        if(PDFkeyInt==PdfDictionary.W){

            boolean isRef=false;

            if(debugFastCode)
                System.out.println(padding+"Reading W");

            //move to start
            while(raw[i]!='[' ){ //can be number as well

                //System.out.println((char) raw[i]);
                if(raw[i]=='('){ //allow for W (7)
                    isRef=false;
                    break;
                }

                //allow for number as in refer 9 0 R
                if(raw[i]>='0' && raw[i]<='9'){
                    isRef=true;
                    break;
                }

                i++;
            }

            //allow for direct or indirect
            byte[] data=raw;

            int start=i,j=i;

            int count=0;

            //read ref data and slot in
            if(isRef){
                //number
                int keyStart2=i,keyLength2=0;
                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){

                    i++;
                    keyLength2++;

                }
                int number= NumberUtils.parseInt(keyStart2, i, raw);

                //generation
                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                    i++;

                keyStart2=i;
                //move cursor to end of reference
                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                    i++;
                int generation= NumberUtils.parseInt(keyStart2, i, raw);

                //move cursor to start of R
                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                    i++;

                if(raw[i]!=82) //we are expecting R to end ref
                    throw new RuntimeException("3. Unexpected value in file "+raw[i]+" - please send to IDRsolutions for analysis");

                if(!ignoreRecursion){

                    //read the Dictionary data
                    data=readObjectAsByteArray(pdfObject, objectRef, objectReader.isCompressed(number, generation),number,generation);

                    //allow for data in Linear object not yet loaded
                    if(data==null){
                        pdfObject.setFullyResolved(false);

                        if(debugFastCode)
                            System.out.println(padding+"Data not yet loaded");

                        LogWriter.writeLog("[Linearized] "+objectRef+" not yet available (6)");

                        return raw.length;
                    }

                    //lose obj at start
                    j=3;
                    while(data[j-1]!=106 && data[j-2]!=98 && data[j-3]!=111){
                        j++;

                        //catch for error
                        if(j==data.length){
                            j=0;
                            break;
                        }
                    }

                    //skip any spaces after
                    while(data[j]==10 || data[j]==13 || data[j]==32)// || data[j]==47 || data[j]==60)
                        j++;

                    //reset pointer
                    start=j;

                }
            }

            //move to end
            while(j<data.length){

                if(data[j]=='[' || data[j]=='(')
                    count++;
                else if(data[j]==']' || data[j]==')')
                    count--;

                if(count==0)
                    break;

                j++;
            }

            if(!ignoreRecursion){
                int stringLength=j-start+1;
                byte[] newString=new byte[stringLength];

                System.arraycopy(data, start, newString, 0, stringLength);

                /**
                 * clean up so matches old string so old code works
                 */
                if(PDFkeyInt!=PdfDictionary.JS){ //keep returns in code
                    for(int aa=0;aa<stringLength;aa++){
                        if(newString[aa]==10 || newString[aa]==13)
                            newString[aa]=32;
                    }
                }

                pdfObject.setTextStreamValue(PDFkeyInt, newString);

                if(debugFastCode)
                    System.out.println(padding+"W="+new String(newString)+" set in "+pdfObject);
            }

            //roll on
            if(!isRef)
                i=j;
        }else{

            byte[] data=null;
            try{
                if(raw[i]!='<' && raw[i]!='(')
                    i++;

                while(raw[i]==10 || raw[i]==13 || raw[i]==32)
                    i++;

                //allow for no actual value but another key
                if(raw[i]==47){
                    pdfObject.setTextStreamValue(PDFkeyInt, new byte[1]);
                    i--;
                    return i;
                }

                if(debugFastCode){
                    System.out.println(padding+"i="+i+" Reading Text from String="+new String(raw)+"<");

                    System.out.println("-->>");
                    for(int zz=i;zz<raw.length;zz++){
                        System.out.print((char)raw[zz]);
                    }
                    System.out.println("<<--");
                }

                //System.out.println("raw["+i+"]="+(char)raw[i]);
                //get next key to see if indirect
                boolean isRef=raw[i]!='<' && raw[i]!='(';

                int j=i;
                data=raw;
                if(isRef){

                    //number
                    int keyStart2=i,keyLength2=0;
                    while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){

                        i++;
                        keyLength2++;
                    }

                    int number= NumberUtils.parseInt(keyStart2, i, raw);

                    //generation
                    while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                        i++;

                    keyStart2=i;
                    //move cursor to end of reference
                    while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                        i++;
                    int generation= NumberUtils.parseInt(keyStart2, i, raw);

                    //move cursor to start of R
                    while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                        i++;

                    if(raw[i]!=82) //we are expecting R to end ref
                        throw new RuntimeException(i+" 3. Unexpected value in file " + (char) raw[i - 2]+ (char) raw[i-1] + (char) raw[i] + (char) raw[i+1] + (char) raw[i+2]+(char)raw[i]+" - please send to IDRsolutions for analysis "+pdfObject);

                    if(!ignoreRecursion){

                        //read the Dictionary data
                        data=readObjectAsByteArray(pdfObject, objectRef, objectReader.isCompressed(number, generation),number,generation);

                        //							System.out.println("data read is>>>>>>>>>>>>>>>>>>>\n");
                        //							for(int ab=0;ab<data.length;ab++)
                        //							System.out.print((char)data[ab]);
                        //							System.out.println("\n<<<<<<<<<<<<<<<<<<<\n");


                        //allow for data in Linear object not yet loaded
                        if(data==null){
                            pdfObject.setFullyResolved(false);

                            if(debugFastCode)
                                System.out.println(padding+"Data not yet loaded");

                            LogWriter.writeLog("[Linearized] "+objectRef+" not yet available (7)");

                            return raw.length;
                        }

                        //lose obj at start
                        if(data[0]=='('){
                            j=0;
                        }else{
                            j=3;
                            while(data[j-1]!=106 && data[j-2]!=98 && data[j-3]!=111)
                                j++;

                            //skip any spaces after
                            while(data[j]==10 || data[j]==13 || data[j]==32)// || data[j]==47 || data[j]==60)
                                j++;
                        }

                    }
                }
                /////////////////
                int start=0;
                if(!isRef || !ignoreRecursion){
                    //move to start
                    while(data[j]!='(' && data[j]!='<'){
                        j++;

                    }

                    byte startChar=data[j];

                    start=j;

                    //move to end (allow for ((text in brackets))
                    int bracketCount=1;
                    while(j<data.length){
                        //System.out.println(i+"="+raw[j]+" "+(char)raw[j]);
                        j++;

                        if(startChar=='(' && (data[j]==')' || data[j]=='(') && !ObjectUtils.isEscaped(data, j)){
                            //allow for non-escaped brackets
                            if(data[j]=='(')
                                bracketCount++;
                            else if(data[j]==')')
                                bracketCount--;

                            if(bracketCount==0)
                                break;
                        }

                        if(startChar=='<' && data[j]=='>')
                            break;
                    }

                }

                if(!ignoreRecursion){

                    byte[] newString=null;

                    if(data[start]=='<'){
                        start++;

                        int byteCount=(j-start)>>1;
                        newString=new byte[byteCount];

                        int byteReached=0,topHex,bottomHex;
                        while(true){

                            if(start==j)
                                break;

                            while(data[start]==32 || data[start]==10 || data[start]==13)
                                start++;

                            topHex=data[start];

                            //convert to number
                            if(topHex>='A' && topHex<='F'){
                                topHex = topHex - 55;
                            }else if(topHex>='a' && topHex<='f'){
                                topHex = topHex - 87;
                            }else if(topHex>='0' && topHex<='9'){
                                topHex = topHex - 48;
                            }else
                                throw new RuntimeException("Unexpected number "+(char)data[start]);


                            start++;

                            while(data[start]==32 || data[start]==10 || data[start]==13)
                                start++;

                            bottomHex=data[start];

                            if(bottomHex>='A' && bottomHex<='F'){
                                bottomHex = bottomHex - 55;
                            }else if(bottomHex>='a' && bottomHex<='f'){
                                bottomHex = bottomHex - 87;
                            }else if(bottomHex>='0' && bottomHex<='9'){
                                bottomHex = bottomHex - 48;
                            }else
                                throw new RuntimeException("Unexpected number "+(char)data[start]);

                            start++;

                            //calc total
                            int finalValue=bottomHex+(topHex<<4);

                            newString[byteReached] = (byte)finalValue;

                            byteReached++;

                        }



                    }else{
                        //roll past (
                        if(data[start]=='(')
                            start++;

                        newString = readEscapedValue(j,data, start,PDFkeyInt==PdfDictionary.ID);
                    }

                    if(pdfObject.getObjectType()!=PdfDictionary.Encrypt){// && pdfObject.getObjectType()!=PdfDictionary.Outlines){

                        try {
                            if(decryption!=null && !pdfObject.isInCompressedStream())
                                newString=decryption.decryptString(newString, objectRef);
                        } catch (PdfSecurityException e) {
                            e.printStackTrace();
                        }
                    }

                    pdfObject.setTextStreamValue(PDFkeyInt, newString);

                    if(debugFastCode)
                        System.out.println(padding + "TextStream=" + new String(newString)+" in pdfObject="+pdfObject);
                }

                if(!isRef)
                    i=j;

            }catch(Exception ee){
                ee.printStackTrace();
            }
        }
        return i;
    }

    private static byte[] readEscapedValue(int j, byte[] data, int start, boolean keepReturns) {
        byte[] newString;
        //see if escape values
        boolean escapedValues=false;
        for(int aa=start;aa<j;aa++){

            if(data[aa]=='\\' || data[aa]==10 || data[aa]==13){ //convert escaped chars
                escapedValues=true;
                aa=j;
            }
        }

        if(!escapedValues){ //no escapes so fastest copy
            int stringLength=j-start;

            if(stringLength<1)
                return new byte[0];

            newString=new byte[stringLength];

            System.arraycopy(data, start, newString, 0, stringLength);
        }else{ //translate escaped chars on copy

            int jj=0, stringLength=j-start; //max length
            newString=new byte[stringLength];

            for(int aa=start;aa<j;aa++){

                if(data[aa]=='\\'){ //convert escaped chars

                    aa++;
                    byte nextByte=data[aa];
                    if(nextByte=='b')
                        newString[jj]='\b';
                    else if(nextByte=='n')
                        newString[jj]='\n';
                    else if(nextByte=='t')
                        newString[jj]='\t';
                    else if(nextByte=='r')
                        newString[jj]='\r';
                    else if(nextByte=='f')
                        newString[jj]='\f';
                    else if(nextByte=='\\')
                        newString[jj]='\\';

                    else if(nextByte>47 && nextByte<58){ //octal

                        StringBuffer octal=new StringBuffer(3);

                        boolean notOctal=false;
                        for(int ii=0;ii<3;ii++){

                            if(data[aa]=='\\' || data[aa]==')' || data[aa]<'0' || data[aa]>'9') //allow for less than 3 values
                                ii=3;
                            else{
                                octal.append((char)data[aa]);

                                //catch for odd values
                                if(data[aa]>'7')
                                    notOctal=true;

                                aa++;
                            }
                        }
                        //move back 1
                        aa--;
                        //isOctal=true;
                        if(notOctal)
                            newString[jj]=(byte) Integer.parseInt(octal.toString());
                        else
                            newString[jj]=(byte) Integer.parseInt(octal.toString(),8);

                    }else if(nextByte==13 || nextByte==10){ //ignore bum data
                        jj--;
                    }else
                        newString[jj]=nextByte;

                    jj++;
                }else if(!keepReturns && (data[aa]==13 || data[aa]==10)){ //convert returns to spaces
                    newString[jj]=32;
                    jj++;
                }else{
                    newString[jj]=data[aa];
                    jj++;
                }
            }

            //now resize
            byte[] rawString=newString;
            newString=new byte[jj];

            System.arraycopy(rawString, 0, newString, 0, jj);
        }
        return newString;
    }

    private int readNumber(PdfObject pdfObject, String objectRef, int i, byte[] raw, int PDFkeyInt, Object PDFkey) {

        int keyStart=i,rawLength=raw.length;

        //move cursor to end of text
        while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62 && raw[i]!='(' && raw[i]!='.'){
            i++;
        }

        //actual value or first part of ref
        int number= NumberUtils.parseInt(keyStart, i, raw);


        //roll onto next nonspace char and see if number
        int jj=i;
        while(jj<rawLength &&(raw[jj]==32 || raw[jj]==13 || raw[jj]==10))
            jj++;

        boolean  isRef=false;

        //check its not a ref (assumes it XX 0 R)
        if(raw[jj]>= 48 && raw[jj]<=57){ //if next char is number 0-9 it may be a ref

            int aa=jj;

            //move cursor to end of number
            while((raw[aa]!=10 && raw[aa]!=13 && raw[aa]!=32 && raw[aa]!=47 && raw[aa]!=60 && raw[aa]!=62))
                aa++;

            //move cursor to start of text
            while(aa<rawLength && (raw[aa]==10 || raw[aa]==13 || raw[aa]==32 || raw[aa]==47))
                aa++;

            isRef=aa<rawLength && raw[aa]=='R';

        }

        if(isRef){
            //move cursor to start of generation
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                i++;

            /**
             * get generation number
             */
            keyStart=i;
            //move cursor to end of reference
            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                i++;

            int generation= NumberUtils.parseInt(keyStart, i, raw);

            //move cursor to start of R
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                i++;

            if(raw[i]!=82){ //we are expecting R to end ref
                throw new RuntimeException("3. Unexpected value in file - please send to IDRsolutions for analysis");
            }

            //read the Dictionary data
            byte[] data=readObjectAsByteArray(pdfObject, objectRef, objectReader.isCompressed(number, generation),number,generation);

            //allow for data in Linear object not yet loaded
            if(data==null){
                pdfObject.setFullyResolved(false);

                if(debugFastCode)
                    System.out.println(padding+"Data not yet loaded");

                LogWriter.writeLog("[Linearized] "+objectRef+" not yet available (8)");

                return rawLength;
            }

            //lose obj at start
            int j=0,len=data.length;

            //allow for example where start <<
            if(len>1 && data[0]=='<' && data[1]=='<'){
            }else{
                j=3;
                if(len>3){ //allow for small values (ie Rotate object pointing to value 0)
                    while(data[j-1]!=106 && data[j-2]!=98 && data[j-3]!=111){
                        j++;

                        if(j==len){
                            j=0;
                            break;
                        }
                    }
                }
            }

            //skip any spaces after
            if(len>1){//allow for small values (ie Rotate object pointing to value 0)
                while(data[j]==9 || data[j]==10 || data[j]==13 || data[j]==32)// || data[j]==47 || data[j]==60)
                    j++;
            }

            int count=j;

            //skip any spaces at end
            while(count<len && data[count]!=9 && data[count]!=10 && data[count]!=13 && data[count]!=32)// || data[j]==47 || data[j]==60)
                count++;

            number= NumberUtils.parseInt(j, count, data);

        }

        //store value
        pdfObject.setIntNumber(PDFkeyInt,number);

        if(debugFastCode)
            System.out.println(padding+"set key="+PDFkey+" numberValue="+number);//+" in "+pdfObject);

        i--;// move back so loop works

        return i;
    }


    private int handleColorSpaces(PdfObject pdfObject,int i, byte[] raw) {

        final boolean debugColorspace=false;//pdfObject.getObjectRefAsString().equals("194 0 R");//pdfObject.getDebugMode();// || debugFastCode;

        if(debugColorspace){

            System.out.println(padding+"Reading colorspace into "+pdfObject+" ref="+pdfObject.getObjectRefAsString()+" i="+i+" chars="+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]+(char)raw[i+4]);

            System.out.println(padding+"------------>");
            for(int ii=i;ii<raw.length;ii++){
                System.out.print((char)raw[ii]);

                if(ii>5 && raw[ii-5]=='s' && raw[ii-4]=='t' && raw[ii-3]=='r' && raw[ii-2]=='e' && raw[ii-1]=='a' &&raw[ii]=='m')
                    ii=raw.length;
            }

            System.out.println("<--------");

        }

        //ignore any spaces
        while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]=='['){

            //glag a sindirect as encryption will need to use this level for key
            if(raw[i]=='[')
                pdfObject.maybeIndirect(true);

            i++;
        }

        if(raw[i]=='/'){

            /**
             * read the first value which is ID
             **/

            i++;

            //move cursor to start of text
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47){
                //System.out.println("skip="+raw[i]);
                i++;
            }

            int keyStart=i;
            int keyLength=0;

            //System.out.println("firstChar="+raw[i]+" "+(char)raw[i]);

            if(debugColorspace)
                System.out.print(padding+"Colorspace is /");

            //move cursor to end of text
            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62 && raw[i]!='[' && raw[i]!=']'){

                if(debugColorspace)
                    System.out.print((char)raw[i]);

                i++;
                keyLength++;

                if(i==raw.length)
                    break;
            }

            if(debugColorspace)
                System.out.println("");


            i--;// move back so loop works

            //store value
            int constant=pdfObject.setConstant(PdfDictionary.ColorSpace,keyStart,keyLength,raw);

            //allow for abreviation in ID command
            if(constant==PdfDictionary.I)
                constant=ColorSpaces.Indexed;

            if(debugColorspace)
                System.out.println(padding+"set ID="+constant+" in "+pdfObject);

            i++;//roll on

            switch(constant){

                case ColorSpaces.CalRGB:{

                    if(debugColorspace)
                        System.out.println(padding+"CalRGB Colorspace");

                    i=handleColorSpaces(pdfObject, i,  raw);

                    i++;

                    break;
                }case ColorSpaces.CalGray:{

                    if(debugColorspace)
                        System.out.println(padding+"CalGray Colorspace");

                    i=handleColorSpaces(pdfObject, i,  raw);

                    i++;

                    break;
                }case ColorSpaces.DeviceCMYK:{

                    if(debugColorspace)
                        System.out.println(padding+"DeviceGray Colorspace");

                    break;
                }case ColorSpaces.DeviceGray:{

                    if(debugColorspace)
                        System.out.println(padding+"DeviceGray Colorspace");

                    break;
                }case ColorSpaces.DeviceN:{

                    if(debugColorspace)
                        System.out.println(padding+"DeviceN Colorspace >>"+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]);

                    int endPoint=i;
                    while(endPoint<raw.length && raw[endPoint]!=']'){
                        //System.out.println(endPoint+" "+(char)raw[endPoint]+" "+raw[endPoint]);
                        endPoint++;
                    }

                    //read Components
                    i=readArray(false,i, endPoint, PdfDictionary.VALUE_IS_STRING_ARRAY, raw, "", pdfObject, PdfDictionary.Components, null, -1);

                    if(debugColorspace)
                        System.out.println("i="+i+" "+(char)raw[i]+" "+raw[i]);

                    while(raw[i]==93 || raw[i]==32 || raw[i]==10 || raw[i]==13)
                        i++;

                    if(debugColorspace)
                        System.out.println(padding+"i="+i+" DeviceN Reading altColorspace >>"+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]+(char)raw[i+4]+(char)raw[i+5]+(char)raw[i+6]+(char)raw[i+7]+(char)raw[i+8]);

                    if(debugColorspace)
                        System.out.println(padding+"before alt colorspace >>"+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]);

                    if(debugColorspace)
                        System.out.println("i="+i+"  >>"+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]+(char)raw[i+4]+(char)raw[i+5]+(char)raw[i+6]+(char)raw[i+7]);

                    //read the alt colorspace
                    PdfObject altColorSpace=new ColorSpaceObject(-1,0);
                    i=handleColorSpaces(altColorSpace, i,  raw);
                    pdfObject.setDictionary(PdfDictionary.AlternateSpace,altColorSpace);

                    if(debugColorspace){
                        System.out.println("i="+i+" Alt colorspace="+altColorSpace+" "+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]+(char)raw[i+4]);

                    }

                    i++;

                    if(debugColorspace)
                        System.out.println(padding+"DeviceN Reading tintTransform >>"+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]);

                    //read the transform
                    PdfObject tintTransform=new FunctionObject(-1,0);

                    i=handleColorSpaces(tintTransform, i,  raw);
                    pdfObject.setDictionary(PdfDictionary.tintTransform,tintTransform);

                    //check for attributes
                    for(int ii=i;ii<raw.length;ii++){

                        // System.out.println((char)raw[ii]+""+(char)raw[ii+1]+""+(char)raw[ii+2]+""+(char)raw[ii+3]);

                        if(raw[ii]==']'){
                            ii=raw.length;
                            break;
                        }else if(raw[ii]==32 || raw[ii]==10 || raw[ii]==13){//ignore spaces
                        }else{

                            i=ii;
                            //read the attributes
                            PdfObject attributesObj=new ColorSpaceObject(-1,0);
                            i=handleColorSpaces(attributesObj, i,  raw);
                            pdfObject.setDictionary(PdfDictionary.Process,attributesObj);
                            //i--;

                            return i;

                        }
                    }
                    if(debugColorspace)
                        System.out.println("i="+i+"  >>"+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]+(char)raw[i+4]+(char)raw[i+5]+(char)raw[i+6]+(char)raw[i+7]);

                    i++;

                    break;
                }case ColorSpaces.DeviceRGB:{

                    if(debugColorspace)
                        System.out.println(padding+"DeviceRGB Colorspace");

                    break;
                }case ColorSpaces.ICC:{

                    if(debugColorspace)
                        System.out.println(padding+"ICC Colorspace");

                    //get the colorspace data
                    i=readDictionaryFromRefOrDirect(-1, pdfObject,"", i, raw, PdfDictionary.ColorSpace);

                    break;

                }case ColorSpaces.Indexed:{

                    if(debugColorspace){
                        System.out.println(new String(raw));
                        System.out.println(padding+ "Indexed Colorspace - Reading base >>" + (char) raw[i] + (char) raw[i + 1]+(char)+raw[i+2]+"<< i="+i+" into "+pdfObject);
                    }
                    //read the base value
                    PdfObject IndexedColorSpace=new ColorSpaceObject(-1,0,true);

                    //IndexedColorSpace.setRef(pdfObject.getObjectRefAsString());
                    i=handleColorSpaces(IndexedColorSpace, i,  raw);
                    pdfObject.setDictionary(PdfDictionary.Indexed,IndexedColorSpace);


                    //onto hival number
                    while(i<raw.length && (raw[i]==32 || raw[i]==13 || raw[i]==10 || raw[i]==']' || raw[i]=='>'))
                        i++;

                    if(debugColorspace)
                        System.out.println(padding + "Indexed Reading hival starting at >>" + (char) raw[i] + (char) raw[i + 1]+(char)+raw[i+2]+"<<i="+i);

                    //roll on
                    //i++;

                    //move cursor to start of text
                    //while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47)
                    //    i++;

                    //hival
                    i = readNumber(pdfObject, "", i, raw, PdfDictionary.hival, "hival");

                    if(debugColorspace)
                        System.out.println("hival="+pdfObject.getInt(PdfDictionary.hival)+" i="+i+" raw[i]="+(char)raw[i]);

                    if(raw[i]!='(')
                        i++;

                    if(debugColorspace)
                        System.out.println(padding + "next chars >>" + (char) raw[i] + (char) raw[i + 1]+(char)+raw[i+2]+"<<i="+i);


                    //onto lookup
                    while(i<raw.length && (raw[i]==32 || raw[i]==13 || raw[i]==10))
                        i++;

                    if(debugColorspace)
                        System.out.println(padding+"Indexed Reading lookup "+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+(char)raw[i+3]+(char)raw[i+4]);

                    //read lookup
                    //get the colorspace data (base)

                    PdfObject IndexedColorSpaceData=null;

                    //can be embedded in this object (when we need to use ref or in separate object
                    //when we need to use that ref). This code switches as needed)
                    boolean needsKey=raw[i]=='[' || raw[i]=='(' || raw[i]=='<';
                    if(needsKey)
                        IndexedColorSpaceData=new ColorSpaceObject(pdfObject.getObjectRefAsString());
                    else
                        IndexedColorSpaceData=new ColorSpaceObject(-1,0);

                    //IndexedColorSpace.setRef(pdfObject.getObjectRefAsString());
                    pdfObject.setDictionary(PdfDictionary.Lookup,IndexedColorSpaceData);

                    i=handleColorSpaces(IndexedColorSpaceData, i,  raw);

                    //if(debugColorspace)
                    //System.out.println(paddingString + "after stream>>" + (char) raw[i] + (char) raw[i + 1]+(char)+raw[i+2]+"<<i="+i);

                    i++;

                    break;

                }case ColorSpaces.Lab:{

                    if(debugColorspace)
                        System.out.println(padding+"Lab Colorspace");

                    i=handleColorSpaces(pdfObject, i,  raw);

                    i++;

                    break;

                }case ColorSpaces.Pattern:{

                    if(debugColorspace)
                        System.out.println(padding+"Pattern Colorspace");

                    break;
                }case ColorSpaces.Separation:{

                    if(debugColorspace)
                        System.out.println(padding+"Separation Colorspace");

                    int endPoint=i;

                    //roll on to start
                    while(raw[endPoint]=='/' || raw[endPoint]==32 ||raw[endPoint]==10 ||raw[endPoint]==13)
                        endPoint++;

                    int startPt=endPoint;

                    //get name length
                    while(endPoint<raw.length){
                        if(raw[endPoint]=='/' || raw[endPoint]==' ' || raw[endPoint]==13 || raw[endPoint]==10)
                            break;

                        endPoint++;
                    }

                    //read name
                    //set value
                    keyLength=endPoint-startPt;
                    byte[] stringBytes=new byte[keyLength];
                    System.arraycopy(raw,startPt,stringBytes,0,keyLength);

                    //store value
                    pdfObject.setName(PdfDictionary.Name,stringBytes);

                    if(debugColorspace)
                        System.out.println(padding+"name="+new String(stringBytes)+" "+pdfObject);

                    i=endPoint;

                    if(raw[i]!=47)
                        i++;

                    if(debugColorspace)
                        System.out.println(padding+"Separation Reading altColorspace >>"+(char)raw[i]+(char)raw[i+1]);

                    //read the alt colorspace
                    PdfObject altColorSpace=new ColorSpaceObject(-1,0);
                    i=handleColorSpaces(altColorSpace, i,  raw);
                    pdfObject.setDictionary(PdfDictionary.AlternateSpace,altColorSpace);

                    //allow for no gap
                    if(raw[i]!='<')
                        i++;

                    //read the transform
                    PdfObject tintTransform=new FunctionObject(-1,0);

                    if(debugColorspace)
                        System.out.println(padding + "Separation Reading tintTransform " + (char) raw[i - 1] + (char) raw[i]+(char)raw[i+1]+" into "+tintTransform);

                    i=handleColorSpaces(tintTransform, i,  raw);
                    pdfObject.setDictionary(PdfDictionary.tintTransform,tintTransform);

                    i++;

                    break;
                }

            }

        }else if(raw[i]=='<' && raw[i+1]=='<'){

            if(debugColorspace)
                System.out.println(padding+ "Direct object starting " + (char) raw[i] + (char) raw[i + 1]+(char)raw[i+2]+" ref="+pdfObject.getObjectRefAsString());

            //System.out.println("i1="+i);
            i = convertDirectDictionaryToObject(pdfObject, "", i, raw, -1);
            //i = convertDirectDictionaryToObject(pdfObject, "", i, raw, i==168, -1, paddingString);

            //System.out.println("i2="+i);
            //allow for stream
            /**
             * look for stream afterwards
             */
            if(pdfObject.hasStream()){
                int count=raw.length, ends=0;
                for(int xx=i;xx<count-5;xx++){

                    //avoid reading on subobject ie <<  /DecodeParams << >> >>
                    if(raw[xx]=='>' && raw[xx+1]=='>')
                        ends++;
                    if(ends==2){
                        if(debugColorspace)
                            System.out.println(padding+"Ignore Stream as not in sub-object "+pdfObject);

                        break;
                    }

                    if(raw[xx] == 's' && raw[xx + 1] == 't' && raw[xx + 2] == 'r' &&
                            raw[xx + 3] == 'e' && raw[xx + 4] == 'a' && raw[xx + 5] == 'm'){

                        if(debugColorspace)
                            System.out.println(padding+"2. Stream found afterwards");

                        readStreamIntoObject(pdfObject,xx, raw, pdfObject,padding);
                        xx=count;

                    }
                }
            }

        }else if(raw[i]=='%'){ //comments
            while(raw[i]!=10 && raw[i]!=13)
                i++;

            //if(debugColorspace)
            //System.out.println(paddingString+"At end="+(char)raw[i]+(char)raw[i+1]+(char)raw[i+2]+"<< i="+i);
        }else if(raw[i]=='<'){ // its array of hex values (ie <FFEE>)

            i++;
            //find end
            int end=i, validCharCount=0;

            //System.err.println("RAW stream ...");
            //for(int y=0;y<raw.length;y++){
            //	System.err.print((char)raw[y]);
            //}
            //System.err.println("\n\n");

            //here
            while(raw[end]!='>'){
                if(raw[end]!=32 && raw[end]!=10 && raw[end]!=13)
                    validCharCount++;
                end++;
            }

            int byteCount=validCharCount>>1;
            byte[] stream=new byte[byteCount];

            int byteReached=0,topHex=0,bottomHex=0;
            while(true){
                while(raw[i]==32 || raw[i]==10 || raw[i]==13)
                    i++;

                topHex=raw[i];

                //convert to number

                //System.out.println("-> raw[i]=" + (char)topHex);

                if(topHex>='A' && topHex<='F'){
                    topHex = topHex - 55;
                }else if(topHex>='a' && topHex<='f'){
                    topHex = topHex - 87;
                }else if(topHex>='0' && topHex<='9'){
                    topHex = topHex - 48;
                }else
                    throw new RuntimeException("Unexpected number "+(char)raw[i]);


                i++;

                while(raw[i]==32 || raw[i]==10 || raw[i]==13)
                    i++;

                bottomHex=raw[i];

                if(bottomHex>='A' && bottomHex<='F'){
                    bottomHex = bottomHex - 55;
                }else if(bottomHex>='a' && bottomHex<='f'){
                    bottomHex = bottomHex - 87;
                }else if(bottomHex>='0' && bottomHex<='9'){
                    bottomHex = bottomHex - 48;
                }else
                    throw new RuntimeException("Unexpected number "+(char)raw[i]);

                i++;


                //calc total
                int finalValue=bottomHex+(topHex<<4);

                stream[byteReached] = (byte)finalValue;

                byteReached++;

                //System.out.println((char)topHex+""+(char)bottomHex+" "+byteReached+"/"+byteCount);
                if(byteReached==byteCount)
                    break;
            }

            pdfObject.setDecodedStream(stream);


        }else if(raw[i]=='('){ // its array of hex values (ie (\000\0\027)

            i++; //move past (

            int start=i;

            //find end of textstream
            while(true){

                if(raw[i]==')' && (!ObjectUtils.isEscaped(raw, i)|| raw[i-1]==0))
                    break;

                i++;
            }

            //i++;

            byte[] nRaw = readEscapedValue(i, raw, start, false);

            try {
                if(decryption!=null)
                    nRaw=decryption.decrypt(nRaw,pdfObject.getObjectRefAsString(), false,null, false,false,null);
            } catch (PdfSecurityException e) {
                e.printStackTrace();
            }

            pdfObject.setDecodedStream(nRaw);

        }else{ //assume its an object

            if(debugColorspace)
                System.out.println(padding+"(assume object) starts with "+raw[i]+" "+raw[i+1]+" "+pdfObject+" "+pdfObject.getObjectRefAsString());

            //number
            int keyStart2=i;//keyLength2=0;
            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){

                i++;
            }
            int number= NumberUtils.parseInt(keyStart2, i, raw);

            if(debugColorspace)
                System.out.println(">>number="+number+" "+new String(raw,keyStart2,i-keyStart2));

            //generation
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                i++;

            keyStart2=i;
            //move cursor to end of reference
            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                i++;

            int generation= NumberUtils.parseInt(keyStart2, i, raw);

            //move cursor to start of R
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                i++;

            if(debugColorspace){
                System.out.println(padding+">>"+number+" "+generation+" "+pdfObject.getObjectRefAsString());
                //System.out.println("raw="+new String(raw));
            }

            if(raw[i]!=82){ //we are expecting R to end ref
                throw new RuntimeException("3. Unexpected value in file "+(char)raw[i]+" - please send to IDRsolutions for analysis");
            }

            i++;

            if(debugColorspace){
                System.out.println(pdfObject.getObjectRefAsString());
            }

            if(debugColorspace)
                System.out.println(padding+"Before setRef="+number+" "+generation+" R pdfObject.getObjectRefAsString()="+pdfObject.getObjectRefAsString()+" "+pdfObject);

            if(pdfObject.getObjectRefID()==-1 || pdfObject.maybeIndirect())
                pdfObject.setRef(number,generation);

            if(debugColorspace)
                System.out.println(padding+"After setRef="+number+" "+generation+" R pdfObject.getObjectRefAsString()="+pdfObject.getObjectRefAsString());

            //read the Dictionary data
            byte[] data=readObjectAsByteArray(pdfObject, "1", objectReader.isCompressed(number, generation),number,generation);

            //allow for data in Linear object not yet loaded
            if(data==null){
                pdfObject.setFullyResolved(false);

                if(debugFastCode)
                    System.out.println(padding+"Data not yet loaded");

                LogWriter.writeLog("[Linearized] "+number+" "+generation+" R not yet available (9)");

                return raw.length;
            }

            //allow for direct (ie /DeviceCMYK)
            if(data[0]=='/'){

                handleColorSpaces(pdfObject,0, data);
            }else{

                int j=0;
                if(data[0]!='[' && data[0]!='<'){
                    //lose obj at start
                    j=3;
                    while(data[j-1]!=106 && data[j-2]!=98 && data[j-3]!=111){
                        j++;
                    }
                }

                if(debugColorspace)
                    System.out.println("Read obj i=" + i + " j=" + j + " " + (char) data[j]+(char)data[j+1]);

                handleColorSpaces(pdfObject,j,  data);
            }
        }

        //if(debugColorspace)
        //System.out.println(paddingString+"return i="+i+" >>"+(char)raw[i]+""+(char)raw[i+1]+""+(char)raw[i+2]);

        //roll back if no gap
        if(i<raw.length && (raw[i]==47 || raw[i]=='>'))
            i--;

        return i;
    }

    /**
     * @param id
     * @param pdfObject
     * @param objectRef
     * @param i
     * @param raw
     * @param PDFkeyInt     - -1 will store in pdfObject directly, not as separate object
     * @return
     */
    private int readDictionaryFromRefOrDirect(int id, PdfObject pdfObject, String objectRef, int i, byte[] raw, int PDFkeyInt) {

        int keyStart;
        int possibleArrayStart = -1;

        //@speed - find end so we can ignore once no longer reading into map as well
        //and skip to end of object
        //allow for [ref] or [<< >>] at top level (may be followed by gap)
        //good example is /PDFdata/baseline_screens/docusign/test3 _ Residential Purchase and Sale Agreement - 6-03.pdf
        while (raw[i] == 91 || raw[i] == 32 || raw[i] == 13 || raw[i] == 10) {

            if (raw[i] == 91) //track incase /Mask [19 19]
                possibleArrayStart = i;

            i++;
        }

        //some items like MAsk can be [19 19] or stream
        //and colorspace is law unto itself
        if (PDFkeyInt == PdfDictionary.ColorSpace || id == PdfDictionary.ColorSpace || pdfObject.getPDFkeyInt()==PdfDictionary.ColorSpace)

            return processColorSpace(pdfObject, objectRef, i, raw);
        else if (possibleArrayStart != -1 && (PDFkeyInt == PdfDictionary.Mask || PDFkeyInt == PdfDictionary.TR || PDFkeyInt == PdfDictionary.OpenAction))
            return processArray(pdfObject, objectRef, raw, PDFkeyInt, possibleArrayStart);

        if (raw[i] == '%') { // if %comment roll onto next line
            while (raw[i] != 13 && raw[i] != 10)
                i++;

            //and lose space after
            while (raw[i] == 91 || raw[i] == 32 || raw[i] == 13 || raw[i] == 10)
                i++;
        }

        if (raw[i] == 60) { //[<<data inside brackets>>]

            i = convertDirectDictionaryToObject(pdfObject, objectRef, i, raw, PDFkeyInt);

        } else if (raw[i] == 47) { //direct value such as /DeviceGray

            i = ObjectUtils.setDirectValue(pdfObject, i, raw, PDFkeyInt);

        } else { // ref or [ref]

            int j = i, ref, generation;
            byte[] data = raw;

            while (true) {

                //allow for [ref] at top level (may be followed by gap
                while (data[j] == 91 || data[j] == 32 || data[j] == 13 || data[j] == 10)
                    j++;

                // trap nulls  as well
                boolean hasNull = false;

                while (true) {

                    //trap null arrays ie [null null]
                    if (hasNull && data[j] == ']')
                        return j;

                    /**
                     * get object ref
                     */
                    keyStart = j;
                    //move cursor to end of reference
                    while (data[j] != 10 && data[j] != 13 && data[j] != 32 && data[j] != 47 && data[j] != 60 && data[j] != 62) {

                        //trap null arrays ie [null null] or [null]

                        if(data[j]=='l' && data[j-1]=='l' && data[j-2]=='u' && data[j-3]=='n')
                            hasNull=true;

                        if (hasNull && data[j] == ']' )
                            return j;

                        j++;
                    }

                    ref = NumberUtils.parseInt(keyStart, j, data);

                    //move cursor to start of generation or next value
                    while (data[j] == 10 || data[j] == 13 || data[j] == 32)// || data[j]==47 || data[j]==60)
                        j++;

                    //handle nulls
                    if (ref != 69560 || data[keyStart]!='n')
                        break; //not null
                    else {
                        hasNull = true;
                        if (data[j] == '<'){ // /DecodeParms [ null << /K -1 /Columns 1778 >>  ] ignore null and jump down to enclosed Dictionary
                            return readDictionaryFromRefOrDirect(id, pdfObject, objectRef,  j, raw, PDFkeyInt);

                        }
                    }
                }

                /**
                 * get generation number
                 */
                keyStart = j;
                //move cursor to end of reference
                while (data[j] != 10 && data[j] != 13 && data[j] != 32 && data[j] != 47 && data[j] != 60 && data[j] != 62)
                    j++;

                generation = NumberUtils.parseInt(keyStart, j, data);

                /**
                 * check R at end of reference and abort if wrong
                 */
                //move cursor to start of R
                while (data[j] == 10 || data[j] == 13 || data[j] == 32 || data[j] == 47 || data[j] == 60)
                    j++;

                if (data[j] != 82)  //we are expecting R to end ref
                    throw new RuntimeException("ref=" + ref + " gen=" + ref + " 1. Unexpected value " + data[j] + " in file - please send to IDRsolutions for analysis char=" + (char) data[j]);

                //read the Dictionary data
                data = readObjectAsByteArray(pdfObject, objectRef, objectReader.isCompressed(ref, generation), ref, generation);

                //allow for data in Linear object not yet loaded
                if(data==null){
                    pdfObject.setFullyResolved(false);

                    LogWriter.writeLog("[Linearized] "+objectRef+" not yet available (11)");

                    return raw.length;
                }

                //disregard corrputed data from start of file
                if(data!=null && data.length>4 && data[0]=='%' && data[1]=='P' && data[2]=='D' && data[3]=='F')
                    data=null;

                if (data == null)
                    break;

                /**
                 * get not indirect and exit if not
                 */
                int j2 = 0;

                //allow for [91 0 r]
                if (data[j2] != '['  && data[0]!='<' && data[1]!='<') {

                    while (j2 < 3 || (j2 > 2 && data[j2 - 1] != 106 && data[j2 - 2] != 98 && data[j2 - 3] != 111)) {

                        //allow for /None as value
                        if (data[j2] == '/')
                            break;
                        j2++;
                    }

                    //skip any spaces
                    while (data[j2] != 91 && (data[j2] == 10 || data[j2] == 13 || data[j2] == 32))// || data[j]==47 || data[j]==60)
                        j2++;
                }

                //if indirect, round we go again
                if (data[j2] != 91) {
                    j = 0;
                    break;
                }

                j = j2;
            }

            //allow for no data found (ie /PDFdata/baseline_screens/debug/hp_broken_file.pdf)
            if (data != null){

                /**
                 * get id from stream
                 */
                //skip any spaces
                while (data[j] == 10 || data[j] == 13 || data[j] == 32)// || data[j]==47 || data[j]==60)
                    j++;

                boolean isMissingValue = j<raw.length && raw[j] == '<';

                if (isMissingValue) { //check not <</Last
                    //find first valid char
                    int xx = j;
                    while (xx < data.length && (raw[xx] == '<' || raw[xx] == 10 || raw[xx] == 13 || raw[xx] == 32))
                        xx++;

                    if (raw[xx] == '/')
                        isMissingValue = false;
                }

                if (isMissingValue) { //missing value at start for some reason

                    /**
                     * get object ref
                     */
                    keyStart = j;
                    //move cursor to end of reference
                    while (data[j] != 10 && data[j] != 13 && data[j] != 32 && data[j] != 47 && data[j] != 60 && data[j] != 62)
                        j++;

                    ref = NumberUtils.parseInt(keyStart, j, data);

                    //move cursor to start of generation
                    while (data[j] == 10 || data[j] == 13 || data[j] == 32 || data[j] == 47 || data[j] == 60)
                        j++;

                    /**
                     * get generation number
                     */
                    keyStart = j;
                    //move cursor to end of reference
                    while (data[j] != 10 && data[j] != 13 && data[j] != 32 && data[j] != 47 && data[j] != 60 && data[j] != 62)
                        j++;

                    generation = NumberUtils.parseInt(keyStart, j, data);

                    //lose obj at start
                    while (data[j - 1] != 106 && data[j - 2] != 98 && data[j - 3] != 111) {

                        if (data[j] == '<')
                            break;

                        j++;
                    }
                }

                //skip any spaces
                while (data[j] == 10 || data[j] == 13 || data[j] == 32 || data[j] == 9)// || data[j]==47 || data[j]==60)
                    j++;

                //move to start of Dict values
                if (data[0] != 60)
                    while (data[j] != 60 && data[j + 1] != 60) {

                        //allow for null object
                        if(data[j]=='n' && data[j+1]=='u' && data[j+2]=='l' && data[j+3]=='l' )
                            return i;

                        //allow for Direct value ie 2 0 obj /WinAnsiEncoding
                        if (data[j] == 47)
                            break;

                        //allow for textStream (text)
                        if(data[j]=='('){
                            j = readTextStream(pdfObject, objectRef, j, data, PDFkeyInt, true);
                            break;
                        }

                        j++;
                    }

                i = handleValue(pdfObject, i, PDFkeyInt, j, ref, generation, data);
            }
        }

        return i;
    }

    private int processArray(PdfObject pdfObject, String objectRef, byte[] raw, int PDFkeyInt, int possibleArrayStart) {
        int i;//find end
        int endPoint = possibleArrayStart;
        while (raw[endPoint] != ']' && endPoint <= raw.length)
            endPoint++;

        //convert data to new Dictionary object and store
        PdfObject valueObj = ObjectFactory.createObject(PDFkeyInt, null, pdfObject.getObjectType(), pdfObject.getID());
        valueObj.setID(PDFkeyInt);
        pdfObject.setDictionary(PDFkeyInt, valueObj);
        valueObj.ignoreRecursion(pdfObject.ignoreRecursion());

        if(valueObj.isDataExternal()){
            valueObj.isDataExternal(true);
            if(!resolveFully(valueObj))
                pdfObject.setFullyResolved(false);
        }

        int type = PdfDictionary.VALUE_IS_INT_ARRAY;
        if (PDFkeyInt == PdfDictionary.TR)
            type = PdfDictionary.VALUE_IS_KEY_ARRAY;

        i = readArray(pdfObject.ignoreRecursion(), possibleArrayStart, endPoint, type, raw, objectRef, valueObj, PDFkeyInt,null, -1);

        //rollon
        return i;
    }

    private int processColorSpace(PdfObject pdfObject, String objectRef, int i, byte[] raw) {
        //very specific type of object

        PdfObject ColorSpace = (PdfObject) cachedColorspaces.get(objectRef);

        if(ColorSpace==null)
            ColorSpace = (PdfObject) cachedColorspaces.get(pdfObject.getObjectRefAsString());

        //read the base value (2 cases - Colorspace pairs or value in XObject
        if (ColorSpace == null && !pdfObject.ignoreRecursion()) {

            if (pdfObject.getObjectType() == PdfDictionary.ColorSpace) {//pairs

                return handleColorSpaces(pdfObject, i, raw);

            }else{ //Direct object in XObject

                //can be called in 2 diff ways and this is difference
                boolean isKey=raw[i]=='/';
                if(isKey)
                    ColorSpace = new ColorSpaceObject(objectRef);
                else
                    ColorSpace = new ColorSpaceObject(-1,0);

                pdfObject.setDictionary(PdfDictionary.ColorSpace, ColorSpace);

                if(ColorSpace.isDataExternal()){
                    ColorSpace.isDataExternal(true);
                    if(!this.resolveFully(ColorSpace))
                        pdfObject.setFullyResolved(false);
                }

                return handleColorSpaces(ColorSpace, i, raw);
            }
        } else {//roll on and ignore

            pdfObject.setDictionary(PdfDictionary.ColorSpace, ColorSpace);

            if(ColorSpace.isDataExternal()){
                ColorSpace.isDataExternal(true);
                if(!resolveFully(ColorSpace))
                    pdfObject.setFullyResolved(false);
            }

            if (raw[i] == '<' && raw[i + 1] == '<') {
                i = i + 2;
                int level = 1;

                while (level > 0) {
                    if (raw[i] == '<' && raw[i + 1] == '<') {
                        i = i + 2;
                        level++;
                    } else if (raw[i] == '>' && raw[i + 1] == '>') {
                        i = i + 2;
                        level--;
                    } else
                        i++;
                }

            } else { //must be a ref
                while (raw[i] != 'R')
                    i++;

                i++;
            }

            return i;
        }
    }

    private int handleValue(PdfObject pdfObject, int i,int PDFkeyInt, int j, int ref, int generation, byte[] data) {

        int keyStart;
        int keyLength;

        if (data[j] == 47) {
            j++; //roll on past /

            keyStart = j;
            keyLength = 0;

            //move cursor to end of text
            while (data[j] != 10 && data[j] != 13 && data[j] != 32 && data[j] != 47 && data[j] != 60 && data[j] != 62) {
                j++;
                keyLength++;

            }

            i--;// move back so loop works

            if (PDFkeyInt == -1) {
                //store value directly
                int constant = pdfObject.setConstant(PDFkeyInt, keyStart, keyLength, data);

                if (debugFastCode)
                    System.out.println(padding + "Set object Constant directly to " + constant);
            } else {
                //convert data to new Dictionary object
                PdfObject valueObj = ObjectFactory.createObject(PDFkeyInt, null,pdfObject.getObjectType(), pdfObject.getID());
                valueObj.setID(PDFkeyInt);
                //store value
                int constant = valueObj.setConstant(PDFkeyInt, keyStart, keyLength, data);
                pdfObject.setDictionary(PDFkeyInt, valueObj);

                if(pdfObject.isDataExternal()){
                    valueObj.isDataExternal(true);
                    if(!resolveFully(valueObj))
                        pdfObject.setFullyResolved(false);
                }
            }
        } else {

            //convert data to new Dictionary object
            PdfObject valueObj  ;
            if (PDFkeyInt == -1)
                valueObj = pdfObject;
            else {
                valueObj = ObjectFactory.createObject(PDFkeyInt, ref, generation, pdfObject.getObjectType());
                valueObj.setID(PDFkeyInt);
                valueObj.setInCompressedStream(pdfObject.isInCompressedStream());

                if(pdfObject.isDataExternal()){
                    valueObj.isDataExternal(true);

                    if(!resolveFully(valueObj))
                        pdfObject.setFullyResolved(false);
                }

                if (PDFkeyInt != PdfDictionary.Resources)
                    valueObj.ignoreRecursion(pdfObject.ignoreRecursion());
            }

            j = readDictionaryAsObject(valueObj, ref + " " + generation + " R", j, data, data.length, false);

            //store value
            if (PDFkeyInt != -1)
                pdfObject.setDictionary(PDFkeyInt, valueObj);
        }
        return i;
    }


    private int convertDirectDictionaryToObject(PdfObject pdfObject, String objectRef, int i, byte[] raw, int PDFkeyInt) {

        //convert data to new Dictionary object
        PdfObject valueObj ;

        if(PDFkeyInt==-1){
            valueObj=pdfObject;

            //if only 1 item use that ref not parent and indirect (ie <</Metadata 38 0 R>>)
            int objCount=0, refStarts=-1,refEnds=-1;
            if(raw[0]=='<'){
                for(int ii=0;ii<raw.length;ii++){

                    //count keys
                    if(raw[ii]=='/')
                        objCount++;
                    //find start of ref
                    if(objCount==1){
                        if(refStarts==-1){
                            if(raw[ii]>'0' && raw[ii]<'9')
                                refStarts=ii;
                        }else{
                            if(raw[ii]=='R')
                                refEnds=ii+1;
                        }
                    }
                }

                if(objCount==1 && refStarts!=-1 && refEnds!=-1){
                    objectRef=new String(raw,refStarts,refEnds-refStarts);
                    valueObj.setRef(objectRef);
                }
            }

        }else{
            valueObj= ObjectFactory.createObject(PDFkeyInt,objectRef, pdfObject.getObjectType(), pdfObject.getID());
            //<start-gpL>
            valueObj.setInCompressedStream(pdfObject.isInCompressedStream());
            //<end-gpl>
            valueObj.setID(PDFkeyInt);
            if(debugFastCode)
                System.out.println("valueObj="+valueObj+" pdfObject="+pdfObject+" PDFkeyInt="+PDFkeyInt+" "+pdfObject.getID()+" "+pdfObject.getParentID());
        }


        if(debugFastCode)
            System.out.println(padding+"Reading [<<data>>] to "+valueObj+" into "+pdfObject+" i="+i);

        i=readDictionaryAsObject( valueObj, objectRef, i, raw, raw.length, false);

        //needed to ensure >>>> works
        if(i<raw.length && raw[i]=='>')
            i--;

        if(debugFastCode){
            System.out.println(padding+"data "+valueObj+" into pdfObject="+pdfObject+" i="+i);
        }

        //store value (already set above for -1
        if(PDFkeyInt!=-1)
            pdfObject.setDictionary(PDFkeyInt,valueObj);

        //roll on to end
        int count=raw.length;
        while( i<count-1 && raw[i]==62  && raw[i+1]==62){ //
            i++;
            if(i+1<raw.length && raw[i+1]==62) //allow for >>>>
                break;
        }
        return i;
    }
    /**
     * if pairs is -1 returns number of pairs
     * otherwise sets pairs and returns point reached in stream
     */
    private int readKeyPairs(int id,byte[] data, int j,int pairs, PdfObject pdfObject) {

        final boolean debug=false;

        int start=j,level=1,length=data.length;

        int numberOfPairs=pairs;

        if(debug){
            System.out.println("count="+pairs+"============================================\n");
            for(int aa=j;aa<length;aa++){
                System.out.print((char)data[aa]);

                if(aa>5 && data[aa-5]=='s' && data[aa-4]=='t' && data[aa-3]=='r'&& data[aa-2]=='e' && data[aa-1]=='a' && data[aa]=='m')
                    aa=length;
            }
            System.out.println("\n============================================");
        }

        //same routine used to count first and then fill with values
        boolean isCountOnly=false,skipToEnd=false;
        byte[][] keys=null,values=null;
        PdfObject[] objs=null;

        if(pairs==-1){
            isCountOnly=true;
        }else if(pairs==-2){
            isCountOnly=true;
            skipToEnd=true;
        }else{
            keys=new byte[numberOfPairs][];
            values=new byte[numberOfPairs][];
            objs=new PdfObject[numberOfPairs];

            if(debug)
                System.out.println("Loading "+numberOfPairs+" pairs");
        }
        pairs=0;

        while(true){

            //move cursor to start of text
            while(data[start]==9 || data[start]==10 || data[start]==13 || data[start]==32 || data[start]==60)
                start++;

            //allow for comment
            if(data[start]==37){
                while(data[start]!=10 && data[start]!=13){
                    //System.out.println(data[start]+" "+(char)data[start]);
                    start++;
                }

                //move cursor to start of text
                while(data[start]==9 || data[start]==10 || data[start]==13 || data[start]==32 || data[start]==60)
                    start++;
            }

            //exit at end
            if(data[start]==62)
                break;

            //count token or tell user problem
            if(data[start]==47){
                pairs++;
                start++;
            }else
                throw new RuntimeException("Unexpected value "+data[start]+" - not key pair");

            //read token key and save if on second run
            int tokenStart=start;
            while(data[start]!=32 && data[start]!=10 && data[start]!=13 && data[start]!='[' && data[start]!='<' && data[start]!='/')
                start++;

            int tokenLength=start-tokenStart;

            byte[] tokenKey=new byte[tokenLength];
            System.arraycopy(data, tokenStart, tokenKey, 0, tokenLength);

            if(!isCountOnly) //pairs already rolled on so needs to be 1 less
                keys[pairs-1]=tokenKey;

            //now skip any spaces to key or text
            while(data[start]==10 || data[start]==13 || data[start]==32)
                start++;

            boolean isDirect=data[start]==60 || data[start]=='[' || data[start]=='/';

            byte[] dictData=null;

            if(debug)
                System.out.println("token="+new String(tokenKey)+" isDirect "+isDirect);

            if(isDirect){
                //get to start at <<
                while(data[start-1]!='<' && data[start]!='<' && data[start]!='[' && data[start]!='/')
                    start++;

                int streamStart=start;

                //find end
                boolean isObject=true;

                if(data[start]=='<'){
                    start=start+2;
                    level=1;

                    while(level>0){
                        //   System.out.print((char)data[start]);
                        if(data[start]=='<' && data[start+1]=='<'){
                            start=start+2;
                            level++;
                        }else if(data[start]=='>' && data[start+1]=='>'){
                            start=start+2;
                            level--;
                        }else
                            start++;
                    }

                    //System.out.println("\n<---------------"+start);

                    //if(data[start]=='>' && data[start+1]=='>')
                    //start=start+2;
                }else if(data[start]=='['){

                    level=1;
                    start++;

                    boolean inStream=false;

                    while(level>0){

                        //allow for streams
                        if(!inStream && data[start]=='(')
                            inStream=true;
                        else if(inStream && data[start]==')' && (data[start-1]!='\\' || data[start-2]=='\\' ))
                            inStream=false;

                        //System.out.println((char)data[start]);

                        if(!inStream){
                            if(data[start]=='[')
                                level++;
                            else if(data[start]==']')
                                level--;
                        }

                        start++;
                    }

                    isObject=false;
                }else if(data[start]=='/'){
                    start++;
                    while(data[start]!='/' && data[start]!=10 && data[start]!=13 && data[start]!=32){
                        start++;

                        if(start<data.length-1 && data[start]=='>' && data[start+1]=='>')
                            break;
                    }
                }

                if(!isCountOnly){
                    int len=start-streamStart;
                    dictData=new byte[len];
                    System.arraycopy(data, streamStart, dictData, 0, len);
                    //pairs already rolled on so needs to be 1 less
                    values[pairs-1]=dictData;

                    String ref=pdfObject.getObjectRefAsString();

                    //@speed - will probably need to change as we add more items

                    if(pdfObject.getObjectType()==PdfDictionary.ColorSpace){

                        if(isObject){


                            handleColorSpaces(pdfObject, 0,  dictData);
                            objs[pairs-1]=pdfObject;
                        }else{
                            ColorSpaceObject colObject=new ColorSpaceObject(ref);

                            if(isDirect)
                                colObject.setRef(-1,0);

                            handleColorSpaces(colObject, 0,  dictData);
                            objs[pairs-1]=colObject;
                        }

                        //handleColorSpaces(-1, valueObj,ref, 0, dictData,debug, -1,null, paddingString);
                    }else if(isObject){

                        PdfObject valueObj=ObjectFactory.createObject(id, ref, pdfObject.getObjectType(), pdfObject.getID());
                        valueObj.setID(id);
                        readDictionaryFromRefOrDirect(id, valueObj,ref, 0, dictData, -1);
                        objs[pairs-1]=valueObj;
                    }

                    //lose >> at end
                    //while(start<data.length && data[start-1]!='>' && data[start]!='>')
                    //	start++;

                }

            }else{ //its 50 0 R

                //number
                int refStart=start, keyStart2=start,keyLength2=0;
                while(data[start]!=10 && data[start]!=13 && data[start]!=32 && data[start]!=47 &&
                        data[start]!=60 && data[start]!=62){
                    start++;
                    keyLength2++;
                }
                int number= NumberUtils.parseInt(keyStart2, start, data);

                //generation
                while(data[start]==10 || data[start]==13 || data[start]==32 || data[start]==47 || data[start]==60)
                    start++;

                keyStart2=start;
                //move cursor to end of reference
                while(data[start]!=10 && data[start]!=13 && data[start]!=32 &&
                        data[start]!=47 && data[start]!=60 && data[start]!=62)
                    start++;

                int generation= NumberUtils.parseInt(keyStart2, start, data);

                //move cursor to start of R
                while(data[start]==10 || data[start]==13 || data[start]==32 || data[start]==47 || data[start]==60)
                    start++;

                if(data[start]!=82) //we are expecting R to end ref
                    throw new RuntimeException("3. Unexpected value in file - please send to IDRsolutions for analysis");

                start++; //roll past

                if(debug)
                    System.out.println("Data in object="+number+" "+generation+" R");

                //read the Dictionary data
                if(!isCountOnly){

                    if(PdfDictionary.getKeyType(id, pdfObject.getObjectType())==PdfDictionary.VALUE_IS_UNREAD_DICTIONARY){

                        String ref=new String(data, refStart,start-refStart);

                        PdfObject valueObj=ObjectFactory.createObject(id, ref, pdfObject.getObjectType(), pdfObject.getID());

                        valueObj.setStatus(PdfObject.UNDECODED_REF);
                        valueObj.setUnresolvedData(ref.getBytes(),id);

                        objs[pairs-1]=valueObj;

                    }else{

                        byte[] rawDictData=readObjectAsByteArray(pdfObject, "", objectReader.isCompressed(number,generation),number,generation);

                        //allow for data in Linear object not yet loaded
                        if(rawDictData==null){
                            pdfObject.setFullyResolved(false);

                            LogWriter.writeLog("[Linearized] "+pdfObject.getObjectRefAsString()+" not yet available (12)");

                            return data.length;
                        }

                        if(debug){
                            System.out.println("============================================\n");
                            for(int aa=0;aa<rawDictData.length;aa++){
                                System.out.print((char)rawDictData[aa]);

                                if(aa>5 && rawDictData[aa-5]=='s' && rawDictData[aa-4]=='t' && rawDictData[aa-3]=='r'&& rawDictData[aa-2]=='e' && rawDictData[aa-1]=='a' && rawDictData[aa]=='m')
                                    aa=rawDictData.length;
                            }
                            System.out.println("\n============================================");
                        }
                        //cleanup
                        //lose obj at start
                        int jj=0;

                        while(jj<3 ||(rawDictData[jj-1]!=106 && rawDictData[jj-2]!=98 && rawDictData[jj-3]!=111)){

                            if(rawDictData[jj]=='/' || rawDictData[jj]=='[' || rawDictData[jj]=='<')
                                break;

                            jj++;

                            if(jj==rawDictData.length){
                                jj=0;
                                break;
                            }
                        }

                        //skip any spaces after
                        while(rawDictData[jj]==10 || rawDictData[jj]==13 || rawDictData[jj]==32)// || data[j]==47 || data[j]==60)
                            jj++;

                        int len=rawDictData.length-jj;
                        dictData=new byte[len];
                        System.arraycopy(rawDictData, jj, dictData, 0, len);
                        //pairs already rolled on so needs to be 1 less
                        values[pairs-1]=dictData;

                        String ref=number+" "+generation+" R";//pdfObject.getObjectRefAsString();

                        if(pdfObject.getObjectType()==PdfDictionary.Font && id==PdfDictionary.Font){//last condition for CharProcs
                            objs[pairs-1]=null;
                            values[pairs-1]=ref.getBytes();
                        }else if(pdfObject.getObjectType()==PdfDictionary.XObject){
                            //intel Unimplemented pattern type 0 in file
                            PdfObject valueObj=ObjectFactory.createObject(id, ref, PdfDictionary.XObject, PdfDictionary.XObject);
                            valueObj.setStatus(PdfObject.UNDECODED_REF);
                            valueObj.setUnresolvedData(ref.getBytes(),id);

                            objs[pairs-1]=valueObj;
                        }else{

                            //@speed - will probably need to change as we add more items
                            PdfObject valueObj=ObjectFactory.createObject(id, ref, pdfObject.getObjectType(), pdfObject.getID());
                            valueObj.setID(id);
                            if(debug){
                                System.out.println(ref+" ABOUT TO READ OBJ for "+valueObj+" "+pdfObject);

                                System.out.println("-------------------\n");
                                for(int aa=0;aa<dictData.length;aa++){
                                    System.out.print((char)dictData[aa]);

                                    if(aa>5 && dictData[aa-5]=='s' && dictData[aa-4]=='t' && dictData[aa-3]=='r'&& dictData[aa-2]=='e' && dictData[aa-1]=='a' && dictData[aa]=='m')
                                        aa=dictData.length;
                                }
                                System.out.println("\n-------------------");
                            }

                            if(valueObj.getObjectType()==PdfDictionary.ColorSpace)
                                handleColorSpaces(valueObj, 0,  dictData);
                            else
                                readDictionaryFromRefOrDirect(id, valueObj,ref, 0, dictData, -1);

                            objs[pairs-1]=valueObj;

                        }
                    }
                }
            }
        }


        if(!isCountOnly)
            pdfObject.setDictionaryPairs(keys,values,objs);

        if(debug)
            System.out.println("done=============================================");

        if(skipToEnd || !isCountOnly)
            return start;
        else
            return pairs;

    }

    private void readStreamIntoObject(PdfObject pdfObject, int j, byte[] data, PdfObject valueObj, String paddingString) {

        int count=data.length;

        if(debugFastCode)
            System.out.println(paddingString+"Looking for stream");

        byte[] stream=null;

        /**
         * see if JBIG encoded
         */
        PdfArrayIterator maskFilters = valueObj.getMixedArray(PdfDictionary.Filter);


        //get type as need different handling
        boolean isJBigEncoded =false;
        int firstMaskValue=PdfDictionary.Unknown;
        if(maskFilters!=null && maskFilters.hasMoreTokens()){
            while(maskFilters.hasMoreTokens() && !isJBigEncoded){
                firstMaskValue=maskFilters.getNextValueAsConstant(true);
                if(firstMaskValue==PdfFilteredReader.JBIG2Decode)
                    isJBigEncoded=true;
            }
        }

        //may need optimising
        //debug - @speed
        for(int a=j;a<count;a++){
            if ((data[a] == 115)&& (data[a + 1] == 116)&& (data[a + 2] == 114)&&
                    (data[a + 3] == 101)&& (data[a + 4] == 97)&& (data[a + 5] == 109)) {


                //ignore these characters and first return
                a = a + 6;

                while(data[a]==32)
                    a++;

                if (data[a] == 13 && data[a+1] == 10) //allow for double linefeed
                    a=a+2;
                else if(data[a]==10 || data[a]==13)
                    a++;

                int start = a;

                a--; //move pointer back 1 to allow for zero length stream

                /**
                 * if Length set and valid use it
                 */
                int streamLength=0;
                int setStreamLength=pdfObject.getInt(PdfDictionary.Length);

                if(debugFastCode)
                    System.out.println(paddingString+"setStreamLength="+setStreamLength);

                boolean	isValid=false;

                if(setStreamLength!=-1){

                    streamLength=setStreamLength;

                    //System.out.println("1.streamLength="+streamLength);

                    a=start+streamLength;

                    if(a<count && data[a]==13 && (a+1<count) && data[a+1]==10)
                        a=a+2;

                    //check validity
                    if (count>(a+9) && data[a] == 101 && data[a + 1] == 110 && data[a + 2] == 100 &&
                            data[a + 3] == 115 && data[a + 4] == 116
                            && data[a + 5] == 114 && data[a + 6] == 101 && data[a + 7] == 97 && data[a + 8] == 109){

                    }else{

                        int current=a;
                        //check forwards
                        if(a<count){
                            while(true){
                                a++;
                                if(isValid || a==count)
                                    break;

                                if (data[a] == 101 && data[a + 1] == 110 && data[a + 2] == 100 && data[a + 3] == 115 && data[a + 4] == 116
                                        && data[a + 5] == 114 && data[a + 6] == 101 && data[a + 7] == 97 && data[a + 8] == 109){

                                    streamLength=a-start;
                                    isValid=true;
                                }
                            }
                        }

                        if(!isValid){
                            a=current;
                            if(a>count)
                                a=count;
                            //check backwords
                            while(true){
                                a--;
                                if(isValid || a<0)
                                    break;

                                if (data[a] == 101 && data[a + 1] == 110 && data[a + 2] == 100 && data[a + 3] == 115 && data[a + 4] == 116
                                        && data[a + 5] == 114 && data[a + 6] == 101 && data[a + 7] == 97 && data[a + 8] == 109){
                                    streamLength=a-start;
                                    isValid=true;
                                }
                            }
                        }

                        if(!isValid)
                            a=current;
                    }

                    //use correct figure if encrypted
                    if(decryption!=null && decryption.getBooleanValue(PDFflags.IS_FILE_ENCRYPTED))
                        streamLength=setStreamLength;

                }else{

                    /**workout length and check if length set*/
                    int end;

                    while (true) { //find end

                        a++;

                        if(a==count)
                            break;
                        if (data[a] == 101 && data[a + 1] == 110 && data[a + 2] == 100 && data[a + 3] == 115 && data[a + 4] == 116
                                && data[a + 5] == 114 && data[a + 6] == 101 && data[a + 7] == 97 && data[a + 8] == 109)
                            break;

                    }

                    end=a-1;

                    if((end>start))
                        streamLength=end-start+1;
                }

                //lose trailing 10s or 13s
                if(streamLength>1 && !(decryption!=null && decryption.getBooleanValue(PDFflags.IS_FILE_ENCRYPTED))){// && !isValid){
                    int ptr=start+streamLength-1;

                    if(ptr<data.length && ptr>0 && (data[ptr]==10 || (data[ptr]==13 && ((valueObj!=null && isJBigEncoded)||(ptr>0 && data[ptr-1]==10))))){
                        streamLength--;
                        ptr--;
                    }
                }

                /**
                 * read stream into object from memory
                 */
                if(start+streamLength>count)
                    streamLength=count-start;

                //@speed - switch off and investigate
                if(streamLength<0)
                    return;

                if(streamLength<0)
                    throw new RuntimeException("Negative stream length "+streamLength+" start="+start+" count="+count);
                stream = new byte[streamLength];
                System.arraycopy(data, start, stream, 0, streamLength);


                a=count;
            }

        }

        if(debugFastCode && stream!=null)
            System.out.println(paddingString+"stream read saved into "+valueObj);

        if(valueObj!=null){

            valueObj.setStream(stream);

            //and decompress now forsome objects
            if(valueObj.decompressStreamWhenRead())
                readStream(valueObj,true,true,false, valueObj.getObjectType()==PdfDictionary.Metadata, valueObj.isCompressedStream(), null);

        }
    }

    /**read a stream*/
    final public byte[] readStream(PdfObject pdfObject, boolean cacheValue,
                                   boolean decompress, boolean keepRaw, boolean isMetaData,
                                   boolean isCompressedStream, String cacheName)  {

        final boolean debugStream=false;
        
        boolean isCachedOnDisk = pdfObject.isCached();

        byte[] data=null;

        if(!isCachedOnDisk)
            data=pdfObject.getDecodedStream();

        //BufferedOutputStream streamCache=null;
        byte[] stream;

        //decompress first time
        if(data==null){

            String objectRef=pdfObject.getObjectRefAsString();

            stream=pdfObject.stream;

            if(isCachedOnDisk){

                //decrypt the stream
                try{
                    if(decryption!=null && !isCompressedStream && (decryption.getBooleanValue(PDFflags.IS_METADATA_ENCRYPTED) || !isMetaData)){

                        decryption.decrypt(null,objectRef, false,cacheName, false,false, cachedObjects);
                    }
                }catch(Exception e){
                    e.printStackTrace();
                    stream=null;
                    LogWriter.writeLog("Exception "+e);
                }
            }

            if(stream!=null){ /**decode and save stream*/

                //decrypt the stream
                try{
                    if(decryption!=null && !isCompressedStream  && (decryption.getBooleanValue(PDFflags.IS_METADATA_ENCRYPTED) || !isMetaData)){// && pdfObject.getObjectType()!=PdfDictionary.ColorSpace){

                        // System.out.println(objectRef+">>>"+pdfObject.getObjectRefAsString());
                        if(pdfObject.getObjectType()==PdfDictionary.ColorSpace && objectRef.startsWith("[")){

                        }else
                            stream=decryption.decrypt(stream,objectRef, false,null,false,false,null);

                    }
                }catch(Exception e){
                    e.printStackTrace();
                    stream=null;
                    LogWriter.writeLog("Exception "+e+" with "+objectRef);
                }
            }

            if(keepRaw)
                pdfObject.stream=null;

            int length=1;

            if(stream!=null || isCachedOnDisk){

                //values for CCITTDecode
                int height=1,width=1;

                int newH=pdfObject.getInt(PdfDictionary.Height);
                if(newH!=-1)
                    height=newH;

                int newW=pdfObject.getInt(PdfDictionary.Width);
                if(newW!=-1)
                    width=newW;

                int newLength=pdfObject.getInt(PdfDictionary.Length);
                if(newLength!=-1)
                    length=newLength;

                /**allow for no width or length*/
                if(height*width==1)
                    width=length;

                PdfArrayIterator filters = pdfObject.getMixedArray(PdfDictionary.Filter);

                //check not handled elsewhere
                int firstValue=PdfDictionary.Unknown;
                if(filters!=null && filters.hasMoreTokens())
                    firstValue=filters.getNextValueAsConstant(false);

                if(debugStream)
                    System.out.println("First filter="+firstValue);

                if (filters != null && firstValue!=PdfDictionary.Unknown && firstValue!=PdfFilteredReader.JPXDecode &&
                        firstValue!=PdfFilteredReader.DCTDecode){

                    if(debugStream)
                        System.out.println("Decoding stream "+stream+" "+pdfObject.isCached()+" "+pdfObject.getObjectRefAsString());
                    
                    try{
                        PdfFilteredReader filter=new PdfFilteredReader();
                        stream =filter.decodeFilters(setupDecodeParms(pdfObject), stream, filters ,width,height, cacheName);

                    }catch(Exception e){

                        LogWriter.writeLog("[PDF] Problem "+e+" decompressing stream ");
                        stream=null;
                        isCachedOnDisk=false; //make sure we return null, and not some bum values
                    }

                    //stop spurious match down below in caching code
                    length=1;
                }else if(stream!=null && length!=-1 && length<stream.length ){

                    /**make sure length correct*/
                    //if(stream.length!=length){
                    if(stream.length!=length && length>0){//<--  last item breaks jbig??
                        byte[] newStream=new byte[length];
                        System.arraycopy(stream, 0, newStream, 0, length);

                        stream=newStream;
                    }else if(stream.length==1 && length==0)
                        stream=new byte[0];
                }
            }


            if(stream!=null && cacheValue)
                pdfObject.setDecodedStream(stream);

            if(decompress && isCachedOnDisk){
                int streamLength = (int) new File(cacheName).length();

                byte[] bytes = new byte[streamLength];

                try {
                    new BufferedInputStream(new FileInputStream(cacheName)).read(bytes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                /**resize if length supplied*/
                if((length!=1)&&(length<streamLength)){

                    /**make sure length correct*/
                    byte[] newStream=new byte[length];
                    System.arraycopy(bytes, 0, newStream, 0, length);

                    bytes=newStream;

                }

                return bytes;
            }

        }else
            stream=data;

        if(stream==null)
            return null;

        //make a a DEEP copy so we cant alter
        int len=stream.length;
        byte[] copy=new byte[len];
        System.arraycopy(stream, 0, copy, 0, len);

        return  copy;
    }



    private int readNameString(PdfObject pdfObject, String objectRef, int i, byte[] raw, int PDFkeyInt, boolean isMap, Object PDFkey) {

        byte[] stringBytes;

        int keyLength,keyStart;

        //move cursor to end of last command if needed
        while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!='(')
            i++;

        //move cursor to start of text
        while(raw[i]==10 || raw[i]==13 || raw[i]==32)
            i++;

        //work out if direct (ie /String or read ref 27 0 R
        int j2=i;
        byte[] arrayData=raw;

        boolean isIndirect=raw[i]!=47 && raw[i]!=40; //Some /NAME values start (

        boolean startsWithBrace=raw[i]==40;

        //delete
        //@speed - lose this code once Filters done properly
        /**
         * just check its not /Filter [/FlateDecode ] or [] or [ /ASCII85Decode /FlateDecode ]
         * by checking next valid char not /
         */
        boolean isInsideArray=false;
        if(isIndirect){
            int aa=i+1;
            while(aa<raw.length && (raw[aa]==10 || raw[aa]==13 || raw[aa]==32 ))
                aa++;

            if(raw[aa]==47 || raw[aa]==']'){
                isIndirect=false;
                i=aa+1;
                isInsideArray=true;
            }
        }

        if(isIndirect){ //its in another object so we need to fetch

            keyStart=i;
            keyLength=0;

            //move cursor to end of ref
            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){
                i++;
                keyLength++;
            }

            //actual value or first part of ref
            int ref= NumberUtils.parseInt(keyStart, i, raw);

            //move cursor to start of generation
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                i++;

            // get generation number
            keyStart=i;
            //move cursor to end of reference
            while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                i++;

            int generation= NumberUtils.parseInt(keyStart, i, raw);

            //move cursor to start of R
            while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                i++;

            if(raw[i]!=82){ //we are expecting R to end ref
                throw new RuntimeException(padding+"2. Unexpected value in file - please send to IDRsolutions for analysis");
            }

            //read the Dictionary data
            arrayData=readObjectAsByteArray(pdfObject, objectRef, objectReader.isCompressed(ref,generation),ref,generation);

            //allow for data in Linear object not yet loaded
            if(arrayData==null){
                pdfObject.setFullyResolved(false);

                if(debugFastCode)
                    System.out.println(padding+"Data not yet loaded");

                LogWriter.writeLog("[Linearized] "+pdfObject.getObjectRefAsString()+" not yet available (13)");

                return raw.length;
            }

            //lose obj at start and roll onto /
            j2=3;
            while(arrayData[j2]!=47)
                j2++;
        }

        //lose /
        j2++;

        //allow for no value with /Intent//Filter
        if(arrayData[j2]==47)
            return j2-1;

        int end=j2+1;


        if(isInsideArray){ //values inside []

            //move cursor to start of text
            while(arrayData[j2]==10 || arrayData[j2]==13 || arrayData[j2]==32 || arrayData[j2]==47)
                j2++;

            int slashes=0;

            //count chars
            byte lastChar=0;
            while(true){
                if(arrayData[end]==']')
                    break;

                if(arrayData[end]==47 && (lastChar==32 || lastChar==10 || lastChar==13))//count the / if gap before
                    slashes++;

                lastChar=arrayData[end];
                end++;

                if(end==arrayData.length)
                    break;
            }

            //set value and ensure space gap
            int charCount=end-slashes,ptr=0;
            stringBytes=new byte[charCount-j2];

            byte nextChar,previous=0;
            for(int ii=j2;ii<charCount;ii++){
                nextChar=arrayData[ii];
                if(nextChar==47){
                    if(previous!=32 && previous!=10 && previous!=13){
                        stringBytes[ptr]=32;
                        ptr++;
                    }
                }else{
                    stringBytes[ptr]=nextChar;
                    ptr++;
                }

                previous=nextChar;
            }
        }else{ //its in data stream directly or (string)

            //count chars
            while(true){

                if(startsWithBrace){
                    if(arrayData[end]==')')
                        break;
                }else if(arrayData[end]==32 || arrayData[end]==10 || arrayData[end]==13 || arrayData[end]==47 || arrayData[end]==62)
                    break;

                end++;

                if(end==arrayData.length)
                    break;
            }

            //set value
            int charCount=end-j2;
            stringBytes=new byte[charCount];
            System.arraycopy(arrayData,j2,stringBytes,0,charCount);

        }

        /**
         * finally set the value
         */
        if(isMap){
            pdfObject.setName(PDFkey, StringUtils.getTextString(stringBytes, false));
        }else
            pdfObject.setName(PDFkeyInt,stringBytes);

        if(debugFastCode)
            System.out.println(padding+"String set as ="+new String(stringBytes)+"< written to "+pdfObject);

        //put cursor in correct place (already there if ref)
        if(!isIndirect)
            i=end-1;

        return i;
    }

    public int readArray(boolean ignoreRecursion, int i, int endPoint, int type, byte[] raw, String objectRef, PdfObject pdfObject, int PDFkeyInt, Object[] objectValuesArray, int keyReached) {

        int keyStart;

        //roll on
        if(type==PdfDictionary.VALUE_IS_KEY_ARRAY && raw[i]==60){
            //i--;
        }else if(raw[i]!=91)
            i++;

        //ignore empty
        if(raw[i]=='[' && raw[i+1]==']')
            return i+1;

        Map isRef=new HashMap();

        boolean isHexString=false;

        boolean alwaysRead =(PDFkeyInt==PdfDictionary.Kids || PDFkeyInt==PdfDictionary.Annots);

        final boolean debugArray=debugFastCode;// || type==PdfDictionary.VALUE_IS_OBJECT_ARRAY;

        if(debugArray)
            System.out.println(padding+"Reading array type="+PdfDictionary.showArrayType(type)+" into "+pdfObject+" "+(char)raw[i]+" "+(char)raw[i+1]+" "+(char)raw[i+2]+" "+(char)raw[i+3]+" "+(char)raw[i+4]);

        if(debugArray){
            for(int aa=i;aa<endPoint;aa++)
                System.out.print((char)raw[aa]);
            System.out.println("");
        }
        int currentElement=0, elementCount=0,rawCount=0;

        //move cursor to start of text
        while(raw[i]==10 || raw[i]==13 || raw[i]==32)
            i++;

        //allow for comment
        if(raw[i]==37){
            while(raw[i]!=10 && raw[i]!=13){
                i++;
            }

            //move cursor to start of text
            while(raw[i]==10 || raw[i]==13 || raw[i]==32)
                i++;
        }

        keyStart=i;

        //work out if direct or read ref ( [values] or ref to [values])
        int j2=i;
        byte[] arrayData=raw;

        //may need to add method to PdfObject is others as well as Mask
        boolean isIndirect=raw[i]!=91 && raw[i]!='(' && (PDFkeyInt!=PdfDictionary.Mask && PDFkeyInt!=PdfDictionary.TR &&
                //pdfObject.getObjectType()!=PdfDictionary.ColorSpace &&
                raw[0]!=0); //0 never occurs but we set as flag if called from gotoDest/DefaultActionHandler

        // allow for /Contents null
        if(raw[i]=='n' && raw[i+1]=='u' && raw[i+2]=='l' && raw[i+2]=='l'){
            isIndirect=false;
            elementCount=1;
        }

        //check not indirect Kids with 1 element and flag
        /**if(raw[i]==91 && pdfObject.getObjectType()==PdfDictionary.Form && PDFkeyInt==PdfDictionary.Kids){


         int j=i,objCount=0;
         while(raw[j]!=']'){

         if(raw[j]=='R')
         objCount++;
         j++;
         }

         if(objCount==1)
         pdfObject.kidsIndirect(true);

         }/**/


        if(debugArray)
            System.out.println("IsIndirect="+isIndirect+" "+raw[i]+" "+(char)raw[i]);


        //check indirect and not [/DeviceN[/Cyan/Magenta/Yellow/Black]/DeviceCMYK 36 0 R]
        if(isIndirect){
            //find next value and make sure not /
            int aa=i;

            while(raw[aa]!=93 ){
                aa++;

                //allow for ref (ie 7 0 R)
                if(aa>=endPoint)
                    break;

                if(raw[aa]=='R' && (raw[aa-1]==32 || raw[aa-1]==10 || raw[aa-1]==13))
                    break;
                else if(raw[aa]=='>' && raw[aa-1]=='>'){
                    isIndirect=false;
                    if(debugArray )
                        System.out.println(padding+"1. rejected as indirect ref");

                    break;
                }else if(raw[aa]==47){
                    isIndirect=false;
                    if(debugArray )
                        System.out.println(padding+"2. rejected as indirect ref - starts with /");

                    break;
                }
            }
        }

        if(debugArray && isIndirect)
            System.out.println(padding+"Indirect ref");

        boolean isSingleKey=false,isSingleDirectValue=false; //flag to show points to Single value (ie /FlateDecode)
        boolean isSingleNull=true;
        int endPtr=-1;

        if((raw[i]==47 || raw[i]=='(' ||
                (raw[i]=='<' && raw[i+1]=='f' && raw[i+2]=='e') && raw[i+3]=='f' && raw[i+4]=='f') &&
                type!=PdfDictionary.VALUE_IS_STRING_ARRAY && PDFkeyInt!=PdfDictionary.TR){ //single value ie /Filter /FlateDecode or (text)

            elementCount=1;
            isSingleKey=true;

            if(debugArray)
                System.out.println(padding+"Direct single value with /");
        }else{

            int endI=-1;//allow for jumping back to single value (ie /Contents 12 0 R )

            if(isIndirect){

                if(debugArray)
                    System.out.println(padding+"------reading data----");

                //allow for indirect to 1 item
                int startI=i;

                if(debugArray)
                    System.out.print(padding+"Indirect object ref=");

                //move cursor to end of ref
                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62){
                    i++;
                }

                //actual value or first part of ref
                int ref= NumberUtils.parseInt(keyStart, i, raw);

                //move cursor to start of generation
                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                    i++;

                // get generation number
                keyStart=i;
                //move cursor to end of reference
                while(raw[i]!=10 && raw[i]!=13 && raw[i]!=32 && raw[i]!=47 && raw[i]!=60 && raw[i]!=62)
                    i++;

                int generation= NumberUtils.parseInt(keyStart, i, raw);

                if(debugFastCode)
                    System.out.print(padding+" ref="+ref+" generation="+generation+"\n");

                // check R at end of reference and abort if wrong
                //move cursor to start of R
                while(raw[i]==10 || raw[i]==13 || raw[i]==32 || raw[i]==47 || raw[i]==60)
                    i++;

                if(raw[i]!=82) //we are expecting R to end ref
                    throw new RuntimeException(padding+"4. Unexpected value "+(char)raw[i]+" in file - please send to IDRsolutions for analysis");

                if(ignoreRecursion && !alwaysRead){

                    if(debugArray)
                        System.out.println(padding+"Ignore sublevels");
                    return i;
                }

                //read the Dictionary data
                arrayData=readObjectAsByteArray(pdfObject, objectRef, objectReader.isCompressed(ref,generation),ref,generation);

                //allow for data in Linear object not yet loaded
                if(arrayData==null){
                    pdfObject.setFullyResolved(false);

                    if(debugFastCode)
                        System.out.println(padding+"Data not yet loaded");

                    LogWriter.writeLog("[Linearized] "+pdfObject.getObjectRefAsString()+" not yet available (14)");

                    return raw.length;
                }

                if(debugArray){
                    System.out.println(padding+"Raw data is>>>>>>>>>>>>>>");
                    System.out.print(padding);
                    for(int aa=0;aa<arrayData.length;aa++)  {
                        System.out.print((char)arrayData[aa]);

                        if(aa>5 && arrayData[aa-5]=='s' && arrayData[aa-4]=='t' && arrayData[aa-3]=='r' && arrayData[aa-2]=='e' && arrayData[aa-1]=='a' && arrayData[aa]=='m')
                            aa=arrayData.length;
                    }

                    System.out.println("\n"+padding+"<<<<<<<<<<<<<<");
                }

                //lose obj at start and roll onto [
                j2=0;
                while(arrayData[j2]!=91){

                    //allow for % comment
                    if(arrayData[j2]=='%'){
                        while(true){
                            j2++;
                            if(arrayData[j2]==13 || arrayData[j2]==10)
                                break;
                        }
                        while(arrayData[j2]==13 || arrayData[j2]==10)
                            j2++;
                    }

                    //allow for null
                    if(arrayData[j2]=='n' && arrayData[j2+1]=='u' && arrayData[j2+2]=='l' && arrayData[j2+3]=='l')
                        break;

                    if(arrayData[j2]==47){ //allow for value of type  32 0 obj /FlateDecode endob
                        j2--;
                        isSingleDirectValue=true;
                        break;
                    }if ((arrayData[j2]=='<' && arrayData[j2+1]=='<')||
                            ((j2+4<arrayData.length) &&arrayData[j2+3]=='<' && arrayData[j2+4]=='<')){ //also check ahead to pick up [<<
                        endI=i;

                        j2=startI;
                        arrayData=raw;

                        if(debugArray)
                            System.out.println(padding+"Single value, not indirect");

                        break;
                    }

                    j2++;
                }
            }

            if(j2<0) //avoid exception
                j2=0;

            //skip [ and any spaces allow for [[ in recursion
            boolean startFound=false;

            while(arrayData[j2]==10 || arrayData[j2]==13 || arrayData[j2]==32 ||
                    (arrayData[j2]==91 && !startFound)){//(type!=PdfDictionary.VALUE_IS_OBJECT_ARRAY || objectValuesArray==null)))

                //if(debugArray)
                //System.out.println(arrayData[j2]+" "+(char)arrayData[j2]);

                if(arrayData[j2]==91){
                    startFound=true;

                    //    if(debugArray)
                    //    System.out.println("found-------");
                }

                j2++;
            }

            //count number of elements
            endPtr=j2;
            boolean charIsSpace,lastCharIsSpace=true,isRecursive ;
            int arrayEnd=arrayData.length;
            if(debugArray)
                System.out.println(padding+"----counting elements----arrayData[endPtr]="+arrayData[endPtr]+" type="+type);

            while(endPtr<arrayEnd && arrayData[endPtr]!=93){

                isRecursive=false;

                //if(debugArray)
                //System.out.println("next Char="+arrayData[endPtr]+" "+(char)arrayData[endPtr]);

                //allow for embedded objects
                while(true){

                    if(arrayData[endPtr]=='<' && arrayData[endPtr+1]=='<'){
                        int levels=1;

                        elementCount++;

                        if(debugArray)
                            System.out.println(padding+"Direct value elementCount="+elementCount);

                        while(levels>0){
                            endPtr++;

                            if(arrayData[endPtr]=='<' && arrayData[endPtr+1]=='<'){
                                endPtr++;
                                levels++;
                            }else if(arrayData[endPtr]=='>' && arrayData[endPtr-1]=='>'){
                                endPtr++;
                                levels--;
                            }
                        }

                        if(type==PdfDictionary.VALUE_IS_KEY_ARRAY)
                            endPtr--;

                    }else
                        break;
                }

                //allow for null (not Mixed!)
                if(type!=PdfDictionary.VALUE_IS_MIXED_ARRAY && arrayData[endPtr]=='n' && arrayData[endPtr+1]=='u' &&
                        arrayData[endPtr+2]=='l' && arrayData[endPtr+3]=='l'){

                    //get next legit value and make sure not only value if layer or Order
                    //to handle bum null values in Layers on some files
                    byte nextChar=93;
                    if(PDFkeyInt==PdfDictionary.Layer || PDFkeyInt==PdfDictionary.Order){
                        for(int aa=endPtr+3;aa<arrayData.length;aa++){
                            if(arrayData[aa]==10 || arrayData[aa]==13 || arrayData[aa]==32 || arrayData[aa]==9){
                            }else{
                                nextChar=arrayData[aa];
                                aa=arrayData.length;
                            }
                        }
                    }

                    if(nextChar==93){
                        isSingleNull=true;
                        elementCount=1;
                        break;
                    }else{  //ignore null value
                        isSingleNull=false;
                        //elementCount++;
                        endPtr=endPtr+4;
                        lastCharIsSpace=true;

                        if(debugArray)
                            System.out.println("ignore null");

                        continue;
                    }
                }

                if(isSingleDirectValue && (arrayData[endPtr]==32 || arrayData[endPtr]==13 || arrayData[endPtr]==10))
                    break;

                if(endI!=-1 && endPtr>endI)
                    break;

                if(type==PdfDictionary.VALUE_IS_KEY_ARRAY){

                    if(arrayData[endPtr]==' ')
                        rawCount++;

                    if(arrayData[endPtr]=='R'  || ((PDFkeyInt==PdfDictionary.TR|| PDFkeyInt==PdfDictionary.Category) && arrayData[endPtr]=='/'  ))
                        elementCount++;

                }else{

                    //handle (string)
                    if(arrayData[endPtr]=='('){
                        elementCount++;

                        if(debugArray)
                            System.out.println(padding+"string");
                        while(true){
                            if(arrayData[endPtr]==')' && !ObjectUtils.isEscaped(arrayData, endPtr))
                                break;

                            endPtr++;

                            lastCharIsSpace=true; //needs to be space for code to work eve if no actual space
                        }
                    }else if(arrayData[endPtr]=='<'){
                        elementCount++;

                        if(debugArray)
                            System.out.println(padding+"direct");
                        while(true){
                            if(arrayData[endPtr]=='>')
                                break;

                            endPtr++;

                            lastCharIsSpace=true; //needs to be space for code to work eve if no actual space
                        }
                    }else if(arrayData[endPtr]==91){ //handle recursion

                        elementCount++;

                        if(debugArray)
                            System.out.println(padding+"recursion");
                        int level=1;
                        while(true){

                            endPtr++;

                            if(arrayData[endPtr]==93)
                                level--;
                            else if(arrayData[endPtr]==91)
                                level++;

                            if(level==0)
                                break;
                        }

                        isRecursive=true;
                        lastCharIsSpace=true; //needs to be space for code to work eve if no actual space

                    }else{

                        charIsSpace = arrayData[endPtr] == 10 || arrayData[endPtr] == 13 || arrayData[endPtr] == 32 || arrayData[endPtr] == 47;

                        //allow for single value
                        if(1==2 && arrayData[endPtr]==47 && type==PdfDictionary.VALUE_IS_MIXED_ARRAY &&
                                PDFkeyInt==PdfDictionary.Filter){ //see if actually new key to end sequence

                            int start=endPtr;
                            while(start<arrayEnd){
                                start++;
                                if(arrayData[start]==13 || arrayData[start]==10 || arrayData[start]==9 || arrayData[start]==32 || arrayData[start]==']')
                                    break;
                            }

                            if(arrayData[start]!=']'){
                                endPtr=arrayEnd;
                            }
                        }

                        if(lastCharIsSpace && !charIsSpace ){
                            if((type==PdfDictionary.VALUE_IS_MIXED_ARRAY || type==PdfDictionary.VALUE_IS_OBJECT_ARRAY)
                                    && arrayData[endPtr]=='R' && arrayData[endPtr-1]!='/'){ //adjust so returns correct count  /R and  on 12 0 R
                                elementCount--;

                                isRef.put(new Integer(elementCount-1),"x");

                                if(debugArray)
                                    System.out.println(padding+"aref "+(char)arrayData[endPtr]);
                            }else
                                elementCount++;

                        }
                        lastCharIsSpace=charIsSpace;
                    }
                }

                //allow for empty array [ ]
                if(!isRecursive && endPtr<arrayEnd && arrayData[endPtr]==93 && type!=PdfDictionary.VALUE_IS_KEY_ARRAY){

                    //get first char
                    int ptr=endPtr-1;
                    while(arrayData[ptr]==13 || arrayData[ptr]==10 || arrayData[ptr]==32)
                        ptr--;

                    if(arrayData[ptr]=='[') //if empty reset
                        elementCount=0;
                    break;
                }

                endPtr++;
            }

            if(debugArray)
                System.out.println(padding+"Number of elements="+elementCount+" rawCount="+rawCount);

            if(elementCount==0 && debugArray)
                System.out.println(padding+"zero elements found!!!!!!");

        }

        if(ignoreRecursion && !alwaysRead)
            return endPtr;

        //now create array and read values
        float[] floatValues=null;
        int[] intValues=null;
        double[] doubleValues=null;
        byte[][] mixedValues=null;
        byte[][] keyValues=null;
        byte[][] stringValues=null;
        boolean[] booleanValues=null;
        Object[] objectValues=null;

        if(type==PdfDictionary.VALUE_IS_FLOAT_ARRAY)
            floatValues=new float[elementCount];
        else if(type==PdfDictionary.VALUE_IS_INT_ARRAY)
            intValues=new int[elementCount];
        else if(type==PdfDictionary.VALUE_IS_BOOLEAN_ARRAY)
            booleanValues=new boolean[elementCount];
        else if(type==PdfDictionary.VALUE_IS_DOUBLE_ARRAY)
            doubleValues=new double[elementCount];
        else if(type==PdfDictionary.VALUE_IS_MIXED_ARRAY)
            mixedValues=new byte[elementCount][];
        else if(type==PdfDictionary.VALUE_IS_KEY_ARRAY)
            keyValues=new byte[elementCount][];
        else if(type==PdfDictionary.VALUE_IS_STRING_ARRAY)
            stringValues=new byte[elementCount][];
        else if(type==PdfDictionary.VALUE_IS_OBJECT_ARRAY)
            objectValues=new Object[elementCount];

        /**
         * read all values and convert
         */
        //if(isSingleNull && arrayData[j2]=='n' && arrayData[j2+1]=='u' &&
        if(arrayData[j2]=='n' && arrayData[j2+1]=='u' &&
                arrayData[j2+2]=='l' && arrayData[j2+3]=='l' && isSingleNull &&
                (type!=PdfDictionary.VALUE_IS_OBJECT_ARRAY || elementCount==1)){

            j2=j2+3;

            if(type==PdfDictionary.VALUE_IS_MIXED_ARRAY)
                mixedValues[currentElement]=null;
            else if(type==PdfDictionary.VALUE_IS_KEY_ARRAY)
                keyValues[currentElement]=null;
            else if(type==PdfDictionary.VALUE_IS_STRING_ARRAY)
                stringValues[currentElement]=null;
            else if(type==PdfDictionary.VALUE_IS_OBJECT_ARRAY)
                objectValues[currentElement]=null;

        }else{///read values

            while(arrayData[j2]!=93){

                if(endPtr>-1 && j2>=endPtr)
                    break;

                //move cursor to start of text
                while(arrayData[j2]==10 || arrayData[j2]==13 || arrayData[j2]==32 || arrayData[j2]==47)
                    j2++;

                keyStart=j2;

                if(debugArray)
                    System.out.print("j2="+j2+" value="+(char)arrayData[j2]);

                boolean isKey=arrayData[j2-1]=='/';
                boolean isRecursiveValue=false; //flag to show if processed in top part so ignore second part

                //move cursor to end of text
                if(type==PdfDictionary.VALUE_IS_KEY_ARRAY ||
                        ((type==PdfDictionary.VALUE_IS_MIXED_ARRAY || type==PdfDictionary.VALUE_IS_OBJECT_ARRAY) && (isRef.containsKey(new Integer(currentElement))||
                                (PDFkeyInt==PdfDictionary.Order && arrayData[j2]>='0' && arrayData[j2]<='9')||
                                (arrayData[j2]=='<' && arrayData[j2+1]=='<')))){

                    if(debugArray)
                        System.out.println("ref currentElement="+currentElement);

                    while(arrayData[j2]!='R' && arrayData[j2]!=']'){

                        //allow for embedded object
                        if(arrayData[j2]=='<' && arrayData[j2+1]=='<'){
                            int levels=1;

                            if(debugArray)
                                System.out.println(padding+"Reading Direct value");

                            while(levels>0){
                                j2++;

                                if(arrayData[j2]=='<' && arrayData[j2+1]=='<'){
                                    j2++;
                                    levels++;
                                }else if(arrayData[j2]=='>' && arrayData[j2+1]=='>'){
                                    j2++;
                                    levels--;
                                }
                            }
                            break;
                        }

                        if(isKey && PDFkeyInt==PdfDictionary.TR && arrayData[j2+1]==' ')
                            break;

                        j2++;
                    }
                    j2++;

                }else{

                    // handle (string)
                    if(arrayData[j2]=='('){

                        keyStart=j2+1;
                        while(true){
                            if(arrayData[j2]==')' && !ObjectUtils.isEscaped(arrayData, j2))
                                break;

                            j2++;
                        }

                        isHexString=false;

                    }else if(arrayData[j2]=='[' && type==PdfDictionary.VALUE_IS_MIXED_ARRAY && PDFkeyInt==PdfDictionary.Names){ // [59 0 R /XYZ null 711 null ]

                        //isHexString=true;
                        keyStart=j2;
                        while(true){
                            if(arrayData[j2]==']')
                                break;

                            j2++;

                        }

                        //include end bracket
                        j2++;

                    }else if(arrayData[j2]=='<'){

                        isHexString=true;
                        keyStart=j2+1;
                        while(true){
                            if(arrayData[j2]=='>')
                                break;

                            if(arrayData[j2]=='/')
                                isHexString=false;

                            j2++;

                        }

                    }else if(arrayData[j2]==91 && type==PdfDictionary.VALUE_IS_OBJECT_ARRAY){

                        //find end
                        int j3=j2+1;
                        int level=1;

                        while(true){

                            j3++;

                            if(arrayData[j3]==93)
                                level--;
                            else if(arrayData[j3]==91)
                                level++;

                            if(level==0)
                                break;
                        }
                        j3++;

                        if(debugArray)
                            padding = padding +"   ";

                        j2=readArray(ignoreRecursion, j2, j3, type,  arrayData, objectRef, pdfObject, PDFkeyInt, objectValues, currentElement) ;

                        if(debugArray){
                            int len=padding.length();

                            if(len>3)
                                padding = padding.substring(0,len-3);
                        }

                        if(arrayData[j2]!='[')
                            j2++;

                        isRecursiveValue=true;

                        while(j2<arrayData.length && arrayData[j2]==']')
                            j2++;

                    }else if(!isKey && elementCount-currentElement==1 && type==PdfDictionary.VALUE_IS_MIXED_ARRAY){ //if last value just read to end in case 1 0 R

                        while(arrayData[j2]!=93 && arrayData[j2]!=47){

                            if(arrayData[j2]==62 && arrayData[j2+1]==62)
                                break;

                            j2++;
                        }
                    }else if(type==PdfDictionary.VALUE_IS_OBJECT_ARRAY && arrayData[j2]=='n' && arrayData[j2+1]=='u' && arrayData[j2+2]=='l' && arrayData[j2+3]=='l'){
                        j2=j2+4;
                        objectValues[currentElement]=null;
                        currentElement++;
                        continue;

                    }else{
                        while(arrayData[j2]!=10 && arrayData[j2]!=13 && arrayData[j2]!=32 && arrayData[j2]!=93 && arrayData[j2]!=47){
                            if(arrayData[j2]==62 && arrayData[j2+1]==62)
                                break;

                            j2++;

                            if(j2==arrayData.length)
                                break;
                        }
                    }
                }

                //actual value or first part of ref
                if(type==PdfDictionary.VALUE_IS_FLOAT_ARRAY)
                    floatValues[currentElement]= NumberUtils.parseFloat(keyStart, j2, arrayData);
                else if(type==PdfDictionary.VALUE_IS_INT_ARRAY)
                    intValues[currentElement]= NumberUtils.parseInt(keyStart, j2, arrayData);
                else if(type==PdfDictionary.VALUE_IS_BOOLEAN_ARRAY){
                    if(raw[keyStart]=='t' && raw[keyStart+1]=='r' && raw[keyStart+2]=='u' && raw[keyStart+3]=='e')
                        booleanValues[currentElement]=true; //(false id default if not set)
                }else if(type==PdfDictionary.VALUE_IS_DOUBLE_ARRAY)
                    doubleValues[currentElement]= NumberUtils.parseFloat(keyStart, j2, arrayData);
                else if(!isRecursiveValue){

                    //include / so we can differentiate /9 and 9
                    if(keyStart>0 && arrayData[keyStart-1]==47)
                        keyStart--;

                    //lose any spurious [
                    if(keyStart>0 && arrayData[keyStart]=='[' && PDFkeyInt!=PdfDictionary.Names)
                        keyStart++;

                    //lose any nulls
                    if(PDFkeyInt==PdfDictionary.Order || PDFkeyInt==PdfDictionary.Layer){

                        while(arrayData[keyStart]=='n'){
                            while(arrayData[keyStart]=='n' && arrayData[keyStart+1]=='u' && arrayData[keyStart+2]=='l' && arrayData[keyStart+3]=='l' ){
                                keyStart=keyStart+4;

                                //lose any spurious chars at start
                                while(keyStart>=0 && (arrayData[keyStart]==' ' || arrayData[keyStart]==10 || arrayData[keyStart]==13 || arrayData[keyStart]==9))
                                    keyStart++;
                            }
                        }
                    }

                    //lose any spurious chars at start
                    while(keyStart>=0 && (arrayData[keyStart]==' ' || arrayData[keyStart]==10 || arrayData[keyStart]==13 || arrayData[keyStart]==9))
                        keyStart++;

                    byte[] newValues= readEscapedValue(j2,arrayData, keyStart, PDFkeyInt==PdfDictionary.ID);

                    if(debugArray)
                        System.out.println(padding+"<1.Element -----"+currentElement+"/"+elementCount+"( j2="+j2+" ) value="+new String(newValues)+"<");

                    if(j2==arrayData.length){
                        //ignore
                    }else if(arrayData[j2]=='>'){
                        j2++;
                        //roll past ) and decrypt if needed
                    }else if(arrayData[j2]==')'){
                        j2++;

                        //	 if(pdfObject.getObjectType()!=PdfDictionary.Names){
                        try {
                            if(!pdfObject.isInCompressedStream() && decryption!=null)
                                newValues=decryption.decrypt(newValues,objectRef, false,null, false,false,null);
                        } catch (PdfSecurityException e) {
                            e.printStackTrace();
                        }

                        //convert Strings in Order now
                        if(PDFkeyInt==PdfDictionary.Order){
                            newValues= StringUtils.getTextString(newValues, false).getBytes();
                        }
                        //}
                    }

                    //update pointer if needed
                    if(isSingleKey)
                        i=j2;

                    if(type==PdfDictionary.VALUE_IS_MIXED_ARRAY){
                        mixedValues[currentElement]=newValues;
                    }else if(type==PdfDictionary.VALUE_IS_KEY_ARRAY){
                        keyValues[currentElement]= ObjectUtils.convertReturnsToSpaces(newValues);
                    }else if(type==PdfDictionary.VALUE_IS_STRING_ARRAY){
                        if(isHexString){
                            //convert to byte values
                            String nextValue;
                            String str=new String(newValues);
                            byte[] IDbytes=new byte[newValues.length/2];
                            for(int ii=0;ii<newValues.length;ii=ii+2){

                                if(ii+2>newValues.length)
                                    continue;

                                nextValue=str.substring(ii,ii+2);
                                IDbytes[ii/2]=(byte)Integer.parseInt(nextValue,16);

                            }
                            newValues=IDbytes;
                        }

                        stringValues[currentElement]=newValues;

                    }else if(type==PdfDictionary.VALUE_IS_OBJECT_ARRAY){
                        objectValues[currentElement]=(newValues);

                        // <start-me>
                        if(debugArray)
                            System.out.println(padding+"objectValues["+currentElement+"]="+Arrays.toString(objectValues)+" ");
                        // <end-me>
                    }
                }
                currentElement++;

                if(debugArray)
                    System.out.println(padding+"roll onto ==================================>"+currentElement+"/"+elementCount);
                if(currentElement==elementCount)
                    break;
            }
        }

        //put cursor in correct place (already there if ref)
        if(!isIndirect)
            i=j2;

        //set value
        if(type==PdfDictionary.VALUE_IS_FLOAT_ARRAY)
            pdfObject.setFloatArray(PDFkeyInt,floatValues);
        else if(type==PdfDictionary.VALUE_IS_INT_ARRAY)
            pdfObject.setIntArray(PDFkeyInt,intValues);
        else if(type==PdfDictionary.VALUE_IS_BOOLEAN_ARRAY)
            pdfObject.setBooleanArray(PDFkeyInt,booleanValues);
        else if(type==PdfDictionary.VALUE_IS_DOUBLE_ARRAY)
            pdfObject.setDoubleArray(PDFkeyInt,doubleValues);
        else if(type==PdfDictionary.VALUE_IS_MIXED_ARRAY)
            pdfObject.setMixedArray(PDFkeyInt,mixedValues);
        else if(type==PdfDictionary.VALUE_IS_KEY_ARRAY){

            if(type==PdfDictionary.VALUE_IS_KEY_ARRAY && elementCount==1 && PDFkeyInt==PdfDictionary.Annots){//allow for indirect on Annots

                byte[] objData=keyValues[0];

                //allow for null
                if(objData==null)
                    return i;

                int size=objData.length;
                if(objData[size-1]=='R'){

                    PdfObject obj=new PdfObject(new String(objData));
                    byte[] newData=readObjectData(obj);

                    if(newData!=null){
                        //System.out.println("newData="+new String(newData));

                        int jj=0,newLen=newData.length;
                        boolean hasArray=false;
                        while(jj<newLen){
                            jj++;

                            if(jj==newData.length)
                                break;

                            if(newData[jj]=='['){
                                hasArray=true;
                                break;
                            }else if(newData[jj-1]=='<' && newData[jj]=='<'){
                                hasArray=false;
                                break;
                            }
                        }

                        if(hasArray)
                            readArray(false, jj, newLen, PdfDictionary.VALUE_IS_KEY_ARRAY, newData,new String(objData), pdfObject, PDFkeyInt, null, -1);
                        else
                            pdfObject.setKeyArray(PDFkeyInt,keyValues);
                        //objectValues=null;
                    }

                }
            }else
                pdfObject.setKeyArray(PDFkeyInt,keyValues);


        }else if(type==PdfDictionary.VALUE_IS_STRING_ARRAY)
            pdfObject.setStringArray(PDFkeyInt,stringValues);
        else if(type==PdfDictionary.VALUE_IS_OBJECT_ARRAY){

            //allow for indirect order
            if(PDFkeyInt==PdfDictionary.Order && objectValues!=null && objectValues.length==1 && objectValues[0] instanceof byte[]){

                byte[] objData=(byte[]) objectValues[0];
                int size=objData.length;
                if(objData[size-1]=='R'){

                    PdfObject obj=new OCObject(new String(objData));
                    byte[] newData=readObjectData(obj);

                    int jj=0,newLen=newData.length;
                    boolean hasArray=false;
                    while(jj<newLen){
                        jj++;

                        if(jj==newData.length)
                            break;

                        if(newData[jj]=='['){
                            hasArray=true;
                            break;
                        }
                    }

                    if(hasArray)
                        readArray(false, jj, newLen, PdfDictionary.VALUE_IS_OBJECT_ARRAY, newData, new String(objData), pdfObject, PDFkeyInt, null, -1);

                    objectValues=null;

                }
            }

            if(objectValuesArray!=null){
                objectValuesArray[keyReached]=objectValues;
                // <start-me>
                if(debugArray)
                    System.out.println(padding+"set Object objectValuesArray["+keyReached+"]="+ Arrays.toString(objectValues));
                // <end-me>
            }else if(objectValues!=null){
                pdfObject.setObjectArray(PDFkeyInt,objectValues);
                // <start-me>
                if(debugArray)
                    System.out.println(padding+PDFkeyInt+" set Object value="+Arrays.toString(objectValues));
                // <end-me>
            }
        }

        if(debugArray)  {
            String values="[";

            if(type==PdfDictionary.VALUE_IS_FLOAT_ARRAY){
                int count=floatValues.length;
                for(int jj=0;jj<count;jj++)
                    values=values+floatValues[jj]+" ";

            }else if(type==PdfDictionary.VALUE_IS_DOUBLE_ARRAY){
                int count=doubleValues.length;
                for(int jj=0;jj<count;jj++)
                    values=values+doubleValues[jj]+" ";

            }else if(type==PdfDictionary.VALUE_IS_INT_ARRAY){
                int count=intValues.length;
                for(int jj=0;jj<count;jj++)
                    values=values+intValues[jj]+" ";

            }else if(type==PdfDictionary.VALUE_IS_BOOLEAN_ARRAY){
                int count=booleanValues.length;
                for(int jj=0;jj<count;jj++)
                    values=values+booleanValues[jj]+" ";

            }else if(type==PdfDictionary.VALUE_IS_MIXED_ARRAY){
                int count=mixedValues.length;
                for(int jj=0;jj<count;jj++)
                    if(mixedValues[jj]==null)
                        values=values+"null ";
                    else
                        values=values+new String(mixedValues[jj])+" ";

            }else if(type==PdfDictionary.VALUE_IS_KEY_ARRAY){
                int count=keyValues.length;
                for(int jj=0;jj<count;jj++){
                    if(keyValues[jj]==null)
                        values=values+"null ";
                    else
                        values=values+new String(keyValues[jj])+" ";
                }
            }else if(type==PdfDictionary.VALUE_IS_STRING_ARRAY){
                int count=stringValues.length;
                for(int jj=0;jj<count;jj++){
                    if(stringValues[jj]==null)
                        values=values+"null ";
                    else
                        values=values+new String(stringValues[jj])+" ";
                }
            }else if(type==PdfDictionary.VALUE_IS_OBJECT_ARRAY){
                values = ObjectUtils.showMixedValuesAsString(objectValues, "");
            }

            values=values+" ]";

            if(debugArray)
                System.out.println(padding+"values="+values);
        }

        //roll back so loop works if no spaces
        if(i<raw.length &&(raw[i]==47 || raw[i]==62))
            i--;

        return i;
    }


    public PdfObject[] setupDecodeParms(PdfObject pdfObject) {

        PdfObject[] decodeParmsValues;
        Object[] DecodeParmsArray = pdfObject.getObjectArray(PdfDictionary.DecodeParms);

        //if specific DecodeParms for each filter, set othereise use global
        if(DecodeParmsArray!=null){

            int count=DecodeParmsArray.length;
            decodeParmsValues=new PdfObject[count];
            for(int i=0;i<count;i++){

                byte[] decodeByteData= (byte[]) DecodeParmsArray[i];

                if(decodeByteData!=null){
                    String key= new String(decodeByteData);

                    PdfObject DecodeParms=new DecodeParmsObject(key);

                    if(decodeByteData[0]=='<')
                        DecodeParms.setStatus(PdfObject.UNDECODED_DIRECT);
                    else
                        DecodeParms.setStatus(PdfObject.UNDECODED_REF);

                    //must be done AFTER setStatus()
                    DecodeParms.setUnresolvedData(decodeByteData, PdfDictionary.DecodeParms);
                    checkResolved(DecodeParms);

                    decodeParmsValues[i]=DecodeParms;
                }else
                    decodeParmsValues[i]=null;
            }

        }else{
            decodeParmsValues=new PdfObject[1];
            decodeParmsValues[0]= pdfObject.getDictionary(PdfDictionary.DecodeParms);
        }
        return decodeParmsValues;
    }

    /**
     * read an object in the pdf into a Object which can be an indirect or an object
     *
     */
    final public void readObject(PdfObject pdfObject){

        String objectRef=pdfObject.getObjectRefAsString();

        if(pdfObject.isDataExternal() && linHintTable!=null){

            if(pdfObject.isDataExternal() && linHintTable!=null){

                int ref=pdfObject.getObjectRefID();
                int generation=pdfObject.getObjectRefGeneration();

                byte[] pageData = readObjectAsByteArray(pdfObject, objectRef, objectReader.isCompressed(ref, generation), ref, generation);

                //PdfObject childObj=ObjectFactory.createObject(pdfObject.getID(), pdfObject.getObjectRefAsString(), pdfObject.getObjectType(), pdfObject.getID());
                pdfObject.setStatus(PdfObject.UNDECODED_DIRECT);
                pdfObject.setUnresolvedData(pageData, PdfDictionary.Page);

                resolveFully(pdfObject);

                return ;
            }
        }

        final boolean debug=false;

        if(debug)
            System.err.println("reading objectRef=" + objectRef + "< isCompressed=" + objectReader.isCompressed(objectRef));

        boolean isCompressed=objectReader.isCompressed(objectRef);
        pdfObject.setCompressedStream(isCompressed);

        //any stream
        byte[] raw ;//stream=null;

        /**read raw object data*/
        if(isCompressed){

            int objectID=Integer.parseInt(objectRef.substring(0,objectRef.indexOf(' ')));
            int compressedID=objectReader.getCompressedStreamObject(objectRef);
            String compressedRef=compressedID+" 0 R",startID=null;
            int First=lastFirst;
            boolean isCached=true; //assume cached

            //see if we already have values
            byte[] compressedStream=lastCompressedStream;
            Map offsetStart=lastOffsetStart;
            Map offsetEnd=lastOffsetEnd;

            PdfObject Extends=null;

            if(lastOffsetStart!=null && compressedID==lastCompressedID)
                startID=(String) lastOffsetStart.get(String.valueOf(objectID));

            //read 1 or more streams
            while(startID==null){

                if(Extends!=null){
                    compressedObj=Extends;
                }else if(compressedID!=lastCompressedID){

                    isCached=false;

                    try{
                        objectReader.movePointer(compressedRef);
                    }catch(Exception e){
                        LogWriter.writeLog("Exception moving pointer to "+objectRef);
                    }

                    raw = readObjectData(objectReader.ObjLengthTable[compressedID],null);

                    compressedObj=new CompressedObject(compressedRef);
                    readDictionaryAsObject(compressedObj, objectRef,0,raw, -1, false);

                }

                /**get offsets table see if in this stream*/
                offsetStart=new HashMap();
                offsetEnd=new HashMap();
                First=compressedObj.getInt(PdfDictionary.First);

                compressedStream=compressedObj.getDecodedStream();

                objectReader.extractCompressedObjectOffset(offsetStart, offsetEnd,First, compressedStream, compressedID);

                startID=(String) offsetStart.get(String.valueOf(objectID));

                Extends=compressedObj.getDictionary(PdfDictionary.Extends);
                if(Extends==null)
                    break;

            }

            if(!isCached){
                lastCompressedStream=compressedStream;
                lastCompressedID=compressedID;
                lastOffsetStart=offsetStart;
                lastOffsetEnd=offsetEnd;
                lastFirst=First;
            }

            /**put bytes in stream*/
            int start=First+Integer.parseInt(startID),end=compressedStream.length;

            String endID=(String) offsetEnd.get(String.valueOf(objectID));
            if(endID!=null)
                end=First+Integer.parseInt(endID);

            int streamLength=end-start;
            raw = new byte[streamLength];
            System.arraycopy(compressedStream, start, raw, 0, streamLength);

            pdfObject.setInCompressedStream(true);
        }else{
            try{
                objectReader.movePointer(objectRef);
            }catch(Exception e){
                LogWriter.writeLog("Exception moving pointer to "+objectRef);
            }

            if(objectRef.charAt(0)=='<'){
                raw=readObjectData(-1, pdfObject);
            }else{
                int pointer=objectRef.indexOf(' ');
                int id=Integer.parseInt(objectRef.substring(0,pointer));

                if(objectReader.ObjLengthTable==null || refTableInvalid){ //isEncryptionObject

                    //allow for bum object
                    if(objectReader.getPointer()==0)
                        raw=new byte[0];
                    else
                        raw=readObjectData(-1, pdfObject);


                }else if(id>objectReader.ObjLengthTable.length || objectReader.ObjLengthTable[id]==0){
                    LogWriter.writeLog(objectRef+ " cannot have offset 0");
                    raw=new byte[0];
                }else
                    raw = readObjectData(objectReader.ObjLengthTable[id], pdfObject);
            }
        }

        if(raw.length>1)
            readDictionaryAsObject(pdfObject, objectRef,0,raw, -1, false);

    }


    byte[] readObjectData(int bufSize, PdfObject pdfObject){

        if(objectReader==null)
            return new byte[0];

        int newCacheSize=-1,startStreamCount=0;
        boolean startStreamFound=false, reachedCacheLimit=false;
        long start=-1;

        if(pdfObject!=null) //only use if values found
            newCacheSize=this.newCacheSize;

        final int XXX=2*1024*1024;
        int rawSize=bufSize,realPos=0;
        boolean lengthSet=false; //start false and set to true if we find /Length in metadata
        boolean streamFound=false;

        if(bufSize<1)
            bufSize=128;

        if(newCacheSize!=-1 && bufSize>newCacheSize)
            bufSize=newCacheSize;

        //array for data
        int ptr=0, maxPtr=bufSize;
        byte[] readData=new byte[maxPtr];
        int charReached = 0,charReached2=0, charReached3=0;
        byte[] array,buffer=null,dataRead=null;
        boolean inStream=false;

        /**adjust buffer if less than bytes left in file*/
        long pointer,lastEndStream=-1,objStart=-1;

        /**read the object or block*/
        byte currentByte ;
        int i=bufSize-1, offset=-bufSize, blocksRead=0, lastEnd=-1,lastComment=-1;

        while (true) {

            i++;

            if(i==bufSize){

                //cache data and update counter
                if(blocksRead==1){
                    dataRead=buffer;
                }else if(blocksRead>1){

                    int bytesRead=dataRead.length;
                    int newBytes=buffer.length;
                    byte[] tmp=new byte[bytesRead+newBytes];

                    //existing data into new array
                    System.arraycopy(dataRead, 0, tmp, 0, bytesRead);
                    System.arraycopy(buffer, 0, tmp, bytesRead, newBytes);

                    dataRead=tmp;
                }

                if(streamFound && reachedCacheLimit) //stop if over max size
                    break;

                blocksRead++;

                /**
                 * read the next block
                 */
                pointer = objectReader.getPointer();

                if(start==-1)
                    start=pointer;

                /**adjust buffer if less than bytes left in file*/
                if (pointer + bufSize > objectReader.eof)
                    bufSize = (int) (objectReader.eof - pointer);

                bufSize += 6;
                buffer = new byte[bufSize];

                /**get bytes into buffer*/
                try {
                    objectReader.read(buffer);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                /**
                 * allow for offset being wrong on first block and hitting part of endobj and cleanup
                 * so does not break later code
                 */
                if (blocksRead == 1) {
                    int j = 0;
                    while (buffer[j] == 'e' || buffer[j] == 'n' || buffer[j] == 'd' || buffer[j] == 'o' || buffer[j] == 'b' || buffer[j] == 'j') {
                        j++;
                    }
                    if (j > 0) { //adjust to remove stuff at start
                        byte[] oldBuffer = buffer;
                        int newLength = buffer.length - j;
                        buffer = new byte[newLength];

                        //existing data into new array
                        System.arraycopy(oldBuffer, j, buffer, 0, newLength);
                    }
                }

                offset=offset+i;
                i=0;

            }

            /**write out and look for endobj at end*/
            currentByte = buffer[i];

            if(currentByte=='%') //track comments
                lastComment=realPos;

            /**check for endobj at end - reset if not*/
            if (currentByte == endPattern[charReached] &&  !inStream)
                charReached++;
            else
                charReached = 0;

            //also scan for <SPACE>obj after endstream incase no endobj
            if(streamFound &&currentByte == endObj[charReached2] &&  !inStream)
                charReached2++;
            else
                charReached2 = 0;

            //look for start of stream and set inStream true
            if(newCacheSize!=-1 && !reachedCacheLimit){
                if (startStreamCount<6 && currentByte == startStream[startStreamCount]){
                    startStreamCount++;
                }else
                    startStreamCount=0;

                if(!startStreamFound && (startStreamCount == 6)) //stream start found so log
                    startStreamFound=true;

                //PUT BACK to switch on caching
                if(startStreamFound && ((buffer!=null &&buffer.length>newCacheSize)|| (dataRead!=null &&dataRead.length>newCacheSize))){ //stop if over max size

                    pdfObject.setCache(start,this);

                    //if(!reachedCacheLimit)
                    //System.out.println("Set cache="+start+" "+pdfObject+" "+pdfObject.getObjectRefAsString());

                    reachedCacheLimit=true;
                }
            }

            /**if length not set we go on endstream in data*/
            if(!lengthSet){

                //also scan for /Length if it had a valid size
                if(rawSize!=-1){
                    if(!streamFound &&currentByte == lengthString[charReached3] &&  !inStream){
                        charReached3++;
                        if(charReached3==6)
                            lengthSet=true;
                    }else
                        charReached3 = 0;
                }
            }

            if (charReached == 6 || charReached2==4){

                if(!lengthSet)
                    break;

                charReached=0;
                charReached2=0;
                lastEnd=realPos;

            }

            if(lengthSet && realPos>=rawSize)
                break;

            if(!inStream){

                readData[ptr]=currentByte;

                ptr++;
                if(ptr==maxPtr){
                    if(maxPtr<XXX)
                        maxPtr=maxPtr*2;
                    else
                        maxPtr=maxPtr+100000;

                    byte[] tmpArray=new byte[maxPtr];
                    System.arraycopy(readData,0,tmpArray,0,readData.length);

                    readData=tmpArray;
                }
            }

            realPos++;
        }

        if(blocksRead==1){ //scenario 1 - all in first block
            array=new byte[i];
            System.arraycopy(buffer, 0, array, 0, i);
        }else{
            int bytesRead=dataRead.length;

            array=new byte[bytesRead+i];
            //existing data
            System.arraycopy(dataRead, 0, array, 0, bytesRead);

            //data from current block
            System.arraycopy(buffer, 0, array, bytesRead, i);
        }

        if(lengthSet && lastEnd!=-1 && lastComment!=-1 && lastComment>lastEnd){
            byte[] newArray = new byte[lastEnd];
            System.arraycopy(array, 0, newArray, 0, lastEnd);
            array = newArray;
        }

        if(!lengthSet)
            array = ObjectUtils.checkEndObject(array, objStart, lastEndStream);


        return array;
    }


    /**
     * read an object in the pdf into a Object which can be an indirect or an object
     *
     */
    private byte[] readObjectData(PdfObject pdfObject){

        String objectRef=pdfObject.getObjectRefAsString();

        //read the Dictionary data
        if(pdfObject.isDataExternal()){
            //byte[] data=readObjectAsByteArray(pdfObject, objectRef, isCompressed(number,generation),number,generation);
            byte[] data=readObjectAsByteArray(pdfObject, objectRef, false,pdfObject.getObjectRefID(),0);

            //allow for data in Linear object not yet loaded
            if(data==null){
                pdfObject.setFullyResolved(false);

                //if(debugFastCode)
                //    System.out.println(paddingString+"Data not yet loaded");

                LogWriter.writeLog("[Linearized] "+pdfObject.getObjectRefAsString()+" not yet available (15)");

                return data;
            }
        }


        final boolean debug=false;

        if(debug)
            System.err.println("reading objectRef="+objectRef+"< isCompressed="+objectReader.isCompressed(objectRef));

        boolean isCompressed=objectReader.isCompressed(objectRef);
        pdfObject.setCompressedStream(isCompressed);

        //any stream
        byte[] raw ;

        /**read raw object data*/
        if(isCompressed){

            int objectID=Integer.parseInt(objectRef.substring(0,objectRef.indexOf(' ')));
            int compressedID=objectReader.getCompressedStreamObject(objectRef);
            String compressedRef=compressedID+" 0 R",startID=null;
            int First=lastFirst;
            boolean isCached=true; //assume cached

            //see if we already have values
            byte[] compressedStream=lastCompressedStream;
            Map offsetStart=lastOffsetStart;
            Map offsetEnd=lastOffsetEnd;

            PdfObject Extends=null;

            if(lastOffsetStart!=null)
                startID=(String) lastOffsetStart.get(String.valueOf(objectID));

            //read 1 or more streams
            while(startID==null){

                if(Extends!=null){
                    compressedObj=Extends;
                }else if(compressedID!=lastCompressedID){

                    isCached=false;

                    try{
                        objectReader.movePointer(compressedRef);
                    }catch(Exception e){
                        LogWriter.writeLog("Exception moving pointer to "+objectRef);
                    }

                    raw = readObjectData(objectReader.ObjLengthTable[compressedID],null);

                    compressedObj=new CompressedObject(compressedRef);
                    readDictionaryAsObject(compressedObj, objectRef,0,raw, -1, false);

                }

                /**get offsets table see if in this stream*/
                offsetStart=new HashMap();
                offsetEnd=new HashMap();
                First=compressedObj.getInt(PdfDictionary.First);

                compressedStream=compressedObj.getDecodedStream();

                objectReader.extractCompressedObjectOffset(offsetStart, offsetEnd,First, compressedStream, compressedID);

                startID=(String) offsetStart.get(String.valueOf(objectID));

                Extends=compressedObj.getDictionary(PdfDictionary.Extends);
                if(Extends==null)
                    break;

            }

            if(!isCached){
                lastCompressedStream=compressedStream;
                lastCompressedID=compressedID;
                lastOffsetStart=offsetStart;
                lastOffsetEnd=offsetEnd;
                lastFirst=First;
            }

            /**put bytes in stream*/
            int start=First+Integer.parseInt(startID),end=compressedStream.length;

            String endID=(String) offsetEnd.get(String.valueOf(objectID));
            if(endID!=null)
                end=First+Integer.parseInt(endID);

            int streamLength=end-start;
            raw = new byte[streamLength];
            System.arraycopy(compressedStream, start, raw, 0, streamLength);

            pdfObject.setInCompressedStream(true);

        }else{
            try{
                objectReader.movePointer(objectRef);
            }catch(Exception e){
                LogWriter.writeLog("Exception moving pointer to "+objectRef);
            }

            if(objectRef.charAt(0)=='<'){
                raw=readObjectData(-1, pdfObject);
            }else{
                int pointer=objectRef.indexOf(' ');
                int id=Integer.parseInt(objectRef.substring(0,pointer));

                if(objectReader.ObjLengthTable==null || refTableInvalid){ //isEncryptionObject

                    //allow for bum object
                    if(objectReader.getPointer()==0)
                        raw=new byte[0];
                    else
                        raw=readObjectData(-1, pdfObject);


                }else if(id>objectReader.ObjLengthTable.length || objectReader.ObjLengthTable[id]==0){
                    LogWriter.writeLog(objectRef+ " cannot have offset 0");
                    raw=new byte[0];
                }else
                    raw = readObjectData(objectReader.ObjLengthTable[id], pdfObject);
            }
        }

        return raw;

    }

    /**
     * get object as byte[]
     * @param objectRef is only needed if compressed
     * @param isCompressed
     * @param objectID
     * @param gen
     * @return
     */
    public byte[] readObjectAsByteArray(PdfObject pdfObject,String objectRef, boolean isCompressed, int objectID, int gen) {

        //data not in PDF stream
        if(pdfObject.isDataExternal()){
            if(linHintTable!=null)
                return linHintTable.getObjData(objectID);
            else
                return null;
        }

        byte[] raw;

        /**read raw object data*/
        if(isCompressed){

            int compressedID=objectReader.getCompressedStreamObject(objectID, gen);
            String startID=null,compressedRef;
            Map offsetStart=lastOffsetStart,offsetEnd=lastOffsetEnd;
            int First=lastFirst;
            byte[] compressedStream;
            boolean isCached=true; //assume cached

            PdfObject compressedObj, Extends;

            //see if we already have values
            compressedStream=lastCompressedStream;
            if(lastOffsetStart!=null)
                startID=(String) lastOffsetStart.get(String.valueOf(objectID));

            //read 1 or more streams
            while(startID==null){

                isCached=false;
                try{
                    objectReader.movePointer(compressedID, 0);
                }catch(Exception e){
                    LogWriter.writeLog("Exception moving pointer to "+objectID);
                }

                raw = readObjectData(objectReader.ObjLengthTable[compressedID],null);

                //may need to use compObj and not objectRef
                String compref=compressedID+" "+gen+" R";
                compressedObj=new CompressedObject(compref);
                readDictionaryAsObject(compressedObj, objectRef,0,raw, -1, false);


                /**get offsets table see if in this stream*/
                offsetStart=new HashMap();
                offsetEnd=new HashMap();

                First=compressedObj.getInt(PdfDictionary.First);

                //                if(isEncrypted){
                //                    byte[] bytes=((byte[])compressedObject.get("Stream"));
                //
                //                    try{
                //                        bytes=decrypt(bytes,compressedID+" 0 R", false,null,false,false);
                //                    }catch(Exception ee){
                //
                //                        ee.printStackTrace();
                //                    }
                //                    compressedObject.put("Stream",bytes);
                //
                //                }

                //do later due to code above
                compressedStream=compressedObj.getDecodedStream();

                //start
                //compressedStream=this.readStream(compressedObject,objectRef,true,true,false, false,false);
                //PdfReader.checkStreamsIdentical(compressedStream, oldCompressedStream);
                //////////////////////////////////////


                objectReader.extractCompressedObjectOffset(offsetStart, offsetEnd,First, compressedStream, compressedID);

                startID=(String) offsetStart.get(String.valueOf(objectID));

                Extends=compressedObj.getDictionary(PdfDictionary.Extends);
                if(Extends==null)
                    compressedRef=null;
                else
                    compressedRef=Extends.getObjectRefAsString();

                if(compressedRef!=null)
                    compressedID=Integer.parseInt(compressedRef.substring(0,compressedRef.indexOf(' ')));

            }

            if(!isCached){
                lastCompressedStream=compressedStream;
                lastOffsetStart=offsetStart;
                lastOffsetEnd=offsetEnd;
                lastFirst=First;
            }

            /**put bytes in stream*/
            int start=First+Integer.parseInt(startID),end=compressedStream.length;
            String endID=(String) offsetEnd.get(String.valueOf(objectID));
            if(endID!=null)
                end=First+Integer.parseInt(endID);

            int streamLength=end-start;
            raw = new byte[streamLength];
            System.arraycopy(compressedStream, start, raw, 0, streamLength);

            pdfObject.setInCompressedStream(true);
        }else{
            try{
                objectReader.movePointer(objectID, gen);
            }catch(Exception e){
                LogWriter.writeLog("Exception moving pointer to "+objectRef);
            }

            if(objectReader.ObjLengthTable==null || refTableInvalid)
                raw=readObjectData(-1,pdfObject);
            else if(objectID>objectReader.ObjLengthTable.length)
                return null;
            else
                raw = readObjectData(objectReader.ObjLengthTable[objectID],pdfObject);
        }

        return raw;
    }

    /**
     * used by linearization to check object fully fully available and return false if not
     * @param pdfObject
     */
    public synchronized boolean resolveFully(PdfObject pdfObject){

        boolean fullyResolved=true;
        int ref=0,generation=0;

        try{
            if(pdfObject==null)
                return false;

            byte[] raw=null;

            if(pdfObject.getStatus()==PdfObject.DECODED)
                raw=pdfObject.getObjectRefAsString().getBytes();
            else
                raw=pdfObject.getUnresolvedData();

            //flag now done and flush raw data
            pdfObject.setStatus(PdfObject.DECODED);

            String objectRef=pdfObject.getObjectRefAsString();

            //allow for empty object
            if(raw[0]=='e' && raw[1]=='n' && raw[2]=='d' && raw[3]=='o' && raw[4]=='b' ){
                //empty object
            }else{ //we need to ref from ref elsewhere which may be indirect [ref], hence loop

                int j=0;

                //allow for [ref] at top level (may be followed by gap
                while (raw[j] == 91 || raw[j] == 32 || raw[j] == 13 || raw[j] == 10)
                    j++;

                // get object ref
                int keyStart = j;
                int refStart=j;
                //move cursor to end of reference
                while (raw[j] != 10 && raw[j] != 13 && raw[j] != 32 && raw[j] != 47 && raw[j] != 60 && raw[j] != 62)
                    j++;

                ref = NumberUtils.parseInt(keyStart, j, raw);

                //move cursor to start of generation or next value
                while (raw[j] == 10 || raw[j] == 13 || raw[j] == 32)// || data[j]==47 || data[j]==60)
                    j++;

                /**
                 * get generation number
                 */
                keyStart = j;
                //move cursor to end of reference
                while (raw[j] != 10 && raw[j] != 13 && raw[j] != 32 && raw[j] != 47 && raw[j] != 60 && raw[j] != 62)
                    j++;

                generation = NumberUtils.parseInt(keyStart, j, raw);

                if(raw[raw.length-1]=='R'){ //recursively validate all child objects

                    pdfObject.setRef(new String(raw));
                    pdfObject.isDataExternal(true);

                    byte[] pageData = readObjectAsByteArray(pdfObject, objectRef, objectReader.isCompressed(ref, generation), ref, generation);

                    //allow for data in Linear object not yet loaded
                    if(pageData==null){
                        pdfObject.setFullyResolved(false);
                        return false;
                    }

                    //PdfObject childObj=ObjectFactory.createObject(pdfObject.getID(), pdfObject.getObjectRefAsString(), pdfObject.getObjectType(), pdfObject.getID());
                    pdfObject.setStatus(PdfObject.UNDECODED_DIRECT);
                    pdfObject.setUnresolvedData(pageData, PdfDictionary.Linearized);
                    pdfObject.isDataExternal(true);

                    if(!resolveFully(pdfObject))
                        pdfObject.setFullyResolved(false);

                }

                pdfObject.ignoreRecursion(false);
                readDictionaryAsObject(pdfObject, ref + " " + generation + " R", j, raw, raw.length, false);

                if(!pdfObject.isFullyResolved())
                    fullyResolved=false;
            }

        }catch(Exception e){

        }

        return fullyResolved;
    }

    /**
     * read object setup to contain only ref to data
     * @param pdfObject
     */
    public void checkResolved(PdfObject pdfObject){

        String paddingString="";

        if(pdfObject==null || pdfObject.getStatus()==PdfObject.DECODED)
            return;

        byte[] raw=pdfObject.getUnresolvedData();

        //flag now done and flush raw data
        pdfObject.setStatus(PdfObject.DECODED);

        //allow for empty object
        if(raw[0]=='e' && raw[1]=='n' && raw[2]=='d' && raw[3]=='o' && raw[4]=='b' ){
            //empty object
        }else{ //we need to ref from ref elsewhere which may be indirect [ref], hence loop

            String objectRef=pdfObject.getObjectRefAsString();

            //allow for Color where starts [/ICCBased 2 0 R so we get the ref if present
            if(raw[0]=='['){

                //scan along to find number
                int ptr=0, len=raw.length;
                for(int jj=0;jj<len;jj++){

                    if(raw[jj]>='0' && raw[jj]<='9'){
                        ptr=jj;
                        jj=len;
                    }
                }

                //check first non-number is R
                int end=ptr;
                while((raw[end]>='0' && raw[end]<='9') || raw[end]==' ' || raw[end]==10 || raw[end]==13 || raw[end]==9)
                    end++;
                //and store if it is a ref
                if(raw[end]=='R')
                    pdfObject.setRef(new String(raw,ptr,len-ptr));

            }else if(raw[raw.length-1]=='R')
                pdfObject.setRef(new String(raw));

            readDictionaryFromRefOrDirect(-1,pdfObject,objectRef, 0, raw , -1);

        }
    }

    public void flush() {

        if(cachedObjects!=null){
            Iterator files=cachedObjects.keySet().iterator();
            while(files.hasNext()){
                String fileName=(String)files.next();
                File file=new File(fileName);
                //System.out.println("PdfFileReader - deleting file "+fileName);
                file.delete();
                if(file.exists())
                    LogWriter.writeLog("Unable to delete temp file "+fileName);
            }
        }

        //delete any colorspaces
        cachedColorspaces.clear();
    }

    public void dispose() {
        this.cachedColorspaces=null;
        this.cachedObjects=null;

        this.compressedObj=null;


        //any linearized data
        if(linHintTable!=null){
            linHintTable=null;
        }
    }

    public PdfFileReader getFileReader() {
        return objectReader;
    }

    public void storeLinearizedTables(LinearizedHintTable linHintTable) {
        this.linHintTable=linHintTable;
    }
}
