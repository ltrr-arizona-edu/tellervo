/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2011, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * ObjectUtils.java
  * ---------------
 */
package org.jpedal.io;

import org.jpedal.objects.raw.PdfObject;

/**
 * general static methods
 */
public class ObjectUtils {
    static byte[] checkEndObject(byte[] array, long objStart, long lastEndStream) {
        int ObjStartCount = 0;

        //check if mising endobj
        for (int i = 0; i < array.length - 8; i++) {

            //track endstream and first or second obj
            if ((ObjStartCount < 2) && (array[i] == 32) && (array[i + 1] == 111) &&
                    (array[i + 2] == 98) && (array[i + 3] == 106)) {
                ObjStartCount++;
                objStart = i;
            }
            if ((ObjStartCount < 2) && (array[i] == 101) && (array[i + 1] == 110) &&
                    (array[i + 2] == 100) && (array[i + 3] == 115) &&
                    (array[i + 4] == 116) && (array[i + 5] == 114) &&
                    (array[i + 6] == 101) && (array[i + 7] == 97) && (array[i + 8] == 109))
                lastEndStream = i + 9;
        }

        if ((lastEndStream > 0) && (objStart > lastEndStream)) {
            byte[] newArray = new byte[(int) lastEndStream];
            System.arraycopy(array, 0, newArray, 0, (int) lastEndStream);
            array = newArray;
        }
        return array;
    }

    //replace sequence 13 10 with 32
    static byte[] convertReturnsToSpaces(byte[] newValues) {

        if(newValues==null)
            return null;

        //see if needed
        int returnCount=0;
        int len=newValues.length;
        for(int aa=0;aa<len;aa++){
            if(newValues[aa]==13 && newValues[aa+1]==10){
                aa++;
                returnCount++;
            }
        }

        //swap out if needed
        if(returnCount>0){

            int newLen=len-returnCount;
            int jj=0;
            byte[] oldValue=newValues;
            newValues=new byte[newLen];

            for(int aa=0;aa<len;aa++){

                if(oldValue[aa]==13 && aa<len-1 && oldValue[aa+1]==10){
                    newValues[jj]=32;
                    aa++;
                }else
                    newValues[jj]=oldValue[aa];

                jj++;
            }
        }

        return newValues;

    }

    static int handleUnknownType(int i, byte[] raw, int length) {
        int count=length-1;

        for(int jj=i;jj<count;jj++){

            if(raw[jj]=='R' && raw[jj-2]=='0'){
                i=jj;
                jj=count;
            }else if(raw[jj]=='<' && raw[jj+1]=='<'){

                int levels=0;
                while(true){

                    if(raw[jj]=='<' && raw[jj+1]=='<')
                        levels++;
                    else if(raw[jj]=='>' && raw[jj+1]=='>')
                        levels--;

                    jj++;
                    if(levels==0 || jj>=count)
                        break;
                }

                i=jj;

                jj=count;

            }else if(raw[jj]=='/'){
                jj=count;
            }else if(raw[jj]=='>' && raw[jj+1]=='>'){
                i=jj-1;
                jj=count;
            }else if(raw[jj]=='('){

                while(jj<count && (raw[jj]!=')' || isEscaped(raw, jj))){
                    jj++;
                }

                i=jj;
                jj=count;
            }
        }
        return i;
    }

    //count backwards to get total number of escape chars
    static boolean isEscaped(byte[] raw, int i) {
        int j=i-1, escapedFound=0;
        while(j>-1 && raw[j]=='\\'){
            j--;
            escapedFound++;
        }


        //System.out.println("escapedFound="+escapedFound+" "+(escapedFound & 2 ));
        return (escapedFound & 1) == 1;

    }

    static int setDirectValue(PdfObject pdfObject, int i, byte[] raw, int PDFkeyInt) {

        int keyStart;
        i++;
        keyStart = i;
        while (i < raw.length && raw[i] != 32 && raw[i] != 10 && raw[i] != 13)
            i++;

        //store value
        pdfObject.setConstant(PDFkeyInt, keyStart, i - keyStart, raw);
        return i;
    }

    /**
     * used to debug object reading code
     * @param level
     * @param objRef
     * @param pdfObject
     * @param i
     * @param length
     * @param raw
     * @param padding
     */
    static void showData(int level, String objRef, PdfObject pdfObject, int i, int length, byte[] raw, String padding) {

        System.out.println("\n\n"+ padding +"level="+level+" ------------readDictionaryAsObject ref="+ objRef +" into "+pdfObject+"-----------------\ni="+i+"\nData=>>>>");
        System.out.print(padding);

        for(int jj=i;jj<length;jj++){
            System.out.print((char)raw[jj]);

            //allow for comment
            if(raw[jj]==37){

                while(jj<length && raw[jj]!=10 && raw[jj]!=13)
                    jj++;

                //move cursor to start of text
                while(jj<length &&(raw[jj]==9 || raw[jj]==10 || raw[jj]==13 || raw[jj]==32 || raw[jj]==60))
                    jj++;
            }

            if(jj>5 && raw[jj-5]=='s' && raw[jj-4]=='t' && raw[jj-3]=='r' && raw[jj-2]=='e' && raw[jj-1]=='a' &&raw[jj]=='m')
                jj=length;

            if(jj>2 && raw[jj-2]=='B' && raw[jj-1]=='D' &&raw[jj]=='C')
                jj=length;
        }
        System.out.println(padding +"\n<<<<-----------------------------------------------------\n");
    }

    static String showMixedValuesAsString(Object[] objectValues, String values) {

        if(objectValues==null)
            return "null";

        values=values+'[';
        int count=objectValues.length;

        for(int jj=0;jj<count;jj++){

            if(objectValues[jj]==null)
                values=values+"null ";
            else if(objectValues[jj] instanceof byte[]){
                values=values+new String((byte[])objectValues[jj]);
                if(count-jj>1)
                    values=values+" , ";
            }else{
                values = showMixedValuesAsString((Object[])objectValues[jj], values)+"]";
                if(count-jj>1)
                    values=values+" ,";
            }
        }
        return values;
    }
}
