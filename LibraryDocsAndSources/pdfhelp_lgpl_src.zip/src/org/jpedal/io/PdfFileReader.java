/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * (C) Copyright 1997-2008, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------
  * PdfFileReader.java
  * ---------------
 */
package org.jpedal.io;


import java.io.*;
import java.util.Map;
import java.util.StringTokenizer;

import org.jpedal.exception.PdfSecurityException;
import org.jpedal.exception.PdfException;
import org.jpedal.objects.raw.*;
import org.jpedal.utils.LogWriter;
import org.jpedal.utils.NumberUtils;
import org.jpedal.utils.Sorts;
import org.jpedal.utils.repositories.Vector_Int;
import org.jpedal.utils.repositories.Vector_boolean;

/**
 * provides access to the file using Random access class to
 * read bytes and strings from a pdf file. Pdf file is a mix of
 * character and binary data streams
 */
public class PdfFileReader
{

    private final static int UNSET=-1;
    private final static int COMPRESSED=1;
    private final static int LEGACY=2;

    public PdfObject getInfoObject() {
        return infoObject;
    }

    /**info object*/
        private PdfObject infoObject=null;

    /**holds file ID*/
        private byte[] ID=null;

        PdfObject encyptionObj=null;

        /**pattern to look for in objects*/
        final static private String pattern= "obj";

    //private boolean isFDF=false;

    /**location of end ref*/
    private Vector_Int xref=new Vector_Int(100);

    DecryptionFactory decryption=null;

    /**encryption password*/
    private byte[] encryptionPassword = null;

    private final static byte[] oldPattern = "xref".getBytes();

    final static private byte[] EOFpattern = { 37, 37, 69, 79, 70 }; //pattern %%EOF

    final static private byte[] trailerpattern = { 't','r','a','i','l','e','r' }; //pattern %%EOF

    /**file access*/
    private RandomAccessBuffer pdf_datafile = null;

    private final static byte[] endObj = { 32, 111, 98, 106 }; //pattern endobj

    private final static byte[] lengthString = { 47, 76, 101, 110, 103, 116, 104}; //pattern /Length

    private final static byte[] startStream = { 115, 116, 114, 101, 97, 109};


    /**location from the reference table of each
     * object in the file
     */
    private Vector_Int offset = new Vector_Int( 2000 );

    /**flag to show if compressed*/
    private Vector_boolean isCompressed=new Vector_boolean(2000);

    /**generation of each object*/
    private Vector_Int generation = new Vector_Int( 2000 );

    public static final int alwaysCacheInMemory=16384;
    long eof;

    /**length of each object*/
    int[] ObjLengthTable;


    public void init(RandomAccessBuffer pdf_datafile){

        this.pdf_datafile=pdf_datafile;

        try{
            eof=pdf_datafile.length();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

/**
     * read 1.5 compression stream ref table
     * @throws PdfException
     */
    PdfObject readCompressedStream(int pointer, ObjectDecoder objectDecoder) throws PdfException {

        PdfObject encryptObj=null, rootObj=null;

        while (pointer != -1) {

            /**
             * get values to read stream ref
             */

            /**read raw object data*/
            try{
                movePointer(pointer);
            }catch(Exception e){
                LogWriter.writeLog("Exception moving pointer to "+ pointer);
            }

            byte[] raw = objectDecoder.readObjectData(-1, null);

            /**read the object name from the start*/
            StringBuffer objectName=new StringBuffer();
            char current1,last=' ';
            int matched=0, i1 =0;
            while(i1 <raw.length){
                current1 =(char)raw[i1];

                //treat returns same as spaces
                if(current1 ==10 || current1 ==13)
                    current1 =' ';

                if(current1 ==' ' && last==' '){//lose duplicate or spaces
                    matched=0;
                }else if(current1 ==pattern.charAt(matched)){ //looking for obj at end
                    matched++;
                }else{
                    matched=0;
                    objectName.append(current1);
                }
                if(matched==3)
                    break;
                last= current1;
                i1++;
            }

            //add end and put into Map
            objectName.append('R');
            String ref=objectName.toString();

            PdfObject pdfObject=new CompressedObject(ref);
            pdfObject.setCompressedStream(true);
            objectDecoder.readDictionaryAsObject(pdfObject, ref, 0, raw, -1, false);

            //read the field sizes
            int[] fieldSizes=pdfObject.getIntArray(PdfDictionary.W);

            //read the xrefs stream
            byte[] xrefs=pdfObject.getDecodedStream();

            //if encr
            if(xrefs==null)
                xrefs= objectDecoder.readStream(pdfObject, true, true, false, false, true, null);


            int[] Index=pdfObject.getIntArray(PdfDictionary.Index);
            if(Index==null){ //single set of values

                //System.out.println("-------------1.Offsets-------------"+current+" "+numbEntries);
                readCompressedOffsets(0, 0, pdfObject.getInt(PdfDictionary.Size), fieldSizes, xrefs);

            }else{ //pairs of values in Index[] array
                int count=Index.length,pntr=0;

                for(int aa=0;aa<count;aa=aa+2){

                    //System.out.println("-------------2.Offsets-------------"+Index[aa]+" "+Index[aa+1]);

                    pntr=readCompressedOffsets(pntr, Index[aa], Index[aa + 1], fieldSizes, xrefs);
                }
            }

            /**
             * now process trailer values - only first set of table values for
             * root, encryption and info
             */
            if (rootObj==null) {

                rootObj=pdfObject.getDictionary(PdfDictionary.Root);

                /**
                 * handle encryption
                 */
                encryptObj=pdfObject.getDictionary(PdfDictionary.Encrypt);

                if (encryptObj != null) {

                    byte[][] IDs=pdfObject.getStringArray(PdfDictionary.ID);
                    if(IDs!=null)
                        this.ID=IDs[0];
                }

                infoObject=pdfObject.getDictionary(PdfDictionary.Info);

            }

            //make sure first values used if several tables and code for prev so long as not linearized
            //may need adjusting as more examples turn up
            if(objectDecoder.linearObj!=null)
                pointer=-1;
            else
                pointer=pdfObject.getInt(PdfDictionary.Prev);
        }

        if(encryptObj!=null){
            decryption=new DecryptionFactory(ID,encryptionPassword);

            //and pass into decoder
            objectDecoder.setDecryption(decryption);

            //get values
            if(encyptionObj==null){
                encyptionObj=new EncryptionObject(new String(encryptObj.getUnresolvedData()));
                objectDecoder.readObject(encyptionObj);
            }

            decryption.readEncryptionObject(encyptionObj);

        }

        //add eol to refs as catchall
        xref.addElement( (int) eof);

        ObjLengthTable=calculateObjectLength(xref.get());

        return rootObj;
    }

    /**
     * read reference table from file so we can locate
     * objects in pdf file and read the trailers
     */
    PdfObject readLegacyReferenceTable(int pointer, int eof, ObjectDecoder objectDecoder) throws PdfException {

        PdfObject encryptObj=null, rootObj=null;

        //int lastPointer=-1;

        int current = 0; //current object number
        byte[] Bytes = null;
        int bufSize = 1024;

        int endTable = 0;

        /**read and decode 1 or more trailers*/
        while (true) {

            try {


                //allow for pointer outside file
                Bytes=readTrailer(bufSize, pointer, eof);

            } catch (Exception e) {
                Bytes=null;
                try {
                    closeFile();
                } catch (IOException e1) {
                    LogWriter.writeLog("Exception "+e+" closing file");
                }
                throw new PdfException("Exception " + e + " reading trailer");
            }

            if (Bytes == null) //safety catch
                break;

            /**get trailer*/
            int i = 0;

            int maxLen=Bytes.length;

            //for(int a=0;a<100;a++)
            //	System.out.println((char)Bytes[i+a]);
            while (i <maxLen) {//look for trailer keyword
                if (Bytes[i] == 116 && Bytes[i + 1] == 114 && Bytes[i + 2] == 97 && Bytes[i + 3] == 105 &&
                        Bytes[i + 4] == 108 && Bytes[i + 5] == 101 && Bytes[i + 6] == 114)
                    break;

                i++;
            }

            //save endtable position for later
            endTable = i;

            if(i==Bytes.length)
                break;

            //move to beyond <<
            while (Bytes[i] != 60 && Bytes[i - 1] != 60)
                i++;

            i++;
            PdfObject pdfObject=new CompressedObject("1 0 R");
            objectDecoder.readDictionary(pdfObject, "1 0 R", i, Bytes, false, -1, true);

            //move to beyond >>
            int level=0;
            while(true){

                if(Bytes[i] == 60 && Bytes[i - 1] == 60){
                    level++;
                    i++;
                }else if(Bytes[i] =='['){
                    i++;
                    while(Bytes[i]!=']'){
                        i++;
                        if(i==Bytes.length)
                            break;
                    }
                }else if(Bytes[i] ==62 && Bytes[i - 1] ==62){
                    level--;
                    i++;
                }

                if(level==0)
                    break;

                i++;
            }

            //handle optional XRefStm
            int XRefStm=pdfObject.getInt(PdfDictionary.XRefStm);

            if(XRefStm!=-1){
                pointer=XRefStm;
            }else{ //usual way

                boolean hasRef=true;

                //look for xref as end of startref
                while (Bytes[i] != 116 && Bytes[i + 1] != 120 &&
                        Bytes[i + 2] != 114 && Bytes[i + 3] != 101 && Bytes[i + 4] != 102){

                    if(Bytes[i]=='o' && Bytes[i+1]=='b' && Bytes[i+2]=='j'){
                        hasRef=false;
                        break;
                    }
                    i++;
                }

                if(hasRef){

                    i = i + 8;
                    //move to start of value ignoring spaces or returns
                    while ((i < maxLen)&& (Bytes[i] == 10 || Bytes[i] == 32 || Bytes[i] == 13))
                        i++;

                    int s=i;

                    //allow for characters between xref and startref
                    while (i < maxLen && Bytes[i] != 10 && Bytes[i] != 32 && Bytes[i] != 13)
                        i++;

                    /**convert xref to string to get pointer*/
                    if (s!=i)
                        pointer = NumberUtils.parseInt(s, i, Bytes);

                }
            }

            i=0;

            //allow for bum data at start
            while(Bytes[i]==13 || Bytes[i]==10 || Bytes[i]==9)
                i++;

            if (pointer == -1) {
                LogWriter.writeLog("No startRef");

                /**now read the objects for the trailers*/
            } else if (Bytes[i] == 120 && Bytes[i+1] == 114 && Bytes[i+2] == 101 && Bytes[i+3] == 102) { //make sure starts xref

                i = 5;

                //move to start of value ignoring spaces or returns
                while (Bytes[i] == 10 ||Bytes[i] == 32 || Bytes[i] == 13)
                    i++;

                current = readXRefs(xref, current, Bytes, endTable, i);
                i=endTable;

                /**now process trailer values - only first set of table values for root, encryption and info*/
                if (rootObj==null) {

                    rootObj=pdfObject.getDictionary(PdfDictionary.Root);

                    encryptObj=pdfObject.getDictionary(PdfDictionary.Encrypt);
                    if(encryptObj!=null){

                        byte[][] IDs=pdfObject.getStringArray(PdfDictionary.ID);
                        if(IDs!=null)
                            this.ID=IDs[0];
                    }

                    infoObject=pdfObject.getDictionary(PdfDictionary.Info);

                }

                //make sure first values used if several tables and code for prev
                pointer=pdfObject.getInt(PdfDictionary.Prev);

                //see if other trailers
                if (pointer!=-1 && pointer<this.eof) {
                    //reset values for loop
                    bufSize = 1024;

                    //track ref table so we can work out object length
                    xref.addElement(pointer);

                }else //reset if fails second test above
                    pointer=-1;

            } else{
                pointer=-1;

                //needs to be read to pick up potential /Pages value
                rootObj=new PageObject(findOffsets());
                objectDecoder.readObject(rootObj);

                objectDecoder.refTableInvalid=true;
            }
            if (pointer == -1)
                break;
        }

        /**
         * check offsets
         */

        //checkOffsets(validOffsets);
        if(encryptObj!=null){
            decryption=new DecryptionFactory(ID,encryptionPassword);

            //and pass into decoder
            objectDecoder.setDecryption(decryption);

            //get values
            if(encyptionObj==null){
                encyptionObj=new EncryptionObject(new String(encryptObj.getUnresolvedData()));
                objectDecoder.readObject(encyptionObj);
            }

            decryption.readEncryptionObject(encyptionObj);


        }

        if(!objectDecoder.refTableInvalid ){

            //add eol to refs as catchall
            xref.addElement( eof);

            ObjLengthTable=calculateObjectLength(xref.get());
        }
        return rootObj;
    }


/**give user access to internal flags such as user permissions*/
    public int getPDFflag(Integer flag) {

        if(decryption==null)
            return -1;
        else
            return decryption.getPDFflag(flag);

    }

    /**
        * read first start ref from last 1024 bytes
        */
       private int readFirstStartRef(ObjectDecoder objectDecoder) throws PdfException {

           //reset flag
           objectDecoder.refTableInvalid=false;
           int pointer = -1;
           int i = 1019;
           StringBuffer startRef = new StringBuffer();

           /**move to end of file and read last 1024 bytes*/
           int block=1024;
           byte[] lastBytes = new byte[block];
           long end;

           /**
            * set endpoint, losing null chars and anything before EOF
            */
           final int[] EndOfFileMarker={37,37,69,79};
           int valReached=3;
           boolean EOFFound=false;
           try {
               end=eof;

               /**
                * lose nulls and other trash from end of file
                */
               int bufSize=255;
               while(true){
                   byte[] buffer=getBytes(end - bufSize, bufSize);

                   int offset=0;

                   for(int ii=bufSize-1;ii>-1;ii--){

                       //see if we can decrement EOF tracker or restart check
                       if(!EOFFound)
                           valReached=3;

                       if(buffer[ii]==EndOfFileMarker[valReached]){
                           valReached--;
                           EOFFound=true;
                       }else
                           EOFFound=false;

                       //move to next byte
                       offset--;

                       if(valReached<0)
                           ii=-1;

                   }

                   //exit if found values on loop
                   if(valReached<0){
                       end=end-offset;
                       break;
                   }else{
                       end=end-bufSize;
                   }

                   //allow for no eof
                   if(end<0){
                       end=eof;
                       break;
                   }
               }

               //end=end+bufSize;

               //allow for very small file
               int count=(int)(end - block);

               if(count<0){
                   count=0;
                   int size=(int)eof;
                   lastBytes=new byte[size];
                   i=size+3; //force reset below
               }

               lastBytes=getBytes(count, lastBytes.length);

           } catch (Exception e) {
               LogWriter.writeLog("Exception " + e + " reading last 1024 bytes");
               throw new PdfException( e + " reading last 1024 bytes");
           }

           //		for(int ii=0;ii<lastBytes.length;ii++){
           //		System.out.print((char)lastBytes[ii]);
           //		}
           //		System.out.println();

           //look for tref as end of startxref
           int fileSize=lastBytes.length;

           if(i>fileSize)
               i=fileSize-5;

           while (i >-1) {

               if ((lastBytes[i] == 116)
                       && (lastBytes[i + 1] == 120)
                       && (lastBytes[i + 2] == 114)
                       && (lastBytes[i + 3] == 101)
                       && (lastBytes[i + 4] == 102))
                   break;


               i--;

           }

           /**trap buggy files*/
           if(i==-1){
               try {
                   closeFile();
               } catch (IOException e1) {
                   LogWriter.writeLog("Exception "+e1+" closing file");
               }
               throw new PdfException( "No Startref found in last 1024 bytes ");
           }

           i = i + 5; //allow for word length

           //move to start of value ignoring spaces or returns
           while (i < 1024 && (lastBytes[i] == 10 || lastBytes[i] == 32 || lastBytes[i] == 13))
               i++;

           //move to start of value ignoring spaces or returns
           while ((i < 1024)
                   && (lastBytes[i] != 10)
                   && (lastBytes[i] != 32)
                   && (lastBytes[i] != 13)) {
               startRef.append((char) lastBytes[i]);
               i++;
           }

           /**convert xref to string to get pointer*/
           if (startRef.length() > 0)
               pointer = Integer.parseInt(startRef.toString());

           if (pointer == -1){
               LogWriter.writeLog("No Startref found in last 1024 bytes ");
               try {
                   closeFile();
               } catch (IOException e1) {
                   LogWriter.writeLog("Exception "+e1+" closing file");
               }
               throw new PdfException( "No Startref found in last 1024 bytes ");
           }

           return pointer;
       }





        /**
     * read reference table start to see if new 1.5 type or traditional xref
     * @throws PdfException
     */
    final public PdfObject readReferenceTable(PdfObject linearObj, ObjectDecoder objectDecoder) throws PdfException {

        objectDecoder.linearObj=linearObj;

        int pointer = -1, eof = (int) this.eof;

        boolean islinearizedCompressed = false;

        if (linearObj == null) {
            pointer = readFirstStartRef(objectDecoder);
        } else { //find at start of Linearized
            byte[] data = getBuffer();


            int count = data.length, ptr = 5;
            for (int i = 0; i < count; i++) {

                //track start of this object (needed for compressed)
                if (data[i] == 'e' && data[i + 1] == 'n' && data[i + 2] == 'd' && data[i + 3] == 'o' && data[i + 4] == 'b' && data[i + 5] == 'j') {
                    ptr = i + 6;

                }

                if (data[i] == 'x' && data[i + 1] == 'r' && data[i + 2] == 'e' && data[i + 3] == 'f') {
                    pointer = i;
                    i = count;
                }else if (data[i] == 'X' && data[i + 1] == 'R' && data[i + 2] == 'e' && data[i + 3] == 'f') {

                    islinearizedCompressed = true;

                    pointer = ptr;
                    while (data[pointer] == 10 || data[pointer] == 13 || data[pointer] == 32) {
                        pointer++;
                    }

                    i = count;
                }
            }
        }

        xref.addElement(pointer);

        if (pointer >= eof) {

            LogWriter.writeLog("Pointer not if file - trying to manually find startref");

            objectDecoder.refTableInvalid = true;

            PdfObject rootObj=new PageObject(findOffsets());
            objectDecoder.readObject(rootObj);
            return rootObj;

        } else if (islinearizedCompressed || isCompressedStream(pointer, eof)) {
            return readCompressedStream(pointer,objectDecoder);
        } else {
            return readLegacyReferenceTable(pointer, eof,objectDecoder);
        }


    }


    public void spoolStreamDataToDisk(File tmpFile,long start) throws Exception{

           movePointer(start);

           boolean hasValues=false;

           // Create output file
           BufferedOutputStream array =new BufferedOutputStream(new FileOutputStream(tmpFile));

           int bufSize=-1;
           //PdfObject pdfObject=null;

           int startStreamCount=0;//newCacheSize=-1,;
           boolean startStreamFound=false;

           //if(pdfObject!=null) //only use if values found
           //newCacheSize=this.newCacheSize;

           final int XXX=2*1024*1024;

           int rawSize=bufSize,realPos=0;

           final boolean debug=false;

           boolean lengthSet=false; //start false and set to true if we find /Length in metadata
           boolean streamFound=false;

           if(debug)
               System.out.println("=============================");

           if(bufSize<1)
               bufSize=128;

//        if(newCacheSize!=-1 && bufSize>newCacheSize)
           //bufSize=newCacheSize;

           //array for data
           int ptr=0, maxPtr=bufSize;

           byte[] readData=new byte[maxPtr];

           int charReached = 0,charReached2=0, charReached3=0;

           byte[] buffer=null;
           boolean inStream=false,ignoreByte;

           /**adjust buffer if less than bytes left in file*/
           long pointer ;//lastEndStream=-1,objStart=-1;

           /**read the object or block*/
           try {

               byte currentByte ;//lastByte;

               int i=bufSize-1,offset=-bufSize;
               int blocksRead=0;//lastEnd=-1,lastComment=-1;

               while (true) {

                   i++;

                   if(i==bufSize){

                       //cache data and update counter
//                    if(blocksRead==1){
//                        dataRead=buffer;
//                    }else if(blocksRead>1){
//
//                        int bytesRead=dataRead.length;
//                        int newBytes=buffer.length;
//                        byte[] tmp=new byte[bytesRead+newBytes];
//
//                        //existing data into new array
//                        System.arraycopy(dataRead, 0, tmp, 0, bytesRead);
//
//                        //data from current block
//                        System.arraycopy(buffer, 0, tmp, bytesRead, newBytes);
//
//                        dataRead=tmp;
//
//                        //PUT BACK to switch on caching
//                        if(1==2 && streamFound && dataRead.length>newCacheSize) //stop if over max size
//                            break;
//                    }
                       blocksRead++;

                       /**
                        * read the next block
                        */
                       pointer = getPointer();

                       if(start==-1)
                           start=pointer;

                       /**adjust buffer if less than bytes left in file*/
                       if (pointer + bufSize > eof)
                           bufSize = (int) (eof - pointer);

                       bufSize += 6;
                       buffer = new byte[bufSize];

                       /**get bytes into buffer*/
                       read(buffer);

                       offset=offset+i;
                       i=0;

                   }

                   /**write out and look for endobj at end*/
                   //lastByte=currentByte;
                   currentByte = buffer[i];
                   ignoreByte=false;

                   //track comments
                   //if(currentByte=='%')
                   //lastComment=realPos;

                   /**check for endobj at end - reset if not*/
                   if (currentByte == ObjectDecoder.endPattern[charReached] &&  !inStream)
                       charReached++;
                   else
                       charReached = 0;

                   //also scan for <SPACE>obj after endstream incase no endobj
                   if(streamFound &&currentByte == endObj[charReached2] &&  !inStream)
                       charReached2++;
                   else
                       charReached2 = 0;

                   //look for start of stream and set inStream true

                   if(startStreamFound){
                       if(hasValues || currentByte!=13 && currentByte!=10){ //avoid trailing CR/LF
                           array.write(currentByte);
                           hasValues=true;
                       }
                   }

                   if (startStreamCount<6 && currentByte == startStream[startStreamCount]){
                       startStreamCount++;
                   }else
                       startStreamCount=0;

                   if(!startStreamFound && (startStreamCount == 6)){ //stream start found so log
                       //startStreamCount=offset+startStreamCount;
                       //pdfObject.setCache(start,this);
                       startStreamFound=true;
                   }


                   /**if length not set we go on endstream in data*/
                   if(!lengthSet){

                       //also scan for /Length if it had a valid size
                       if(rawSize!=-1){
                           if(!streamFound &&currentByte == lengthString[charReached3] &&  !inStream){
                               charReached3++;
                               if(charReached3==6)
                                   lengthSet=true;
                           }else
                               charReached3 = 0;
                       }
                   }

                   if (charReached == 6 || charReached2==4){

                       if(!lengthSet)
                           break;

                       charReached=0;
                       charReached2=0;
                       //lastEnd=realPos;

                   }

                   if(lengthSet && realPos>=rawSize)
                       break;

                   if(!ignoreByte && !inStream){//|| !inStream)

                       readData[ptr]=currentByte;

                       ptr++;
                       if(ptr==maxPtr){
                           if(maxPtr<XXX)
                               maxPtr=maxPtr*2;
                           else
                               maxPtr=maxPtr+100000;

                           byte[] tmpArray=new byte[maxPtr];
                           System.arraycopy(readData,0,tmpArray,0,readData.length);

                           readData=tmpArray;
                       }
                   }

                   realPos++;
               }

           } catch (Exception e) {
               e.printStackTrace();
               LogWriter.writeLog("Exception " + e + " reading object");
           }

           if(array!=null){
               array.flush();
               array.close();
           }
       }

/**
     * test first bytes to see if new 1.5 style table with obj or contains ref
     * @throws PdfException
     */
    boolean isCompressedStream(int pointer, int eof) throws PdfException {

        final boolean debug=false;

        int bufSize = 50,charReached_legacy=0, charReached_comp1=0,charReached_comp2=0;

        final int[] objStm={'O','b','j','S','t','m'};
        final int[] XRef={'X','R','e','f'};

        int type=UNSET;

        //flag to show if at start of data for check
        boolean firstRead=true;

        while (true) {

            /** adjust buffer if less than 1024 bytes left in file */
            if (pointer + bufSize > eof)
                bufSize = eof - pointer;

            if(bufSize<0)
                bufSize=50;

            byte[] buffer = getBytes(pointer, bufSize);

            //allow for fact sometimes start of data wrong
            if(firstRead && buffer[0]=='r' && buffer[1]=='e' && buffer[2]=='f')
                charReached_legacy=1;

            firstRead=false; //switch off

            /**look for xref or obj */
            for (int i = 0; i < bufSize; i++) {

                byte currentByte = buffer[i];

                if(debug)
                    System.out.print((char)currentByte);

                /** check for xref OR end - reset if not */
                if (currentByte == oldPattern[charReached_legacy] && type!=COMPRESSED){
                    charReached_legacy++;
                    type=LEGACY;
                }else if ((currentByte == objStm[charReached_comp1] )&& (charReached_comp1==0 || type==COMPRESSED)){

                    charReached_comp1++;
                    type=COMPRESSED;
                }else if ((currentByte == XRef[charReached_comp2] )&& (charReached_comp2==0 || type==COMPRESSED)){

                    charReached_comp2++;
                    type=COMPRESSED;
                }else{

                    charReached_legacy=0;
                    charReached_comp1=0;
                    charReached_comp2=0;

                    type=UNSET;
                }

                if (charReached_legacy==3 || charReached_comp1==3 || charReached_comp2 == 3)
                    break;

            }

            if (charReached_legacy==3 || charReached_comp1==3 || charReached_comp2 == 3)
                break;

            //update pointer
            pointer = pointer + bufSize;

        }

        /**
         * throw exception if no match or tell user which type
         */
        if(type==UNSET){
            try {
                closeFile();
            } catch (IOException e1) {
                LogWriter.writeLog("Exception "+1+" closing file");
            }
            throw new PdfException("Exception unable to find ref or obj in trailer");
        }

        return type == COMPRESSED;
    }


    void closeFile() throws IOException {

        if(pdf_datafile!=null){
            pdf_datafile.close();
            pdf_datafile=null;
        }
    }

        byte[] readTrailer(int bufSize, int pointer, int eof) throws IOException {

        int charReached = 0, charReached2 = 0, trailerCount = 0;
        final int end = 4;

        /**read in the bytes, using the startRef as our terminator*/
        ByteArrayOutputStream bis = new ByteArrayOutputStream();

        while (true) {

            /** adjust buffer if less than 1024 bytes left in file */
            if (pointer + bufSize > eof) {
                bufSize = eof - pointer;
            }

            if(bufSize==0)
                break;

            byte[] buffer = getBytes(pointer, bufSize);

            boolean endFound = false;

            /** write out and lookf for startref at end */
            for (int i = 0; i < bufSize; i++) {

                byte currentByte = buffer[i];

                /** check for startref at end - reset if not */
                if (currentByte == EOFpattern[charReached]) {
                    charReached++;
                } else {
                    charReached = 0;
                }

                /** check for trailer at end - ie second spurious trailer obj */
                if (currentByte == trailerpattern[charReached2]) {
                    charReached2++;
                } else {
                    charReached2 = 0;
                }

                if (charReached2 == 7) {
                    trailerCount++;
                    charReached2 = 0;
                }

                if (charReached == end || trailerCount == 2) { //located %%EOF and get last few bytes

                    for (int j = 0; j < i + 1; j++) {
                        bis.write(buffer[j]);
                    }

                    i = bufSize;
                    endFound = true;

                }
            }

            //write out block if whole block used
            if (!endFound) {
                bis.write(buffer);
            }

            //update pointer
            pointer = pointer + bufSize;

            if (charReached == end || trailerCount == 2) {
                break;
            }

        }

        bis.close();
        return bis.toByteArray();

    }

    /**
     * return pdf data
     */
    public byte[] getBuffer() {
        return pdf_datafile.getPdfBuffer();
    }

    /** Utility method used during processing of type1C files */
    static  private int getWord(byte[] content, int index, int size) {
        int result = 0;
        for (int i = 0; i < size; i++) {
            result = (result << 8) + (content[index + i] & 0xff);

        }
        return result;
    }

    /**
     * read table of values
     */
    int readXRefs(Vector_Int xref, int current, byte[] Bytes, int endTable, int i) {

        char flag;
        int id,tokenCount,generation,lineLen,startLine,endLine;
        boolean skipNext=false;
        boolean isFirstValue=true;

        int[] breaks=new int[5];
        int[] starts=new int[5];

        // loop to read all references
        while (i < endTable) { //exit end at trailer

            startLine=i;
            endLine=-1;

            /**
             * read line locations
             */
            //move to start of value ignoring spaces or returns
            while ((Bytes[i] != 10) & (Bytes[i] != 13)) {
                //scan for %
                if((endLine==-1)&&(Bytes[i]==37))
                    endLine=i-1;

                i++;
            }

            //set end if no comment
            if(endLine==-1)
                endLine=i-1;

            //strip any spaces
            while(Bytes[startLine]==32)
                startLine++;

            //strip any spaces
            while(Bytes[endLine]==32)
                endLine--;

            i++;

            /**
             * decode the line
             */
            tokenCount=0;
            lineLen=endLine-startLine+1;

            if(lineLen>0){

                //decide if line is a section header or value

                //first count tokens
                int lastChar=1,currentChar;
                for(int j=1;j<lineLen;j++){
                    currentChar=Bytes[startLine+j];

                    if((currentChar==32)&&(lastChar!=32)){
                        breaks[tokenCount]=j;
                        tokenCount++;
                    }else if((currentChar!=32)&&(lastChar==32)){
                        starts[tokenCount]=j;
                    }

                    lastChar=currentChar;
                }

                //update numbers so loops work
                breaks[tokenCount]=lineLen;
                tokenCount++;

                if(tokenCount==1){ //fix for first 2 values on separate lines

                    if(skipNext)
                        skipNext=false;
                    else{
                        current= NumberUtils.parseInt(startLine, startLine + breaks[0], Bytes);
                        skipNext=true;
                    }

                }else if (tokenCount == 2){
                    current= NumberUtils.parseInt(startLine, startLine + breaks[0], Bytes);
                }else {

                    id = NumberUtils.parseInt(startLine, startLine + breaks[0], Bytes);
                    generation= NumberUtils.parseInt(startLine + starts[1], startLine + breaks[1], Bytes);

                    flag =(char)Bytes[startLine+starts[2]];

                    if ((flag=='n')) { // only add objects in use

                        /**
                         * assume not valid and test to see if valid
                         */
                        boolean isValid=false;

                        //get bytes
                        int bufSize=20;

                        //adjust buffer if less than 1024 bytes left in file
                        if (id + bufSize > eof)
                            bufSize = (int) (eof - id);

                        if(bufSize>0){

                            /** get bytes into buffer */
                            byte[] buffer = getBytes(id, bufSize);

                            //look for space o b j
                            for(int ii=4;ii<bufSize;ii++){
                                if((buffer[ii-3]==32 || buffer[ii-3]==10)&&(buffer[ii-2]==111)&&(buffer[ii-1]==98)&&(buffer[ii]==106)){
                                    isValid=true;
                                    ii=bufSize;
                                }
                            }

                            //check number
                            if(isValid && isFirstValue){

                                isFirstValue=false;

                                if(buffer[0]==48 && buffer[1]!=48 && current==1)
                                    current=0;
                            }

                            if(isValid){
                                storeObjectOffset(current, id, generation, false);
                                xref.addElement( id);
                            }else{
                            }
                        }

                        current++; //update our pointer
                    }else if (flag=='f')
                        current++; //update our pointer

                }
            }
        }
        return current;
    }

        /**
     * @param First
     * @param compressedStream
     */
    void extractCompressedObjectOffset(Map offsetStart, Map offsetEnd,int First, byte[] compressedStream, int compressedID) {

        String lastKey=null,key,offset ;

        final boolean debug=false;
        StringBuffer rawKey=null,rawOffset ;
        int startKey,endKey,startOff,endOff ;
        int id=-1;

        //read the offsets table
        for(int ii=0;ii<First;ii++){

            //ignore any gaps between entries
            //(for loop assumes single char and not always correct)
            while(compressedStream[ii]==10 || compressedStream[ii]==13)
                ii++;

            if(debug){
                rawKey=new StringBuffer();
                rawOffset=new StringBuffer();
            }

            /**work out key size*/
            startKey=ii;
            while(compressedStream[ii]!=32 && compressedStream[ii]!=13 && compressedStream[ii]!=10){
                if(debug)
                    rawKey.append((char)compressedStream[ii]);
                ii++;
            }
            endKey=ii-1;

            /**extract key*/
            int length=endKey-startKey+1;
            char[] newCommand=new char[length];
            id=-1; //reset for each
            for(int i=0;i<length;i++)
                newCommand[i]=(char)compressedStream[startKey+i];

            key =new String(newCommand);

            //track as number for later
            id= NumberUtils.parseInt(startKey, startKey + length, compressedStream);

            /**test key if in debug*/
            if(debug){
                if(!key.equals(rawKey.toString()))
                    throw new RuntimeException("Different="+key+"<>"+rawKey+ '<');

            }

            /**move to offset*/
            while(compressedStream[ii]==32 || compressedStream[ii]==13 || compressedStream[ii]==10)
                ii++;

            /**get size*/
            startOff=ii;
            while((compressedStream[ii]!=32 && compressedStream[ii]!=13 && compressedStream[ii]!=10)&&(ii<First)){

                if(debug)
                    rawOffset.append((char)compressedStream[ii]);

                ii++;
            }
            endOff=ii-1;

            /**extract offset*/
            length=endOff-startOff+1;
            newCommand=new char[length];
            for(int i=0;i<length;i++)
                newCommand[i]=(char)compressedStream[startOff+i];

            offset =new String(newCommand);

            /**test key if in debug*/
            if(debug){
                if(!offset.equals(rawOffset.toString()))
                    throw new RuntimeException("Different="+offset+"<>"+rawOffset+ '<');

            }

            /**
             * save values if in correct block (can list items over-written in another compressed obj)
             */
            if(compressedID==getOffset(id)){
                offsetStart.put(key,offset);

                //save end as well
                if(lastKey!=null)
                    offsetEnd.put(lastKey,offset);

                lastKey=key;
            }
        }
    }

    int readCompressedOffsets(int pntr, int current, int numbEntries, int[] fieldSizes, byte[] xrefs) throws PdfException {

        //now parse the stream and extract values

        final boolean debug=false;

        if(debug)
            System.out.println("===============read offsets============= current="+current+" numbEntries="+numbEntries);

        int[] defaultValue={1,0,0};

        boolean hasCase0=false;

        for(int i=0;i<numbEntries;i++){

            //read the next 3 values
            int[] nextValue=new int[3];
            for(int ii=0;ii<3;ii++){
                if(fieldSizes[ii]==0){
                    nextValue[ii]=defaultValue[ii];
                }else{
                    nextValue[ii]=getWord(xrefs,pntr,fieldSizes[ii]);
                    pntr=pntr+fieldSizes[ii];
                }
            }

            //handle values appropriately
            int id,gen;
            switch(nextValue[0]){
                case 0: //linked list of free objects
                    current++;

                    hasCase0=nextValue[1]==0 && nextValue[2]==0;

                    if(debug)
                        System.out.println("case 0 nextFree="+nextValue[1]+" gen="+nextValue[2]);

                    break;
                case 1: //non-compressed
                    id=nextValue[1];
                    gen=nextValue[2];

                    if(debug)
                        System.out.println("case 1   current="+current+" id="+id+" byteOffset="+nextValue[1]+" gen="+nextValue[2]);

                    //if number equals offset , test if valid
                    boolean refIsvalid=true;
                    if(current==id){
                        refIsvalid=false;

                        //get the data and see if genuine match
                        int size=20;
                        byte[] data=getBytes(current, size);

                        //find space
                        int ptr=0;
                        for(int ii=0;ii<size;ii++){
                            if(data[ii]==32 || data[ii]==10 || data[ii]==13){
                                ptr=ii;
                                ii=size;

                            }
                        }

                        if(ptr>0){
                            int ref= NumberUtils.parseInt(0, ptr, data);
                            if(ref==current)
                                refIsvalid=true;
                        }
                    }

                    if(refIsvalid || !hasCase0)
                        storeObjectOffset(current, id, gen, false);

                    current++;
                    break;
                case 2: //compressed
                    id=nextValue[1];
                    gen=nextValue[2];

                    if(debug)
                        System.out.println("case 2  current="+current+" object number="+id+" index="+gen);

                    storeObjectOffset(current, id, 0, true);

                    current++;

                    break;
                default:

                    //System.out.println(" -> nextValue[0] = " + nextValue[0]);

                    throw new PdfException("Exception Unsupported Compression mode with value "+nextValue[0]);
                    //current++;
                    //break;
            }
        }

        return pntr;
    }

    byte[] readFDFData() throws IOException{

        int eof = (int) pdf_datafile.length();

        pdf_datafile.readLine(); //lose first line with definition
        int start=(int)pdf_datafile.getFilePointer();

        eof=eof-start;
        byte[] fileData=new byte[eof];
        this.pdf_datafile.read(fileData);

        return fileData;
    }

    /**
     * precalculate sizes for each object
     */
    int[] calculateObjectLength(int[] xrefs) {

        //get order list of refs
        int xrefCount=xrefs.length;
        int[] xrefID=new int[xrefCount];
        for(int i=0;i<xrefCount;i++)
            xrefID[i]=i;
        xrefID= Sorts.quicksort(xrefs, xrefID);

        //get ordered list of objects in offset order
        int objectCount=offset.getCapacity();

        int[] id=new int[objectCount];
        int[] offsets=new int[objectCount];

        //read from local copies and pop lookup table
        int[] off=offset.get();
        boolean[] isComp=isCompressed.get();
        for(int i=0;i<objectCount;i++){
            if(!isComp[i]){
                offsets[i]=off[i];
                id[i]=i;
            }
        }

        id=Sorts.quicksort( offsets, id );

        int i=0;
        //ignore empty values
        while(true){

            if(offsets[id[i]]!=0)
                break;
            i++;

        }

        /**
         * loop to calc all object lengths
         * */
        int  start=offsets[id[i]],end;

        //find next xref
        int j=0;
        while(xrefs[xrefID[j]]<start+1)
            j++;

        int[] ObjLengthTable=new int[objectCount];

        while(i<objectCount-1){

            end=offsets[id[i+1]];
            int objLength=end-start-1;

            //adjust for any xref
            if(xrefs[xrefID[j]]<end){
                objLength=xrefs[xrefID[j]]-start-1;
                while(xrefs[xrefID[j]]<end+1)
                    j++;
            }
            ObjLengthTable[id[i]]=objLength;
            //System.out.println(id[i]+" "+objLength+" "+start+" "+end);
            start=end;
            while(xrefs[xrefID[j]]<start+1)
                j++;
            i++;
        }

        //special case - last object

        ObjLengthTable[id[i]]=xrefs[xrefID[j]]-start-1;
        //System.out.println("*"+id[i]+" "+start+" "+xref+" "+eof);

        return ObjLengthTable;
    }

    /////////////////////////////////////////////////////////////////////////
    /**
     * version of move pointer which takes object name
     * as int
     */
    final protected long movePointer( int currentID,int generation)
    {
        return movePointer( offset.elementAt(currentID ) );
    }

    public long getOffset(int currentID) {
        return offset.elementAt(currentID );
    }

    public byte[] getBytes(long start, int count) {
        byte[] buffer=new byte[count];

        movePointer(start);
        try {
            pdf_datafile.read(buffer); //get next chars
        } catch (IOException e) {
            e.printStackTrace();
        }

        return buffer;
    }

    /**
     * find a valid offset
     */
     String findOffsets() throws PdfSecurityException {

        LogWriter.writeLog("Corrupt xref table - trying to find objects manually");

        String root_id = "";
        try {
            movePointer(0);
        } catch (Exception e) {
            e.printStackTrace();
        }

        while (true) {
            String line = null;

            int i = (int) this.getPointer();

            try {
                line = pdf_datafile.readLine();
            } catch (Exception e) {
                LogWriter.writeLog("Exception " + e + " reading line");
            }
            if (line == null)
                break;

            if (line.indexOf(" obj") != -1) {

                int pointer = line.indexOf(' ');
                if (pointer > -1) {
                    int current_number = Integer.parseInt(line.substring(0,
                            pointer));
                    storeObjectOffset(current_number, i, 1,false);
                }

            } else if (line.indexOf("/Root") != -1) {

                int start = line.indexOf("/Root") + 5;
                int pointer = line.indexOf('R', start);
                if (pointer > -1)
                    root_id = line.substring(start, pointer + 1).trim();
            } else if (line.indexOf("/Encrypt") != -1) {
                //too much risk on corrupt file
                throw new PdfSecurityException("Corrupted, encrypted file");
            }
        }

        return root_id;
    }



    public void dispose(){

// <start-me>
        //SecOP java ME - removed to remove additional package secop1_0.jar in java ME
        if(decryption!=null)
            decryption.cipher=null;
        // <end-me>
        decryption=null;



        offset=null;
        generation=null;
        isCompressed=null;

        try {
            if(pdf_datafile!=null)
                pdf_datafile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        pdf_datafile=null;

         xref=null;

    }

    /////////////////////////////////////////////////////////////////////////
    /**
     * version of move pointer which takes object name
     * and converts before calling main routine
     */
    final protected long movePointer( String pages_id )
    {
        long pointer = getOffset( pages_id );

        return movePointer( pointer );
    }

    //////////////////////////////////////////////////////////////////////
    /**
     * get pdf type in file (found at start of file)
     */
    final public String getType()
    {

        String pdf_type = "";
        try{
            movePointer( 0 );
            pdf_type = pdf_datafile.readLine();

            //strip off anything before
            int pos=pdf_type.indexOf("%PDF");
            if(pos!=-1)
                pdf_type=pdf_type.substring(pos+5);

        }catch( Exception e ){
            LogWriter.writeLog( "Exception " + e + " in reading type" );
        }
        return pdf_type;
    }




    //////////////////////////////////////////////////////////////////////////
    /**
     * returns current location pointer and sets to new value
     */
    final long movePointer(long pointer)
    {
        long old_pointer = 0;
        try
        {
            //make sure inside file
            if( pointer > pdf_datafile.length() ){
                LogWriter.writeLog( "Attempting to access ref outside file" );
                //throw new PdfException("Exception moving file pointer - ref outside file");
            }else{
                old_pointer = getPointer();
                pdf_datafile.seek( pointer );
            }
        }
        catch( Exception e )
        {
            LogWriter.writeLog( "Exception " + e + " moving pointer to  "+pointer+" in file.");

        }
        return old_pointer;
    }

    void read(byte[] buffer) throws IOException {
        pdf_datafile.read(buffer);
    }

    //////////////////////////////////////////////////
    /**
     * gets pointer to current location in the file
     */
    final protected long getPointer()
    {
        long old_pointer = 0;
        try
        {
            old_pointer = pdf_datafile.getFilePointer();
        }
        catch( Exception e )
        {
            LogWriter.writeLog( "Exception " + e + " getting pointer in file" );
        }
        return old_pointer;
    }
    //////////////////////////////////////////////////////////////////////////
    /**
     * place object details in queue
     */
    final void storeObjectOffset(int current_number, int current_offset, int current_generation, boolean isEntryCompressed)
    {

        /**
         * check it does not already exist
         */
        int existing_generation = 0;
        int offsetNumber=0;

        if(current_number<generation.getCapacity()){
            existing_generation=generation.elementAt( current_number );
            offsetNumber=offset.elementAt( current_number ) ;

        }

        //write out if not a newer copy (ignore items from Prev tables if newer)
        if( existing_generation < current_generation  || offsetNumber== 0 )
        {
            offset.setElementAt( current_offset, current_number );
            generation.setElementAt( current_generation, current_number );
            isCompressed.setElementAt(isEntryCompressed,current_number);
        }else{
            //LogWriter.writeLog("Object "+current_number + ", generation "+
            //current_generation + " already exists as"+
            //existing_generation);
        }

    }
    ///////////////////////////////////////////////////////////////////////////

    /**
     * returns stream in which compressed object will be found
     */
    protected final int getCompressedStreamObject(int currentID,int gen)
    {
        return offset.elementAt(currentID );
    }

    /**
     * returns stream in which compressed object will be found
     * (actually reuses getOffset internally)
     */
    protected final int getCompressedStreamObject( String value )
    {

        int currentID=0;
        //		handle indirect reference
        if( value.endsWith( "R" ) == true )
        {
            StringTokenizer values = new StringTokenizer( value );
            currentID = Integer.parseInt( values.nextToken() );
        }
        else
            LogWriter.writeLog( "Error with reference ..value=" + value+"<" );

        return offset.elementAt(currentID );
    }


    /**
     * general routine to turn reference into id with object name
     */
    final int getOffset(String value)
    {

        int currentID=0;
        //		handle indirect reference
        if( value.endsWith( "R" ) == true )
        {
            StringTokenizer values = new StringTokenizer( value );
            currentID = Integer.parseInt( values.nextToken() );
        }
        else
            LogWriter.writeLog( "2. Error with reference .." + value+"<<" );

        return offset.elementAt(currentID );
    }

    /**
     * returns where in compressed stream value can be found
     * (actually reuses getGen internally)
     *
     protected final int getOffsetInCompressedStream( String value )
     {

     int currentID=0;
     //		handle indirect reference
     if( value.endsWith( "R" ) == true )
     {
     StringTokenizer values = new StringTokenizer( value );
     currentID = Integer.parseInt( values.nextToken() );
     currentGeneration=Integer.parseInt( values.nextToken() );
     }
     else
     LogWriter.writeLog( "3. Error with reference .." + value+"<" );

     return generation.elementAt(currentID );
     }/**/

    /**
     * general routine to turn reference into id with object name
     *
     protected final int getGen( String value )
     {

     int currentID=0;
     //		handle indirect reference
     if( value.endsWith( "R" ) == true )
     {
     StringTokenizer values = new StringTokenizer( value );
     currentID = Integer.parseInt( values.nextToken() );
     currentGeneration=Integer.parseInt( values.nextToken() );
     }
     else
     LogWriter.writeLog( "4. Error with reference .." + value+"<" );

     return generation.elementAt(currentID );
     }/**/

    /**
     * general routine to turn reference into id with object name
     */
    public final boolean isCompressed( int ref,int gen )
    {

        return isCompressed.elementAt(ref);
    }

    /**
     * general routine to turn reference into id with object name
     */
    protected final boolean isCompressed( String value )
    {

        int currentID=0;
        //		handle indirect reference
        if( value.endsWith( "R" ) == true )
        {
            StringTokenizer values = new StringTokenizer( value );
            currentID = Integer.parseInt( values.nextToken() );
        }
        else
            LogWriter.writeLog( "5.Error with reference .." + value+"<" );

        return isCompressed.elementAt(currentID );
    }

    public DecryptionFactory getDecryptionObject() {
        return decryption;
    }

    public void setPassword(String password) {

         this.encryptionPassword = password.getBytes();

        //reset
        if(decryption!=null)
            decryption.reset(encryptionPassword);
    }
}

